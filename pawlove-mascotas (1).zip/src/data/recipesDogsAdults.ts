import { Recipe } from '../types';

export const DOG_ADULT_RECIPES: Recipe[] = [
  {
    id: 'dog-adu-01',
    title: 'Pollo con Arroz y Calabaza para Perros Adultos',
    frenchTitle: 'Poulet Fermier au Riz & Potimarron Adulte',
    species: 'dog',
    growthStage: 'adult',
    category: 'sensitive_digestion',
    categoryLabel: 'Mantenimiento & Digestión Confortable',
    description: 'Hervir pollo 25 min, arroz 18 min y calabaza 15 min. Mezclar y añadir aceite de salmón, probióticos y cáscara de huevo.',
    kcalPer100g: 130,
    prepTimeMin: 15,
    cookTimeMin: 25,
    difficulty: 'Fácil',
    suitability: 'Perros adultos de 1 a 7 años de cualquier raza y peso',
    clinicalBenefits: ['Proteína magra para tono muscular sin sobrecarga metabólica', 'Calabaza rica en fibra soluble prebiótica', 'Probióticos vivos y Omega 3'],
    ingredients: [
      { name: 'Pechuga de pollo desgrasada', category: 'protein', baseGramsFor10kgPetPerDay: 190, notes: 'Hervir 25 min' },
      { name: 'Arroz blanco cocido', category: 'fiber_carb', baseGramsFor10kgPetPerDay: 70, notes: 'Hervir 18 min' },
      { name: 'Calabaza cocida', category: 'vegetable', baseGramsFor10kgPetPerDay: 50, notes: 'Cocer 15 min' },
      { name: 'Aceite de salmón salvaje', category: 'healthy_fat', baseGramsFor10kgPetPerDay: 4, notes: 'Añadir templado' },
      { name: 'Probióticos caninos', category: 'supplement_calcium', baseGramsFor10kgPetPerDay: 3, notes: 'Añadir al final' },
      { name: 'Cáscara de huevo en polvo', category: 'supplement_calcium', baseGramsFor10kgPetPerDay: 4, notes: 'Calcio' }
    ],
    instructions: [
      'Hervir la pechuga de pollo durante 25 minutos.',
      'Cocer el arroz durante 18 minutos y la calabaza 15 minutos.',
      'Mezclar todo desmigando la carne.',
      'Añadir aceite de salmón, probióticos y cáscara de huevo en templado.'
    ],
    storageInfo: 'Nevera 3-4 días, congelador 2 meses.',
    macronutrients: { proteinPct: 46, fatPct: 16, fiberCarbPct: 26, moisturePct: 77 }
  },
  {
    id: 'dog-adu-02',
    title: 'Pavo con Patata y Zanahoria para Perros Adultos',
    frenchTitle: 'Dinde Mijotée aux Pommes de Terre & Carottes',
    species: 'dog',
    growthStage: 'adult',
    category: 'vitality_gourmet',
    categoryLabel: 'Vitalidad Diaria & Ligereza',
    description: 'Hervir pavo 25 min, patata 20 min y zanahoria 15 min. Incorporar probióticos al final cuando esté templado y añadir cáscara de huevo.',
    kcalPer100g: 125,
    prepTimeMin: 15,
    cookTimeMin: 25,
    difficulty: 'Fácil',
    suitability: 'Perros adultos activos y perros con tendencia a alergias al pollo',
    clinicalBenefits: ['Pavo hipoalergénico con excelente perfil de aminoácidos', 'Zanahoria rica en fibra y carotenos', 'Soporte probiótico intestinal'],
    ingredients: [
      { name: 'Pechuga o lomo de pavo', category: 'protein', baseGramsFor10kgPetPerDay: 190, notes: 'Hervir 25 min' },
      { name: 'Patata cocida sin piel', category: 'fiber_carb', baseGramsFor10kgPetPerDay: 65, notes: 'Cocer 20 min' },
      { name: 'Zanahoria en dados', category: 'vegetable', baseGramsFor10kgPetPerDay: 50, notes: 'Cocer 15 min' },
      { name: 'Probióticos caninos', category: 'supplement_calcium', baseGramsFor10kgPetPerDay: 3, notes: 'Al templar' },
      { name: 'Cáscara de huevo molida', category: 'supplement_calcium', baseGramsFor10kgPetPerDay: 4, notes: 'Calcio' }
    ],
    instructions: [
      'Hervir el pavo durante 25 minutos.',
      'Cocer la patata 20 minutos y la zanahoria 15 minutos.',
      'Mezclar todo e incorporar probióticos y cáscara de huevo al final.'
    ],
    storageInfo: 'Nevera 3 días, congelador 2 meses.',
    macronutrients: { proteinPct: 47, fatPct: 15, fiberCarbPct: 26, moisturePct: 78 }
  },
  {
    id: 'dog-adu-03',
    title: 'Ternera con Boniato y Espinaca para Perros Adultos',
    frenchTitle: 'Bœuf Braisé à la Patate Douce & Épinards',
    species: 'dog',
    growthStage: 'adult',
    category: 'vitality_gourmet',
    categoryLabel: 'Fuerza Muscular & Glucosamina',
    description: 'Guisar ternera 30 min, boniato 25 min y espinaca 5 min. Añadir aceite de linaza, glucosamina y cáscara de huevo.',
    kcalPer100g: 135,
    prepTimeMin: 15,
    cookTimeMin: 30,
    difficulty: 'Fácil',
    suitability: 'Perros adultos deportistas o de paseos largos',
    clinicalBenefits: ['Carne roja magra con hierro hemo de alta absorción', 'Glucosamina añadida para prevenir desgaste articular', 'Aceite de linaza con omega 3'],
    ingredients: [
      { name: 'Carne magra de ternera', category: 'protein', baseGramsFor10kgPetPerDay: 190, notes: 'Guisar 30 min' },
      { name: 'Boniato cocido', category: 'fiber_carb', baseGramsFor10kgPetPerDay: 65, notes: 'Cocer 25 min' },
      { name: 'Espinaca fresca', category: 'vegetable', baseGramsFor10kgPetPerDay: 35, notes: 'Escaldar 5 min' },
      { name: 'Glucosamina canina', category: 'supplement_calcium', baseGramsFor10kgPetPerDay: 2, notes: 'Protector articular' },
      { name: 'Aceite de linaza', category: 'healthy_fat', baseGramsFor10kgPetPerDay: 4, notes: 'En crudo' },
      { name: 'Cáscara de huevo molida', category: 'supplement_calcium', baseGramsFor10kgPetPerDay: 4, notes: 'Calcio' }
    ],
    instructions: [
      'Guisar la ternera 30 minutos.',
      'Cocer el boniato 25 minutos y la espinaca los últimos 5 minutos.',
      'Mezclar e integrar la glucosamina, el aceite de linaza y la cáscara de huevo.'
    ],
    storageInfo: 'Nevera 3 días, congelador 2 meses.',
    macronutrients: { proteinPct: 49, fatPct: 17, fiberCarbPct: 23, moisturePct: 76 }
  },
  {
    id: 'dog-adu-04',
    title: 'Salmón con Arroz Integral y Brócoli para Perros Adultos',
    frenchTitle: 'Saumon Vapeur au Riz Complet & Brocoli Croquant',
    species: 'dog',
    growthStage: 'adult',
    category: 'joint_omega3',
    categoryLabel: 'Salud Cardiorrespiratoria & Pelaje',
    description: 'Salmón al vapor 12 min, arroz integral 25 min y brócoli 8 min. Suplementar con omega 3, aceite de salmón y cáscara de huevo.',
    kcalPer100g: 140,
    prepTimeMin: 15,
    cookTimeMin: 25,
    difficulty: 'Fácil',
    suitability: 'Perros adultos que mudan pelo o con piel reactiva',
    clinicalBenefits: ['Brillo dérmico inmediato y reducción de caspa', 'Brócoli como potente antioxidante celular', 'Omega 3 marino puro'],
    ingredients: [
      { name: 'Lomo de salmón sin espinas', category: 'protein', baseGramsFor10kgPetPerDay: 190, notes: 'Al vapor 12 min' },
      { name: 'Arroz integral cocido', category: 'fiber_carb', baseGramsFor10kgPetPerDay: 60, notes: 'Cocer 25 min' },
      { name: 'Brócoli al vapor', category: 'vegetable', baseGramsFor10kgPetPerDay: 45, notes: 'Cocer 8 min' },
      { name: 'Aceite de salmón', category: 'healthy_fat', baseGramsFor10kgPetPerDay: 4, notes: 'Omega 3' },
      { name: 'Cáscara de huevo en polvo', category: 'supplement_calcium', baseGramsFor10kgPetPerDay: 4, notes: 'Calcio' }
    ],
    instructions: [
      'Cocinar el salmón al vapor 12 minutos desmenuzando con tenedor.',
      'Cocer el arroz integral 25 minutos y el brócoli 8 minutos.',
      'Mezclar todo con el aceite de salmón y la cáscara de huevo.'
    ],
    storageInfo: 'Nevera 48h, congelador 2 meses.',
    macronutrients: { proteinPct: 45, fatPct: 20, fiberCarbPct: 24, moisturePct: 76 }
  },
  {
    id: 'dog-adu-05',
    title: 'Conejo con Quinoa y Zanahoria para Perros Adultos',
    frenchTitle: 'Lapin Rôti au Quinoa & Carottes',
    species: 'dog',
    growthStage: 'adult',
    category: 'sensitive_digestion',
    categoryLabel: 'Carne Ligera & Energía Limpia',
    description: 'Guisar conejo 35 min, quinoa 15 min y zanahoria 15 min. Añadir aceite de salmón y cáscara de huevo al final.',
    kcalPer100g: 130,
    prepTimeMin: 15,
    cookTimeMin: 35,
    difficulty: 'Fácil',
    suitability: 'Perros adultos que sufren flatulencias o pesadez gástrica',
    clinicalBenefits: ['Carne blanca magra hipoalergénica', 'Quinoa con bajo índice glucémico', 'Zanahoria rica en carotenos'],
    ingredients: [
      { name: 'Carne de conejo deshuesada', category: 'protein', baseGramsFor10kgPetPerDay: 200, notes: 'Guisar 35 min' },
      { name: 'Quinoa cocida', category: 'fiber_carb', baseGramsFor10kgPetPerDay: 60, notes: 'Cocer 15 min' },
      { name: 'Zanahoria en rodajas', category: 'vegetable', baseGramsFor10kgPetPerDay: 45, notes: 'Cocer 15 min' },
      { name: 'Aceite de salmón', category: 'healthy_fat', baseGramsFor10kgPetPerDay: 4, notes: 'Añadir al final' },
      { name: 'Cáscara de huevo en polvo', category: 'supplement_calcium', baseGramsFor10kgPetPerDay: 4, notes: 'Calcio' }
    ],
    instructions: [
      'Guisar el conejo 35 minutos y asegurar eliminar cualquier hueso.',
      'Cocer la quinoa 15 minutos y la zanahoria 15 minutos.',
      'Mezclar todo agregando aceite de salmón y cáscara de huevo.'
    ],
    storageInfo: 'Nevera 3 días, congelador 2 meses.',
    macronutrients: { proteinPct: 48, fatPct: 15, fiberCarbPct: 24, moisturePct: 77 }
  },
  {
    id: 'dog-adu-06',
    title: 'Estofado de Cordero con Quinoa y Verduras Mediterráneas',
    frenchTitle: 'Ragoût d Agneau Méditerranéen au Quinoa',
    species: 'dog',
    growthStage: 'adult',
    category: 'vitality_gourmet',
    categoryLabel: 'Alta Palatabilidad & Nutrición Completa',
    description: 'Estofar cordero 35 min, cocer quinoa 15 min y saltear o cocer verduras mediterráneas 10 min. Terminar con aceite de salmón, probióticos y cáscara de huevo.',
    kcalPer100g: 145,
    prepTimeMin: 15,
    cookTimeMin: 35,
    difficulty: 'Fácil',
    suitability: 'Perros adultos que disfrutan de sabores aromáticos y nutritivos',
    clinicalBenefits: ['Perfil lipídico rico en ácido oleico y L-carnitina', 'Verduras mediterráneas (calabacín, judía tierna) hidratantes', 'Refuerzo de microbiota'],
    ingredients: [
      { name: 'Cordero magro picado o guisado', category: 'protein', baseGramsFor10kgPetPerDay: 190, notes: 'Estofar 35 min' },
      { name: 'Quinoa cocida', category: 'fiber_carb', baseGramsFor10kgPetPerDay: 60, notes: 'Cocer 15 min' },
      { name: 'Verduras mediterráneas (calabacín y zanahoria)', category: 'vegetable', baseGramsFor10kgPetPerDay: 50, notes: 'Cocer 10 min' },
      { name: 'Aceite de salmón', category: 'healthy_fat', baseGramsFor10kgPetPerDay: 4, notes: 'Omega 3' },
      { name: 'Probióticos caninos', category: 'supplement_calcium', baseGramsFor10kgPetPerDay: 3, notes: 'Al templar' },
      { name: 'Cáscara de huevo molida', category: 'supplement_calcium', baseGramsFor10kgPetPerDay: 4, notes: 'Calcio' }
    ],
    instructions: [
      'Estofar el cordero 35 minutos a fuego suave.',
      'Cocer la quinoa 15 minutos y las verduras 10 minutos.',
      'Mezclar todo y añadir el aceite de salmón, los probióticos y el calcio al templar.'
    ],
    storageInfo: 'Nevera 3 días, congelador 2 meses.',
    macronutrients: { proteinPct: 48, fatPct: 18, fiberCarbPct: 23, moisturePct: 76 }
  },
  {
    id: 'dog-adu-07',
    title: 'Pato con Batata y Manzana para Perros Adultos',
    frenchTitle: 'Canard Confit à la Patate Douce & Pommes Adulte',
    species: 'dog',
    growthStage: 'adult',
    category: 'vitality_gourmet',
    categoryLabel: 'Gourmet & Digestión Equilibrada',
    description: 'Cocinar pato 25 min, batata 20 min y manzana 5 min sin semillas. Añadir probióticos, aceite de linaza y cáscara de huevo al final.',
    kcalPer100g: 140,
    prepTimeMin: 15,
    cookTimeMin: 25,
    difficulty: 'Fácil',
    suitability: 'Perros adultos sibaritas o de apetito caprichoso',
    clinicalBenefits: ['Grasa de pato cardiosaludable rica en monoinsaturados', 'Fibra péctica suave', 'Aceite de linaza con lignanos protectores'],
    ingredients: [
      { name: 'Pato magro cocido o asado sin grasa excedente', category: 'protein', baseGramsFor10kgPetPerDay: 190, notes: 'Cocinar 25 min' },
      { name: 'Batata cocida pelada', category: 'fiber_carb', baseGramsFor10kgPetPerDay: 65, notes: 'Cocer 20 min' },
      { name: 'Manzana pelada y sin semillas', category: 'vegetable', baseGramsFor10kgPetPerDay: 40, notes: 'Cocer 5 min' },
      { name: 'Aceite de linaza', category: 'healthy_fat', baseGramsFor10kgPetPerDay: 4, notes: 'En crudo' },
      { name: 'Probióticos caninos', category: 'supplement_calcium', baseGramsFor10kgPetPerDay: 3, notes: 'Al final' },
      { name: 'Cáscara de huevo molida', category: 'supplement_calcium', baseGramsFor10kgPetPerDay: 4, notes: 'Calcio' }
    ],
    instructions: [
      'Cocinar el pato 25 minutos desgrasando el jugo.',
      'Cocer la batata 20 minutos y la manzana 5 minutos.',
      'Unir todo machacando y agregar el aceite de linaza, los probióticos y el calcio al templar.'
    ],
    storageInfo: 'Nevera 3 días, congelador 2 meses.',
    macronutrients: { proteinPct: 46, fatPct: 19, fiberCarbPct: 24, moisturePct: 76 }
  },
  {
    id: 'dog-adu-08',
    title: 'Bacalao con Calabaza y Zanahoria para Perros Adultos',
    frenchTitle: 'Cabillaud Léger au Potiron & Carottes Adulte',
    species: 'dog',
    growthStage: 'adult',
    category: 'sensitive_digestion',
    categoryLabel: 'Dieta Depurativa & Hipoalergénica',
    description: 'Cocer bacalao 10 min, calabaza 15 min y zanahoria 15 min. Mezclar con omega 3 y cáscara de huevo cuando esté templado.',
    kcalPer100g: 110,
    prepTimeMin: 10,
    cookTimeMin: 15,
    difficulty: 'Fácil',
    suitability: 'Perros adultos en detox digestivo o tras comidas pesadas',
    clinicalBenefits: ['Digestión en menos de 2 horas sin pesadez', 'Ayuda a regular deposiciones', 'Pescado blanco muy limpio'],
    ingredients: [
      { name: 'Bacalao desalado fresco sin espinas', category: 'protein', baseGramsFor10kgPetPerDay: 220, notes: 'Cocer 10 min' },
      { name: 'Calabaza cocida', category: 'vegetable', baseGramsFor10kgPetPerDay: 60, notes: 'Cocer 15 min' },
      { name: 'Zanahoria cocida', category: 'vegetable', baseGramsFor10kgPetPerDay: 50, notes: 'Cocer 15 min' },
      { name: 'Aceite de pescado Omega 3', category: 'healthy_fat', baseGramsFor10kgPetPerDay: 4, notes: 'Añadir templado' },
      { name: 'Cáscara de huevo molida', category: 'supplement_calcium', baseGramsFor10kgPetPerDay: 4, notes: 'Calcio' }
    ],
    instructions: [
      'Hervir el bacalao 10 minutos y revisar espinas.',
      'Cocer la calabaza y la zanahoria 15 minutos.',
      'Mezclar todo con el aceite omega 3 y la cáscara de huevo en templado.'
    ],
    storageInfo: 'Consumir en 48 horas.',
    macronutrients: { proteinPct: 48, fatPct: 12, fiberCarbPct: 22, moisturePct: 81 }
  },
  {
    id: 'dog-adu-09',
    title: 'Trucha con Arroz Salvaje y Espinaca para Perros Adultos',
    frenchTitle: 'Truite Dorée au Riz Sauvage & Épinards Adulte',
    species: 'dog',
    growthStage: 'adult',
    category: 'joint_omega3',
    categoryLabel: 'Antioxidantes & Longevidad Muscular',
    description: 'Cocinar trucha 12 min, arroz salvaje 35 min y espinaca 5 min. Añadir aceite de salmón, probióticos y cáscara de huevo.',
    kcalPer100g: 130,
    prepTimeMin: 15,
    cookTimeMin: 35,
    difficulty: 'Fácil',
    suitability: 'Perros adultos que necesitan mantener su peso con excelente vitalidad',
    clinicalBenefits: ['Baja grasa saturada con alto contenido en EPA y DHA', 'Espinaca rica en luteína para la vista', 'Probióticos'],
    ingredients: [
      { name: 'Trucha de río sin espinas', category: 'protein', baseGramsFor10kgPetPerDay: 200, notes: 'Cocinar 12 min' },
      { name: 'Arroz salvaje cocido', category: 'fiber_carb', baseGramsFor10kgPetPerDay: 60, notes: 'Cocer 35 min' },
      { name: 'Espinacas tiernas', category: 'vegetable', baseGramsFor10kgPetPerDay: 40, notes: 'Escaldar 5 min' },
      { name: 'Aceite de salmón', category: 'healthy_fat', baseGramsFor10kgPetPerDay: 4, notes: 'Omega 3' },
      { name: 'Probióticos caninos', category: 'supplement_calcium', baseGramsFor10kgPetPerDay: 3, notes: 'Al templar' },
      { name: 'Cáscara de huevo en polvo', category: 'supplement_calcium', baseGramsFor10kgPetPerDay: 4, notes: 'Calcio' }
    ],
    instructions: [
      'Cocer el arroz salvaje 35 minutos.',
      'Cocinar la trucha 12 minutos al vapor o plancha y desmigar verificando espinas.',
      'Escaldar las espinacas 5 minutos.',
      'Mezclar todo y agregar aceite de salmón, probióticos y calcio en templado.'
    ],
    storageInfo: 'Nevera 48h, congelador 2 meses.',
    macronutrients: { proteinPct: 46, fatPct: 16, fiberCarbPct: 25, moisturePct: 78 }
  },
  {
    id: 'dog-adu-10',
    title: 'Sardinas con Boniato y Calabacín para Perros Adultos',
    frenchTitle: 'Sardines & Patate Douce au Courgettes Adulte',
    species: 'dog',
    growthStage: 'adult',
    category: 'joint_omega3',
    categoryLabel: 'Protección Cardiovascular & Articular',
    description: 'Cocer sardinas 8 min, boniato 20 min y calabacín 10 min. Terminar con omega 3, aceite de linaza y cáscara de huevo.',
    kcalPer100g: 135,
    prepTimeMin: 15,
    cookTimeMin: 20,
    difficulty: 'Fácil',
    suitability: 'Perros adultos que sufren rigidez matutina o inflamación dérmica',
    clinicalBenefits: ['Ácidos grasos antiinflamatorios directos para articulaciones', 'Vitamina D y fósforo orgánico bioequilibrado', 'Pescado pequeño seguro'],
    ingredients: [
      { name: 'Sardinas frescas limpias sin espina gruesa', category: 'protein', baseGramsFor10kgPetPerDay: 190, notes: 'Cocer 8 min' },
      { name: 'Boniato cocido', category: 'fiber_carb', baseGramsFor10kgPetPerDay: 65, notes: 'Cocer 20 min' },
      { name: 'Calabacín tierno', category: 'vegetable', baseGramsFor10kgPetPerDay: 45, notes: 'Cocer 10 min' },
      { name: 'Aceite de linaza', category: 'healthy_fat', baseGramsFor10kgPetPerDay: 3, notes: 'En crudo' },
      { name: 'Aceite omega 3', category: 'healthy_fat', baseGramsFor10kgPetPerDay: 3, notes: 'Al final' },
      { name: 'Cáscara de huevo molida', category: 'supplement_calcium', baseGramsFor10kgPetPerDay: 4, notes: 'Calcio' }
    ],
    instructions: [
      'Cocer el boniato 20 minutos y el calabacín 10 minutos.',
      'Cocer las sardinas 8 minutos en agua hirviendo y desmigar con tenedor.',
      'Mezclar e incorporar los aceites de linaza y omega 3 con la cáscara de huevo.'
    ],
    storageInfo: 'Nevera 48 horas.',
    macronutrients: { proteinPct: 47, fatPct: 18, fiberCarbPct: 23, moisturePct: 77 }
  },
  {
    id: 'dog-adu-11',
    title: 'Pollo con Hígado y Arroz para Perros Adultos',
    frenchTitle: 'Poulet & Foie au Riz Parfumé Adulte',
    species: 'dog',
    growthStage: 'adult',
    category: 'vitality_gourmet',
    categoryLabel: 'Complejo B & Vigor Natural',
    description: 'Cocer pollo 20 min, hígado 7 min y arroz 18 min. Añadir probióticos, cáscara de huevo y dejar templar antes de servir.',
    kcalPer100g: 135,
    prepTimeMin: 15,
    cookTimeMin: 20,
    difficulty: 'Fácil',
    suitability: 'Perros adultos que necesitan estímulo de apetito y energía limpia',
    clinicalBenefits: ['Hígado como multivitamínico natural concentrado', 'Arroz blanco de rápida asimilación', 'Probióticos'],
    ingredients: [
      { name: 'Pechuga de pollo', category: 'protein', baseGramsFor10kgPetPerDay: 180, notes: 'Cocer 20 min' },
      { name: 'Hígado de pollo fresco', category: 'protein', baseGramsFor10kgPetPerDay: 20, notes: 'Cocer 7 min' },
      { name: 'Arroz blanco cocido', category: 'fiber_carb', baseGramsFor10kgPetPerDay: 70, notes: 'Cocer 18 min' },
      { name: 'Probióticos caninos', category: 'supplement_calcium', baseGramsFor10kgPetPerDay: 3, notes: 'Al templar' },
      { name: 'Cáscara de huevo en polvo', category: 'supplement_calcium', baseGramsFor10kgPetPerDay: 4, notes: 'Calcio' }
    ],
    instructions: [
      'Cocer el pollo 20 minutos añadiendo el hígado en los últimos 7 minutos.',
      'Cocer el arroz 18 minutos.',
      'Trocear las carnes, unir al arroz y añadir probióticos y cáscara de huevo al templar.'
    ],
    storageInfo: 'Nevera 3 días, congelador 2 meses.',
    macronutrients: { proteinPct: 50, fatPct: 15, fiberCarbPct: 24, moisturePct: 76 }
  },
  {
    id: 'dog-adu-12',
    title: 'Pavo con Corazón y Calabaza para Perros Adultos',
    frenchTitle: 'Dinde & Cœur Musculaire au Potiron Adulte',
    species: 'dog',
    growthStage: 'adult',
    category: 'vitality_gourmet',
    categoryLabel: 'Taurina & Salud Miocárdica',
    description: 'Hervir pavo y corazón 25 min y calabaza 15 min. Incorporar aceite de salmón, probióticos y cáscara de huevo al final.',
    kcalPer100g: 130,
    prepTimeMin: 15,
    cookTimeMin: 25,
    difficulty: 'Fácil',
    suitability: 'Perros adultos de razas medianas y grandes con predisposición cardiaca',
    clinicalBenefits: ['El corazón aporta taurina natural y L-carnitina para el músculo cardíaco', 'Calabaza para regular tránsito', 'Probióticos'],
    ingredients: [
      { name: 'Carne magra de pavo', category: 'protein', baseGramsFor10kgPetPerDay: 170, notes: 'Hervir 25 min' },
      { name: 'Corazón de pavo o vacuno limpio', category: 'protein', baseGramsFor10kgPetPerDay: 30, notes: 'Hervir 25 min' },
      { name: 'Calabaza cocida', category: 'vegetable', baseGramsFor10kgPetPerDay: 60, notes: 'Hervir 15 min' },
      { name: 'Aceite de salmón', category: 'healthy_fat', baseGramsFor10kgPetPerDay: 4, notes: 'Omega 3' },
      { name: 'Probióticos caninos', category: 'supplement_calcium', baseGramsFor10kgPetPerDay: 3, notes: 'Al templar' },
      { name: 'Cáscara de huevo molida', category: 'supplement_calcium', baseGramsFor10kgPetPerDay: 4, notes: 'Calcio' }
    ],
    instructions: [
      'Hervir el pavo y el corazón juntos 25 minutos.',
      'Cocer la calabaza 15 minutos y machacar con tenedor.',
      'Integrar todo y suplementar con aceite de salmón, probióticos y cáscara de huevo.'
    ],
    storageInfo: 'Nevera 3 días, congelador 2 meses.',
    macronutrients: { proteinPct: 51, fatPct: 16, fiberCarbPct: 20, moisturePct: 77 }
  },
  {
    id: 'dog-adu-13',
    title: 'Merluza con Patata y Calabacín para Perros Adultos',
    frenchTitle: 'Colin Fin aux Pommes de Terre & Courgettes Adulte',
    species: 'dog',
    growthStage: 'adult',
    category: 'sensitive_digestion',
    categoryLabel: 'Ultra Digestible & Pelaje Brillante',
    description: 'Cocer merluza 12 min, patata 20 min y calabacín 10 min. Añadir omega 3, aceite de linaza y cáscara de huevo al servir.',
    kcalPer100g: 115,
    prepTimeMin: 15,
    cookTimeMin: 20,
    difficulty: 'Fácil',
    suitability: 'Perros adultos que necesitan una dieta ligera y de digestión sin esfuerzo',
    clinicalBenefits: ['Pescado blanco bajo en grasa', 'Aceite de linaza rico en ALA', 'Patata como hidrato de carbono limpio'],
    ingredients: [
      { name: 'Lomos de merluza sin espinas', category: 'protein', baseGramsFor10kgPetPerDay: 220, notes: 'Cocer 12 min' },
      { name: 'Patata cocida sin piel', category: 'fiber_carb', baseGramsFor10kgPetPerDay: 70, notes: 'Cocer 20 min' },
      { name: 'Calabacín en dados', category: 'vegetable', baseGramsFor10kgPetPerDay: 45, notes: 'Cocer 10 min' },
      { name: 'Aceite de linaza', category: 'healthy_fat', baseGramsFor10kgPetPerDay: 3, notes: 'En crudo' },
      { name: 'Aceite de salmón / Omega 3', category: 'healthy_fat', baseGramsFor10kgPetPerDay: 3, notes: 'Al servir' },
      { name: 'Cáscara de huevo molida', category: 'supplement_calcium', baseGramsFor10kgPetPerDay: 4, notes: 'Calcio' }
    ],
    instructions: [
      'Cocer la patata 20 minutos y el calabacín 10 minutos.',
      'Cocer la merluza 12 minutos y revisar con las manos que no queden espinas.',
      'Mezclar todo y aderezar con los aceites y el calcio al momento de servir.'
    ],
    storageInfo: 'Consumir en 48 horas.',
    macronutrients: { proteinPct: 45, fatPct: 14, fiberCarbPct: 24, moisturePct: 80 }
  },
  {
    id: 'dog-adu-14',
    title: 'Ternera Molida con Verduras para Perros Adultos',
    frenchTitle: 'Haché de Bœuf aux Petits Légumes Tendres Adulte',
    species: 'dog',
    growthStage: 'adult',
    category: 'vitality_gourmet',
    categoryLabel: 'Articulaciones & Vitalidad Canina',
    description: 'Cocinar la ternera molida 12 min y las verduras suaves 10 min. Mezclar con cáscara de huevo, glucosamina y un poco de aceite de salmón.',
    kcalPer100g: 140,
    prepTimeMin: 10,
    cookTimeMin: 15,
    difficulty: 'Fácil',
    suitability: 'Perros adultos que disfrutan de textura picada y necesitan soporte de cartílagos',
    clinicalBenefits: ['Glucosamina para mantenimiento del líquido sinovial', 'Ternera magra rica en creatina natural', 'Aceite de salmón antiinflamatorio'],
    ingredients: [
      { name: 'Carne picada magra de ternera', category: 'protein', baseGramsFor10kgPetPerDay: 190, notes: 'Cocinar 12 min' },
      { name: 'Verduras suaves (zanahoria y calabacín picados)', category: 'vegetable', baseGramsFor10kgPetPerDay: 60, notes: 'Cocer 10 min' },
      { name: 'Glucosamina canina', category: 'supplement_calcium', baseGramsFor10kgPetPerDay: 2, notes: 'Condroprotector' },
      { name: 'Aceite de salmón', category: 'healthy_fat', baseGramsFor10kgPetPerDay: 4, notes: 'Omega 3' },
      { name: 'Cáscara de huevo molida', category: 'supplement_calcium', baseGramsFor10kgPetPerDay: 4, notes: 'Calcio' }
    ],
    instructions: [
      'Cocinar la ternera molida 12 minutos sin aceite.',
      'Cocer las verduras 10 minutos y picar bien fino.',
      'Mezclar carnes y verduras y añadir la glucosamina, el aceite de salmón y la cáscara de huevo.'
    ],
    storageInfo: 'Nevera 3 días, congelador 2 meses.',
    macronutrients: { proteinPct: 51, fatPct: 18, fiberCarbPct: 18, moisturePct: 76 }
  },
  {
    id: 'dog-adu-15',
    title: 'Salmón con Calabaza y Zanahoria para Perros Adultos',
    frenchTitle: 'Saumon au Four Potiron & Carottes Adulte',
    species: 'dog',
    growthStage: 'adult',
    category: 'joint_omega3',
    categoryLabel: 'Doble Caroteno & Ácidos Grasos Esenciales',
    description: 'Hornear o cocer el salmón 12 min, calabaza 15 min y zanahoria 15 min. Terminar con omega 3, probióticos y cáscara de huevo.',
    kcalPer100g: 135,
    prepTimeMin: 15,
    cookTimeMin: 15,
    difficulty: 'Fácil',
    suitability: 'Perros adultos que necesitan una dieta rica en ácidos grasos poliinsaturados',
    clinicalBenefits: ['Doble fuente vegetal de provitamina A para mucosas y visión', 'Omega-3 que protege las membranas celulares', 'Probióticos'],
    ingredients: [
      { name: 'Lomo de salmón limpio de espinas', category: 'protein', baseGramsFor10kgPetPerDay: 200, notes: 'Hornear 12 min' },
      { name: 'Calabaza en dados', category: 'vegetable', baseGramsFor10kgPetPerDay: 50, notes: 'Cocer 15 min' },
      { name: 'Zanahoria en dados', category: 'vegetable', baseGramsFor10kgPetPerDay: 50, notes: 'Cocer 15 min' },
      { name: 'Aceite de salmón / Omega 3', category: 'healthy_fat', baseGramsFor10kgPetPerDay: 4, notes: 'Al templar' },
      { name: 'Probióticos caninos', category: 'supplement_calcium', baseGramsFor10kgPetPerDay: 3, notes: 'Al servir' },
      { name: 'Cáscara de huevo molida', category: 'supplement_calcium', baseGramsFor10kgPetPerDay: 4, notes: 'Calcio' }
    ],
    instructions: [
      'Hornear o cocer el salmón 12 minutos asegurando retirar cualquier espina.',
      'Cocer la calabaza y la zanahoria juntas 15 minutos.',
      'Desmigar el pescado, unir a las verduras e incorporar el aceite, probióticos y calcio al templar.'
    ],
    storageInfo: 'Nevera 48h, congelador 2 meses.',
    macronutrients: { proteinPct: 45, fatPct: 19, fiberCarbPct: 22, moisturePct: 77 }
  },
  {
    id: 'dog-adu-16',
    title: 'Conejo con Arroz Integral y Verduras para Perros Adultos',
    frenchTitle: 'Lapin Rissolé au Riz Complet & Légumes Adulte',
    species: 'dog',
    growthStage: 'adult',
    category: 'sensitive_digestion',
    categoryLabel: 'Fibra Insoluble & Digestión Fácil',
    description: 'Cocer conejo 35 min, arroz integral 25 min y verduras suaves 10 min. Añadir aceite de salmón, probióticos y cáscara de huevo al final.',
    kcalPer100g: 130,
    prepTimeMin: 15,
    cookTimeMin: 35,
    difficulty: 'Fácil',
    suitability: 'Perros adultos que se benefician de fuentes cárnicas no convencionales',
    clinicalBenefits: ['Proteína novedosa hipoalergénica', 'Fibra dietética del arroz integral para evacuaciones sanas', 'Probióticos'],
    ingredients: [
      { name: 'Carne de conejo deshuesada', category: 'protein', baseGramsFor10kgPetPerDay: 200, notes: 'Cocer 35 min' },
      { name: 'Arroz integral cocido', category: 'fiber_carb', baseGramsFor10kgPetPerDay: 60, notes: 'Cocer 25 min' },
      { name: 'Verduras suaves (calabacín y zanahoria)', category: 'vegetable', baseGramsFor10kgPetPerDay: 45, notes: 'Cocer 10 min' },
      { name: 'Aceite de salmón', category: 'healthy_fat', baseGramsFor10kgPetPerDay: 4, notes: 'Omega 3' },
      { name: 'Probióticos caninos', category: 'supplement_calcium', baseGramsFor10kgPetPerDay: 3, notes: 'Al templar' },
      { name: 'Cáscara de huevo molida', category: 'supplement_calcium', baseGramsFor10kgPetPerDay: 4, notes: 'Calcio' }
    ],
    instructions: [
      'Cocer la carne de conejo 35 minutos y retirar meticulosamente cualquier hueso.',
      'Cocer el arroz integral 25 minutos y las verduras 10 minutos.',
      'Unir todo y agregar aceite de salmón, probióticos y cáscara de huevo al templar.'
    ],
    storageInfo: 'Nevera 3 días, congelador 2 meses.',
    macronutrients: { proteinPct: 48, fatPct: 15, fiberCarbPct: 24, moisturePct: 77 }
  },
  {
    id: 'dog-adu-17',
    title: 'Bacalao con Arroz Integral y Espinaca para Perros Adultos',
    frenchTitle: 'Cabillaud au Riz Complet & Feuilles d Épinards',
    species: 'dog',
    growthStage: 'adult',
    category: 'sensitive_digestion',
    categoryLabel: 'Pescado Blanco & Depuración',
    description: 'Bacalao al vapor 10 min, arroz integral 25 min y espinaca 5 min. Incorporar aceite de linaza y cáscara de huevo cuando esté templado.',
    kcalPer100g: 120,
    prepTimeMin: 15,
    cookTimeMin: 25,
    difficulty: 'Fácil',
    suitability: 'Perros adultos que necesitan una dieta suave y baja en grasa',
    clinicalBenefits: ['Mínimo colesterol y excelente digestibilidad', 'Aceite de linaza vegetal con lignanos', 'Espinaca rica en hierro'],
    ingredients: [
      { name: 'Bacalao fresco al vapor desespinado', category: 'protein', baseGramsFor10kgPetPerDay: 210, notes: 'Al vapor 10 min' },
      { name: 'Arroz integral cocido', category: 'fiber_carb', baseGramsFor10kgPetPerDay: 60, notes: 'Cocer 25 min' },
      { name: 'Espinacas frescas', category: 'vegetable', baseGramsFor10kgPetPerDay: 35, notes: 'Escaldar 5 min' },
      { name: 'Aceite de linaza', category: 'healthy_fat', baseGramsFor10kgPetPerDay: 4, notes: 'En crudo' },
      { name: 'Cáscara de huevo molida', category: 'supplement_calcium', baseGramsFor10kgPetPerDay: 4, notes: 'Calcio' }
    ],
    instructions: [
      'Cocer el arroz integral 25 minutos.',
      'Cocinar el bacalao al vapor 10 minutos y revisar espinas.',
      'Escaldar las espinacas 5 minutos.',
      'Mezclar e incorporar el aceite de linaza y la cáscara de huevo cuando esté templado.'
    ],
    storageInfo: 'Nevera 48h, congelador 2 meses.',
    macronutrients: { proteinPct: 47, fatPct: 13, fiberCarbPct: 25, moisturePct: 79 }
  },
  {
    id: 'dog-adu-18',
    title: 'Pato con Quinoa y Verduras para Perros Adultos',
    frenchTitle: 'Magret de Canard au Quinoa & Légumes Mixtes',
    species: 'dog',
    growthStage: 'adult',
    category: 'vitality_gourmet',
    categoryLabel: 'Alta Energía & Aminoácidos Completos',
    description: 'Hornear pato 40 min, cocer quinoa 15 min y verduras 10 min. Terminar con probióticos, aceite de salmón y cáscara de huevo.',
    kcalPer100g: 145,
    prepTimeMin: 15,
    cookTimeMin: 40,
    difficulty: 'Fácil',
    suitability: 'Perros adultos activos que realizan senderismo o ejercicio continuo',
    clinicalBenefits: ['Pato con hierro bioasimilable y sabor premium', 'Quinoa con bajo índice glucémico y sin gluten', 'Aceite de salmón'],
    ingredients: [
      { name: 'Carne magra de pato', category: 'protein', baseGramsFor10kgPetPerDay: 190, notes: 'Hornear 40 min' },
      { name: 'Quinoa cocida', category: 'fiber_carb', baseGramsFor10kgPetPerDay: 60, notes: 'Cocer 15 min' },
      { name: 'Verduras variadas (calabacín y zanahoria)', category: 'vegetable', baseGramsFor10kgPetPerDay: 45, notes: 'Cocer 10 min' },
      { name: 'Aceite de salmón', category: 'healthy_fat', baseGramsFor10kgPetPerDay: 4, notes: 'Omega 3' },
      { name: 'Probióticos caninos', category: 'supplement_calcium', baseGramsFor10kgPetPerDay: 3, notes: 'Al templar' },
      { name: 'Cáscara de huevo molida', category: 'supplement_calcium', baseGramsFor10kgPetPerDay: 4, notes: 'Calcio' }
    ],
    instructions: [
      'Hornear la carne de pato 40 minutos escurriendo el exceso de grasa.',
      'Cocer la quinoa 15 minutos y las verduras 10 minutos.',
      'Picar el pato, unir a la quinoa y verduras y agregar probióticos, aceite de salmón y calcio al templar.'
    ],
    storageInfo: 'Nevera 3 días, congelador 2 meses.',
    macronutrients: { proteinPct: 48, fatPct: 19, fiberCarbPct: 23, moisturePct: 76 }
  },
  {
    id: 'dog-adu-19',
    title: 'Cordero con Patata y Calabacín para Perros Adultos',
    frenchTitle: 'Agneau Roti aux Pommes de Terre & Courgettes',
    species: 'dog',
    growthStage: 'adult',
    category: 'vitality_gourmet',
    categoryLabel: 'Articulaciones & Condroprotección',
    description: 'Estofar cordero 35 min, patata 20 min y calabacín 10 min. Añadir aceite de linaza, glucosamina y cáscara de huevo al final.',
    kcalPer100g: 140,
    prepTimeMin: 15,
    cookTimeMin: 35,
    difficulty: 'Fácil',
    suitability: 'Perros adultos que necesitan cuidar cartílagos mientras mantienen musculatura',
    clinicalBenefits: ['Glucosamina de protección sinovial activa', 'Cordero rico en carnitina', 'Aceite de linaza antiinflamatorio'],
    ingredients: [
      { name: 'Carne magra de cordero', category: 'protein', baseGramsFor10kgPetPerDay: 190, notes: 'Estofar 35 min' },
      { name: 'Patata cocida sin piel', category: 'fiber_carb', baseGramsFor10kgPetPerDay: 65, notes: 'Cocer 20 min' },
      { name: 'Calabacín en dados', category: 'vegetable', baseGramsFor10kgPetPerDay: 45, notes: 'Cocer 10 min' },
      { name: 'Glucosamina canina', category: 'supplement_calcium', baseGramsFor10kgPetPerDay: 2, notes: 'Protector articular' },
      { name: 'Aceite de linaza', category: 'healthy_fat', baseGramsFor10kgPetPerDay: 4, notes: 'En crudo' },
      { name: 'Cáscara de huevo molida', category: 'supplement_calcium', baseGramsFor10kgPetPerDay: 4, notes: 'Calcio' }
    ],
    instructions: [
      'Estofar el cordero 35 minutos desgrasando el caldo.',
      'Cocer la patata 20 min y el calabacín 10 min.',
      'Mezclar y aderezar con glucosamina, aceite de linaza y cáscara de huevo.'
    ],
    storageInfo: 'Nevera 3 días, congelador 2 meses.',
    macronutrients: { proteinPct: 48, fatPct: 18, fiberCarbPct: 23, moisturePct: 76 }
  },
  {
    id: 'dog-adu-20',
    title: 'Trucha con Boniato y Espinaca para Perros Adultos',
    frenchTitle: 'Truite Sauvage à la Patate Douce & Épinards Adulte',
    species: 'dog',
    growthStage: 'adult',
    category: 'joint_omega3',
    categoryLabel: 'Omega 3 Fresco & Probióticos',
    description: 'Trucha al vapor 12 min, boniato 20 min y espinaca 5 min. Suplementar con omega 3, probióticos y cáscara de huevo.',
    kcalPer100g: 130,
    prepTimeMin: 15,
    cookTimeMin: 20,
    difficulty: 'Fácil',
    suitability: 'Perros adultos que alternan entre carne y pescado para máxima diversidad',
    clinicalBenefits: ['Excelente ratio EPA/DHA de agua dulce', 'Boniato con betacarotenos protectores celulares', 'Probióticos'],
    ingredients: [
      { name: 'Trucha fresca al vapor sin espinas', category: 'protein', baseGramsFor10kgPetPerDay: 200, notes: 'Al vapor 12 min' },
      { name: 'Boniato cocido', category: 'fiber_carb', baseGramsFor10kgPetPerDay: 65, notes: 'Cocer 20 min' },
      { name: 'Espinacas escaldadas', category: 'vegetable', baseGramsFor10kgPetPerDay: 35, notes: 'Escaldar 5 min' },
      { name: 'Aceite de salmón / Omega 3', category: 'healthy_fat', baseGramsFor10kgPetPerDay: 4, notes: 'Omega 3' },
      { name: 'Probióticos caninos', category: 'supplement_calcium', baseGramsFor10kgPetPerDay: 3, notes: 'Al templar' },
      { name: 'Cáscara de huevo en polvo', category: 'supplement_calcium', baseGramsFor10kgPetPerDay: 4, notes: 'Calcio' }
    ],
    instructions: [
      'Cocinar la trucha al vapor 12 minutos desmigando minuciosamente sin espinas.',
      'Hervir el boniato 20 minutos y escaldar las espinacas 5 minutos.',
      'Mezclar con omega 3, probióticos y cáscara de huevo al templar.'
    ],
    storageInfo: 'Nevera 48h, congelador 2 meses.',
    macronutrients: { proteinPct: 46, fatPct: 17, fiberCarbPct: 24, moisturePct: 77 }
  },
  {
    id: 'dog-adu-21',
    title: 'Codorniz con Quinoa y Zanahoria para Perros Adultos ⭐',
    frenchTitle: 'Caille Rôtie au Quinoa Doré & Carottes Adulte',
    species: 'dog',
    growthStage: 'adult',
    category: 'vitality_gourmet',
    categoryLabel: 'Receta Premium Caza Suave',
    description: 'Premium. Hornear codorniz 25 min, cocer quinoa 15 min y zanahoria 15 min. Añadir aceite de salmón, cáscara de huevo y dejar templar antes de servir.',
    kcalPer100g: 140,
    prepTimeMin: 15,
    cookTimeMin: 25,
    difficulty: 'Media',
    suitability: 'Perros adultos que necesitan una proteína selecta y muy digestible',
    clinicalBenefits: ['Carne de caza blanca con micronutrientes intactos', 'Quinoa con todos los aminoácidos', 'Excelente apetencia'],
    ingredients: [
      { name: 'Carne de codorniz deshuesada', category: 'protein', baseGramsFor10kgPetPerDay: 190, notes: 'Hornear 25 min' },
      { name: 'Quinoa cocida', category: 'fiber_carb', baseGramsFor10kgPetPerDay: 60, notes: 'Cocer 15 min' },
      { name: 'Zanahoria cocida', category: 'vegetable', baseGramsFor10kgPetPerDay: 45, notes: 'Cocer 15 min' },
      { name: 'Aceite de salmón', category: 'healthy_fat', baseGramsFor10kgPetPerDay: 4, notes: 'Omega 3' },
      { name: 'Cáscara de huevo molida', category: 'supplement_calcium', baseGramsFor10kgPetPerDay: 4, notes: 'Calcio' }
    ],
    instructions: [
      'Hornear la codorniz 25 minutos y desmigar meticulosamente descartando huesos.',
      'Cocer la quinoa 15 minutos y la zanahoria 15 minutos.',
      'Integrar todo con el aceite de salmón y la cáscara de huevo molida.'
    ],
    storageInfo: 'Nevera 3 días, congelador 2 meses.',
    macronutrients: { proteinPct: 50, fatPct: 17, fiberCarbPct: 23, moisturePct: 76 }
  },
  {
    id: 'dog-adu-22',
    title: 'Faisán con Boniato y Espinaca para Perros Adultos ⭐',
    frenchTitle: 'Faisan Fermier à la Patate Douce & Épinards Adulte',
    species: 'dog',
    growthStage: 'adult',
    category: 'vitality_gourmet',
    categoryLabel: 'Receta Premium Regeneración Celular',
    description: 'Premium. Cocinar faisán 30 min, boniato 20 min y espinaca 5 min. Terminar con probióticos, aceite de linaza y cáscara de huevo.',
    kcalPer100g: 140,
    prepTimeMin: 15,
    cookTimeMin: 30,
    difficulty: 'Media',
    suitability: 'Perros adultos que requieren una dieta antiinflamatoria de alta gama',
    clinicalBenefits: ['Ave de caza magra con bajo perfil alérgico', 'Boniato para soporte glucídico estable', 'Probióticos y linaza'],
    ingredients: [
      { name: 'Carne de faisán deshuesada', category: 'protein', baseGramsFor10kgPetPerDay: 190, notes: 'Cocinar 30 min' },
      { name: 'Boniato cocido', category: 'fiber_carb', baseGramsFor10kgPetPerDay: 65, notes: 'Cocer 20 min' },
      { name: 'Espinacas tiernas', category: 'vegetable', baseGramsFor10kgPetPerDay: 35, notes: 'Escaldar 5 min' },
      { name: 'Aceite de linaza', category: 'healthy_fat', baseGramsFor10kgPetPerDay: 4, notes: 'En crudo' },
      { name: 'Probióticos caninos', category: 'supplement_calcium', baseGramsFor10kgPetPerDay: 3, notes: 'Al templar' },
      { name: 'Cáscara de huevo en polvo', category: 'supplement_calcium', baseGramsFor10kgPetPerDay: 4, notes: 'Calcio' }
    ],
    instructions: [
      'Cocinar el faisán 30 minutos revisando huesos.',
      'Cocer el boniato 20 minutos y la espinaca los últimos 5 minutos.',
      'Mezclar e incorporar probióticos, aceite de linaza y cáscara de huevo al templar.'
    ],
    storageInfo: 'Nevera 3 días, congelador 2 meses.',
    macronutrients: { proteinPct: 49, fatPct: 16, fiberCarbPct: 24, moisturePct: 77 }
  },
  {
    id: 'dog-adu-23',
    title: 'Caballa con Arroz Integral y Calabacín para Perros Adultos ⭐',
    frenchTitle: 'Maquereau de Mer au Riz Complet & Courgettes Adulte',
    species: 'dog',
    growthStage: 'adult',
    category: 'joint_omega3',
    categoryLabel: 'Receta Premium Digestión Amable & Omega 3',
    description: 'Premium. Caballa al vapor 12 min, arroz integral 25 min y calabacín 10 min. Añadir omega 3, probióticos y cáscara de huevo al final.',
    kcalPer100g: 145,
    prepTimeMin: 15,
    cookTimeMin: 25,
    difficulty: 'Fácil',
    suitability: 'Perros adultos que buscan vitalidad y pelaje sedoso',
    clinicalBenefits: ['Pescado azul silvestre rico en EPA/DHA de máxima pureza', 'Calabacín hidratante con potasio', 'Probióticos'],
    ingredients: [
      { name: 'Filetes de caballa fresca al vapor', category: 'protein', baseGramsFor10kgPetPerDay: 190, notes: 'Al vapor 12 min' },
      { name: 'Arroz integral cocido', category: 'fiber_carb', baseGramsFor10kgPetPerDay: 60, notes: 'Cocer 25 min' },
      { name: 'Calabacín en dados', category: 'vegetable', baseGramsFor10kgPetPerDay: 45, notes: 'Cocer 10 min' },
      { name: 'Aceite de salmón / Omega 3', category: 'healthy_fat', baseGramsFor10kgPetPerDay: 3, notes: 'Al final' },
      { name: 'Probióticos caninos', category: 'supplement_calcium', baseGramsFor10kgPetPerDay: 3, notes: 'Al templar' },
      { name: 'Cáscara de huevo en polvo', category: 'supplement_calcium', baseGramsFor10kgPetPerDay: 4, notes: 'Calcio' }
    ],
    instructions: [
      'Cocinar la caballa al vapor 12 minutos desmigando sin espinas.',
      'Cocer el arroz integral 25 minutos y el calabacín 10 minutos.',
      'Mezclar todo con el omega 3, probióticos y calcio en polvo.'
    ],
    storageInfo: 'Nevera 48h, congelador 2 meses.',
    macronutrients: { proteinPct: 47, fatPct: 20, fiberCarbPct: 22, moisturePct: 76 }
  },
  {
    id: 'dog-adu-24',
    title: 'Trucha con Quinoa Roja y Verduras para Perros Adultos ⭐',
    frenchTitle: 'Truite au Quinoa Rouge & Légumes du Marché Adulte',
    species: 'dog',
    growthStage: 'adult',
    category: 'joint_omega3',
    categoryLabel: 'Receta Premium Antioxidante Celular',
    description: 'Premium. Trucha 12 min, quinoa roja 18 min y verduras suaves 10 min. Incorporar aceite de salmón, cáscara de huevo y servir templado.',
    kcalPer100g: 135,
    prepTimeMin: 15,
    cookTimeMin: 18,
    difficulty: 'Fácil',
    suitability: 'Perros adultos que viven en ciudades y necesitan protección antioxidante',
    clinicalBenefits: ['Quinoa roja rica en bioflavonoides protectores', 'Pescado de río con bajo contenido en mercurio', 'Omega 3 marino'],
    ingredients: [
      { name: 'Trucha fresca limpia sin espinas', category: 'protein', baseGramsFor10kgPetPerDay: 200, notes: 'Cocer 12 min' },
      { name: 'Quinoa roja cocida', category: 'fiber_carb', baseGramsFor10kgPetPerDay: 60, notes: 'Cocer 18 min' },
      { name: 'Verduras suaves (zanahoria y calabaza)', category: 'vegetable', baseGramsFor10kgPetPerDay: 45, notes: 'Cocer 10 min' },
      { name: 'Aceite de salmón', category: 'healthy_fat', baseGramsFor10kgPetPerDay: 4, notes: 'Omega 3' },
      { name: 'Cáscara de huevo en polvo', category: 'supplement_calcium', baseGramsFor10kgPetPerDay: 4, notes: 'Calcio' }
    ],
    instructions: [
      'Cocer la quinoa roja 18 minutos y las verduras suaves 10 minutos.',
      'Cocinar la trucha 12 minutos y revisar minuciosamente espinas.',
      'Mezclar todo agregando el aceite de salmón y la cáscara de huevo al servir templado.'
    ],
    storageInfo: 'Nevera 48h, congelador 2 meses.',
    macronutrients: { proteinPct: 46, fatPct: 18, fiberCarbPct: 24, moisturePct: 77 }
  },
  {
    id: 'dog-adu-25',
    title: 'Pato con Batata Morada y Manzana para Perros Adultos ⭐',
    frenchTitle: 'Magret de Canard Patate Violette & Pommes Adulte',
    species: 'dog',
    growthStage: 'adult',
    category: 'vitality_gourmet',
    categoryLabel: 'Receta Premium Sabor & Energía Estable',
    description: 'Premium. Hornear pato 40 min, batata morada 25 min y manzana cocida 8 min. Añadir probióticos, aceite de salmón y cáscara de huevo.',
    kcalPer100g: 145,
    prepTimeMin: 15,
    cookTimeMin: 40,
    difficulty: 'Fácil',
    suitability: 'Perros adultos que valoran recetas aromáticas de alta gastronomía',
    clinicalBenefits: ['Batata morada con antocianinas protectoras cardiovasculares', 'Manzana con fibra soluble saciante', 'Probióticos'],
    ingredients: [
      { name: 'Carne magra de pato', category: 'protein', baseGramsFor10kgPetPerDay: 190, notes: 'Hornear 40 min' },
      { name: 'Batata morada cocida', category: 'fiber_carb', baseGramsFor10kgPetPerDay: 65, notes: 'Cocer 25 min' },
      { name: 'Manzana sin semillas cocida', category: 'vegetable', baseGramsFor10kgPetPerDay: 40, notes: 'Cocer 8 min' },
      { name: 'Aceite de salmón', category: 'healthy_fat', baseGramsFor10kgPetPerDay: 4, notes: 'Omega 3' },
      { name: 'Probióticos caninos', category: 'supplement_calcium', baseGramsFor10kgPetPerDay: 3, notes: 'Al templar' },
      { name: 'Cáscara de huevo molida', category: 'supplement_calcium', baseGramsFor10kgPetPerDay: 4, notes: 'Calcio' }
    ],
    instructions: [
      'Hornear el pato 40 minutos retirando grasa excedente.',
      'Cocer la batata morada 25 minutos y la manzana 8 minutos.',
      'Integrar y aderezar con probióticos, aceite de salmón y cáscara de huevo en templado.'
    ],
    storageInfo: 'Nevera 3 días, congelador 2 meses.',
    macronutrients: { proteinPct: 47, fatPct: 19, fiberCarbPct: 24, moisturePct: 76 }
  },
  {
    id: 'dog-adu-26',
    title: 'Conejo con Lenteja Roja y Verduras para Perros Adultos ⭐',
    frenchTitle: 'Lapin Braisé aux Lentilles Corail & Légumes Adulte',
    species: 'dog',
    growthStage: 'adult',
    category: 'sensitive_digestion',
    categoryLabel: 'Receta Premium Digestiones Ligeras',
    description: 'Premium. Cocer conejo 35 min, lenteja roja 15 min y verduras suaves 10 min. Terminar con aceite de linaza, glucosamina y cáscara de huevo.',
    kcalPer100g: 135,
    prepTimeMin: 15,
    cookTimeMin: 35,
    difficulty: 'Fácil',
    suitability: 'Perros adultos que sufren intolerancias a proteínas tradicionales',
    clinicalBenefits: ['Lenteja roja rica en hierro y fibra suave sin pellejo', 'Glucosamina de refuerzo cartilaginoso', 'Conejo magro digestivo'],
    ingredients: [
      { name: 'Carne de conejo deshuesada', category: 'protein', baseGramsFor10kgPetPerDay: 200, notes: 'Cocer 35 min' },
      { name: 'Lenteja roja cocida', category: 'fiber_carb', baseGramsFor10kgPetPerDay: 55, notes: 'Cocer 15 min' },
      { name: 'Verduras suaves (calabaza y judía verde)', category: 'vegetable', baseGramsFor10kgPetPerDay: 45, notes: 'Cocer 10 min' },
      { name: 'Glucosamina canina', category: 'supplement_calcium', baseGramsFor10kgPetPerDay: 2, notes: 'Protector articular' },
      { name: 'Aceite de linaza', category: 'healthy_fat', baseGramsFor10kgPetPerDay: 4, notes: 'En crudo' },
      { name: 'Cáscara de huevo molida', category: 'supplement_calcium', baseGramsFor10kgPetPerDay: 4, notes: 'Calcio' }
    ],
    instructions: [
      'Cocer el conejo 35 minutos y desmigar retirando cualquier hueso.',
      'Hervir la lenteja roja 15 minutos y las verduras 10 minutos.',
      'Mezclar todo con el aceite de linaza, la glucosamina y la cáscara de huevo.'
    ],
    storageInfo: 'Nevera 3 días, congelador 2 meses.',
    macronutrients: { proteinPct: 49, fatPct: 15, fiberCarbPct: 24, moisturePct: 77 }
  },
  {
    id: 'dog-adu-27',
    title: 'Salmón con Calabaza y Probióticos para Perros Adultos ⭐',
    frenchTitle: 'Saumon au Four Potimarron & Probiotiques Vivants Adulte',
    species: 'dog',
    growthStage: 'adult',
    category: 'joint_omega3',
    categoryLabel: 'Receta Premium Flora Intestinal & Articulaciones',
    description: 'Premium. Hornear salmón 12 min, calabaza 15 min y mezclar cuando esté templado. Añadir probióticos, omega 3 y cáscara de huevo.',
    kcalPer100g: 135,
    prepTimeMin: 15,
    cookTimeMin: 15,
    difficulty: 'Fácil',
    suitability: 'Perros adultos que necesitan reforzar defensas y mantener articulaciones flexibles',
    clinicalBenefits: ['Potente acción sinérgica de probióticos y omega-3', 'Calabaza como mucílago protector gástrico', 'Salmón sin espinas'],
    ingredients: [
      { name: 'Salmón fresco horneado sin espinas', category: 'protein', baseGramsFor10kgPetPerDay: 200, notes: 'Hornear 12 min' },
      { name: 'Calabaza cocida', category: 'vegetable', baseGramsFor10kgPetPerDay: 80, notes: 'Cocer 15 min' },
      { name: 'Aceite de salmón / Omega 3', category: 'healthy_fat', baseGramsFor10kgPetPerDay: 4, notes: 'Al templar' },
      { name: 'Probióticos caninos', category: 'supplement_calcium', baseGramsFor10kgPetPerDay: 3, notes: 'Al final' },
      { name: 'Cáscara de huevo en polvo', category: 'supplement_calcium', baseGramsFor10kgPetPerDay: 4, notes: 'Calcio' }
    ],
    instructions: [
      'Hornear el salmón 12 minutos y desmenuzar comprobando ausencia de espinas.',
      'Cocer la calabaza 15 minutos y aplastar en puré fino.',
      'Mezclar todo en templado y espolvorear los probióticos, omega 3 y cáscara de huevo.'
    ],
    storageInfo: 'Nevera 48h, congelador 2 meses.',
    macronutrients: { proteinPct: 45, fatPct: 19, fiberCarbPct: 22, moisturePct: 78 }
  },
  {
    id: 'dog-adu-28',
    title: 'Cordero con Boniato y Glucosamina para Perros Adultos ⭐',
    frenchTitle: 'Agneau Braisé au Boniato & Glucosamine Adulte',
    species: 'dog',
    growthStage: 'adult',
    category: 'joint_omega3',
    categoryLabel: 'Receta Premium Cuidado Articular Activo',
    description: 'Premium. Estofar cordero 35 min, boniato 20 min y cocer todo hasta tierno. Añadir glucosamina, aceite de salmón y cáscara de huevo.',
    kcalPer100g: 145,
    prepTimeMin: 15,
    cookTimeMin: 35,
    difficulty: 'Fácil',
    suitability: 'Perros adultos de razas grandes con tendencia a artrosis temprana',
    clinicalBenefits: ['Aporte directo de glucosamina condroitín sulfato', 'Cordero rico en aminoácidos para masa magra', 'Aceite de salmón antiinflamatorio'],
    ingredients: [
      { name: 'Carne magra de cordero', category: 'protein', baseGramsFor10kgPetPerDay: 190, notes: 'Estofar 35 min' },
      { name: 'Boniato cocido pelado', category: 'fiber_carb', baseGramsFor10kgPetPerDay: 70, notes: 'Cocer 20 min' },
      { name: 'Glucosamina canina', category: 'supplement_calcium', baseGramsFor10kgPetPerDay: 2, notes: 'Protector articular' },
      { name: 'Aceite de salmón', category: 'healthy_fat', baseGramsFor10kgPetPerDay: 4, notes: 'Omega 3' },
      { name: 'Cáscara de huevo molida', category: 'supplement_calcium', baseGramsFor10kgPetPerDay: 4, notes: 'Calcio' }
    ],
    instructions: [
      'Estofar el cordero 35 minutos hasta que esté muy tierno y desgrasado.',
      'Cocer el boniato 20 minutos y machacar con tenedor.',
      'Mezclar e integrar la glucosamina, el aceite de salmón y la cáscara de huevo molida.'
    ],
    storageInfo: 'Nevera 3 días, congelador 2 meses.',
    macronutrients: { proteinPct: 48, fatPct: 19, fiberCarbPct: 22, moisturePct: 76 }
  },
  {
    id: 'dog-adu-29',
    title: 'Bacalao con Arroz Germinado y Espinaca para Perros Adultos ⭐',
    frenchTitle: 'Cabillaud Vapeur au Riz Germé & Épinards Frais',
    species: 'dog',
    growthStage: 'adult',
    category: 'sensitive_digestion',
    categoryLabel: 'Receta Premium Microflora & Asimilación',
    description: 'Premium. Bacalao al vapor 10 min, arroz germinado 20 min y espinaca 5 min. Incorporar aceite de linaza, probióticos y cáscara de huevo.',
    kcalPer100g: 120,
    prepTimeMin: 15,
    cookTimeMin: 20,
    difficulty: 'Fácil',
    suitability: 'Perros adultos que requieren una dieta fácil de procesar y ligera',
    clinicalBenefits: ['Arroz germinado bioactivo con micronutrientes activados', 'Bacalao muy digestible', 'Probióticos y linaza'],
    ingredients: [
      { name: 'Bacalao fresco desespinado', category: 'protein', baseGramsFor10kgPetPerDay: 210, notes: 'Al vapor 10 min' },
      { name: 'Arroz germinado cocido', category: 'fiber_carb', baseGramsFor10kgPetPerDay: 60, notes: 'Cocer 20 min' },
      { name: 'Espinacas frescas escaldadas', category: 'vegetable', baseGramsFor10kgPetPerDay: 35, notes: 'Escaldar 5 min' },
      { name: 'Aceite de linaza', category: 'healthy_fat', baseGramsFor10kgPetPerDay: 4, notes: 'En crudo' },
      { name: 'Probióticos caninos', category: 'supplement_calcium', baseGramsFor10kgPetPerDay: 3, notes: 'Al templar' },
      { name: 'Cáscara de huevo en polvo', category: 'supplement_calcium', baseGramsFor10kgPetPerDay: 4, notes: 'Calcio' }
    ],
    instructions: [
      'Cocer el arroz germinado 20 minutos.',
      'Cocinar el bacalao al vapor 10 minutos y escaldar la espinaca 5 minutos.',
      'Mezclar todo con el aceite de linaza, probióticos y calcio en templado.'
    ],
    storageInfo: 'Nevera 48h, congelador 2 meses.',
    macronutrients: { proteinPct: 47, fatPct: 14, fiberCarbPct: 24, moisturePct: 80 }
  },
  {
    id: 'dog-adu-30',
    title: 'Pollo con Hígado y Quinoa para Perros Adultos ⭐',
    frenchTitle: 'Poule au Pot & Foie Doux au Quinoa Royal',
    species: 'dog',
    growthStage: 'adult',
    category: 'vitality_gourmet',
    categoryLabel: 'Receta Premium Nutrición Integral',
    description: 'Premium. Cocer pollo 20 min, hígado 7 min y quinoa 15 min. Añadir cáscara de huevo, probióticos y dejar templar antes de servir.',
    kcalPer100g: 140,
    prepTimeMin: 15,
    cookTimeMin: 20,
    difficulty: 'Fácil',
    suitability: 'Perros adultos que buscan vitalidad máxima, brillo en el pelaje y energía',
    clinicalBenefits: ['Equilibrio perfecto de aminoácidos, hierro, zinc y vitaminas B', 'Quinoa sin alérgenos', 'Probióticos'],
    ingredients: [
      { name: 'Pechuga de pollo', category: 'protein', baseGramsFor10kgPetPerDay: 180, notes: 'Cocer 20 min' },
      { name: 'Hígado de pollo fresco', category: 'protein', baseGramsFor10kgPetPerDay: 20, notes: 'Cocer 7 min' },
      { name: 'Quinoa cocida', category: 'fiber_carb', baseGramsFor10kgPetPerDay: 60, notes: 'Cocer 15 min' },
      { name: 'Probióticos caninos', category: 'supplement_calcium', baseGramsFor10kgPetPerDay: 3, notes: 'Al templar' },
      { name: 'Cáscara de huevo molida', category: 'supplement_calcium', baseGramsFor10kgPetPerDay: 4, notes: 'Calcio' }
    ],
    instructions: [
      'Cocer el pollo 20 minutos añadiendo el hígado en los últimos 7 minutos.',
      'Cocer la quinoa 15 minutos en agua hirviendo y escurrir.',
      'Picar fino las carnes, unir a la quinoa y añadir los probióticos y el calcio al templar.'
    ],
    storageInfo: 'Nevera 3 días, congelador 2 meses.',
    macronutrients: { proteinPct: 52, fatPct: 16, fiberCarbPct: 22, moisturePct: 76 }
  }
];
