import { Recipe } from '../types';

export const CAT_SENIOR_RECIPES: Recipe[] = [
  {
    id: 'cat-sen-01',
    title: 'Pavo con Calabaza para Gatos Senior',
    frenchTitle: 'Dinde Délicate au Potiron & Condroprotecteurs Chat Senior',
    species: 'cat',
    growthStage: 'senior',
    category: 'joint_omega3',
    categoryLabel: 'Articular & Condroprotectores Senior',
    description: 'Cocer pavo 20 min y calabaza 15 min. Añadir taurina, condroprotectores y cáscara de huevo.',
    kcalPer100g: 115,
    prepTimeMin: 15,
    cookTimeMin: 20,
    difficulty: 'Fácil',
    suitability: 'Gatos mayores (+7 años) con artrosis, saltos con dificultad o rigidez lumbar',
    clinicalBenefits: ['Condroprotectores para preservar cartílago articular', 'Proteína magra para evitar atrofia muscular', 'Taurina'],
    ingredients: [
      { name: 'Pechuga de pavo cocida', category: 'protein', baseGramsFor10kgPetPerDay: 100, notes: 'Cocer 20 min' },
      { name: 'Calabaza cocida en puré', category: 'vegetable', baseGramsFor10kgPetPerDay: 20, notes: 'Cocer 15 min' },
      { name: 'Taurina felina', category: 'supplement_calcium', baseGramsFor10kgPetPerDay: 0.5, notes: 'Al templar' },
      { name: 'Condroprotectores felinos (glucosamina/condroitina)', category: 'supplement_calcium', baseGramsFor10kgPetPerDay: 1, notes: 'Articular' },
      { name: 'Aceite de salmón', category: 'healthy_fat', baseGramsFor10kgPetPerDay: 2, notes: 'Omega 3' },
      { name: 'Cáscara de huevo molida', category: 'supplement_calcium', baseGramsFor10kgPetPerDay: 2, notes: 'Calcio' }
    ],
    instructions: [
      'Cocer el pavo 20 minutos y triturar finamente.',
      'Cocer la calabaza 15 minutos formando un puré hidratante con su caldo.',
      'Mezclar en templado e incorporar la taurina, los condroprotectores, el aceite y la cáscara de huevo.'
    ],
    storageInfo: 'Nevera 48h, congelador 2 meses.',
    macronutrients: { proteinPct: 55, fatPct: 22, fiberCarbPct: 4, moisturePct: 80 }
  },
  {
    id: 'cat-sen-02',
    title: 'Pollo con Calabacín para Gatos Senior',
    frenchTitle: 'Poulet Tendre aux Courgettes Chat Senior',
    species: 'cat',
    growthStage: 'senior',
    category: 'sensitive_digestion',
    categoryLabel: 'Hidratación Renal & Páncreas en Reposo',
    description: 'Cocer pollo 20 min y calabacín 10 min. Incorporar taurina, aceite de salmón y cáscara de huevo.',
    kcalPer100g: 120,
    prepTimeMin: 15,
    cookTimeMin: 20,
    difficulty: 'Fácil',
    suitability: 'Gatos mayores que necesitan cuidar riñones y orinar con facilidad',
    clinicalBenefits: ['Calabacín con 95% de agua biológica que diluye la orina', 'Pollo fácil de masticar', 'Taurina'],
    ingredients: [
      { name: 'Pechuga de pollo cocida', category: 'protein', baseGramsFor10kgPetPerDay: 100, notes: 'Cocer 20 min' },
      { name: 'Calabacín cocido en dados muy blandos', category: 'vegetable', baseGramsFor10kgPetPerDay: 20, notes: 'Cocer 10 min' },
      { name: 'Taurina felina', category: 'supplement_calcium', baseGramsFor10kgPetPerDay: 0.5, notes: 'Al templar' },
      { name: 'Aceite de salmón', category: 'healthy_fat', baseGramsFor10kgPetPerDay: 2, notes: 'Omega 3' },
      { name: 'Cáscara de huevo molida', category: 'supplement_calcium', baseGramsFor10kgPetPerDay: 2, notes: 'Calcio' }
    ],
    instructions: [
      'Cocer el pollo 20 minutos y deshebrar en hilachas muy cortas.',
      'Cocer el calabacín 10 minutos y machacar con el caldo.',
      'Integrar en templado con la taurina, el aceite de salmón y la cáscara de huevo molida.'
    ],
    storageInfo: 'Nevera 48h, congelador 2 meses.',
    macronutrients: { proteinPct: 56, fatPct: 23, fiberCarbPct: 3, moisturePct: 80 }
  },
  {
    id: 'cat-sen-03',
    title: 'Conejo con Calabaza para Gatos Senior',
    frenchTitle: 'Lapin Braisé au Potiron & Glucosamine Chat Senior',
    species: 'cat',
    growthStage: 'senior',
    category: 'joint_omega3',
    categoryLabel: 'Glucosamina & Protección Muscular Senior',
    description: 'Cocer conejo 35 min y calabaza 15 min. Añadir taurina, glucosamina y cáscara de huevo.',
    kcalPer100g: 120,
    prepTimeMin: 15,
    cookTimeMin: 35,
    difficulty: 'Fácil',
    suitability: 'Gatos mayores con digestión delicada y atrofia muscular del tren posterior',
    clinicalBenefits: ['Proteína magra no alergena', 'Glucosamina para articulaciones rígidas', 'Taurina'],
    ingredients: [
      { name: 'Carne magra de conejo deshuesada', category: 'protein', baseGramsFor10kgPetPerDay: 105, notes: 'Cocer 35 min' },
      { name: 'Calabaza cocida', category: 'vegetable', baseGramsFor10kgPetPerDay: 18, notes: 'Cocer 15 min' },
      { name: 'Taurina felina', category: 'supplement_calcium', baseGramsFor10kgPetPerDay: 0.5, notes: 'Al templar' },
      { name: 'Glucosamina felina', category: 'supplement_calcium', baseGramsFor10kgPetPerDay: 1, notes: 'Soporte articular' },
      { name: 'Aceite de salmón', category: 'healthy_fat', baseGramsFor10kgPetPerDay: 2, notes: 'Omega 3' },
      { name: 'Cáscara de huevo molida', category: 'supplement_calcium', baseGramsFor10kgPetPerDay: 2, notes: 'Calcio' }
    ],
    instructions: [
      'Cocer el conejo 35 minutos y verificar que no haya ningún fragmento óseo.',
      'Cocer la calabaza 15 minutos y aplastar en puré fino.',
      'Mezclar en templado e incorporar la taurina, la glucosamina, el aceite y el calcio.'
    ],
    storageInfo: 'Nevera 48h, congelador 2 meses.',
    macronutrients: { proteinPct: 57, fatPct: 22, fiberCarbPct: 4, moisturePct: 79 }
  },
  {
    id: 'cat-sen-04',
    title: 'Bacalao con Calabacín para Gatos Senior',
    frenchTitle: 'Cabillaud Délicat Vapeur aux Courgettes Chat Senior',
    species: 'cat',
    growthStage: 'senior',
    category: 'sensitive_digestion',
    categoryLabel: 'Pescado Blanco Magro & Cuidado Renal',
    description: 'Bacalao al vapor 10 min y calabacín 10 min. Terminar con taurina, aceite de linaza y cáscara de huevo.',
    kcalPer100g: 105,
    prepTimeMin: 10,
    cookTimeMin: 10,
    difficulty: 'Fácil',
    suitability: 'Gatos mayores con insuficiencia renal incipiente o enzimas hepáticas alteradas',
    clinicalBenefits: ['Mínimo residuo metabólico nitrogenado', 'Fósforo moderado y baja grasa', 'Taurina'],
    ingredients: [
      { name: 'Bacalao fresco desespinado', category: 'protein', baseGramsFor10kgPetPerDay: 110, notes: 'Al vapor 10 min' },
      { name: 'Calabacín al vapor suave', category: 'vegetable', baseGramsFor10kgPetPerDay: 20, notes: 'Cocer 10 min' },
      { name: 'Taurina felina', category: 'supplement_calcium', baseGramsFor10kgPetPerDay: 0.5, notes: 'Al templar' },
      { name: 'Aceite de linaza', category: 'healthy_fat', baseGramsFor10kgPetPerDay: 2, notes: 'En crudo' },
      { name: 'Cáscara de huevo molida', category: 'supplement_calcium', baseGramsFor10kgPetPerDay: 2, notes: 'Calcio' }
    ],
    instructions: [
      'Cocinar el bacalao 10 minutos al vapor y desmigar minuciosamente descartando espinas.',
      'Cocer el calabacín 10 minutos y aplastar con tenedor.',
      'Unir e integrar la taurina, el aceite de linaza y la cáscara de huevo molida en tibio.'
    ],
    storageInfo: 'Nevera 48 horas.',
    macronutrients: { proteinPct: 54, fatPct: 20, fiberCarbPct: 3, moisturePct: 82 }
  },
  {
    id: 'cat-sen-05',
    title: 'Salmón con Calabaza para Gatos Senior',
    frenchTitle: 'Saumon Fondant au Potiron & Omega 3 Chat Senior',
    species: 'cat',
    growthStage: 'senior',
    category: 'joint_omega3',
    categoryLabel: 'Cognitivo Felino & Antiinflamatorio Articular',
    description: 'Hornear salmón 12 min y cocer calabaza 15 min. Añadir taurina, omega 3 y cáscara de huevo.',
    kcalPer100g: 130,
    prepTimeMin: 15,
    cookTimeMin: 15,
    difficulty: 'Fácil',
    suitability: 'Gatos mayores con síndrome de disfunción cognitiva o pérdida de agilidad',
    clinicalBenefits: ['DHA para ralentizar el envejecimiento cerebral felino', 'EPA para articulaciones', 'Taurina'],
    ingredients: [
      { name: 'Lomo de salmón desespinado', category: 'protein', baseGramsFor10kgPetPerDay: 95, notes: 'Hornear 12 min' },
      { name: 'Calabaza cocida', category: 'vegetable', baseGramsFor10kgPetPerDay: 18, notes: 'Cocer 15 min' },
      { name: 'Taurina felina', category: 'supplement_calcium', baseGramsFor10kgPetPerDay: 0.5, notes: 'Al templar' },
      { name: 'Aceite de salmón (omega 3)', category: 'healthy_fat', baseGramsFor10kgPetPerDay: 2, notes: 'Ácidos EPA/DHA' },
      { name: 'Cáscara de huevo molida', category: 'supplement_calcium', baseGramsFor10kgPetPerDay: 2, notes: 'Calcio' }
    ],
    instructions: [
      'Hornear el salmón 12 minutos y revisar que no quede ninguna espina.',
      'Cocer la calabaza 15 minutos y aplastar fino.',
      'Mezclar en templado y añadir la taurina, el omega 3 y la cáscara de huevo molida.'
    ],
    storageInfo: 'Nevera 48 horas.',
    macronutrients: { proteinPct: 51, fatPct: 28, fiberCarbPct: 3, moisturePct: 77 }
  },
  {
    id: 'cat-sen-06',
    title: 'Pavo con Judías Verdes para Gatos Senior',
    frenchTitle: 'Dinde & Haricots Verts Condroprotecteurs Chat Senior',
    species: 'cat',
    growthStage: 'senior',
    category: 'joint_omega3',
    categoryLabel: 'Movilidad & Condroprotección Senior',
    description: 'Cocer pavo 20 min y judías 12 min. Incorporar taurina, condroprotectores y cáscara de huevo.',
    kcalPer100g: 115,
    prepTimeMin: 15,
    cookTimeMin: 20,
    difficulty: 'Fácil',
    suitability: 'Gatos mayores con sobrepeso que necesitan cuidar columna y patas',
    clinicalBenefits: ['Control calórico con soporte de cartílagos', 'Proteína magra', 'Taurina'],
    ingredients: [
      { name: 'Pechuga de pavo cocida', category: 'protein', baseGramsFor10kgPetPerDay: 100, notes: 'Cocer 20 min' },
      { name: 'Judías verdes cocidas tiernas', category: 'vegetable', baseGramsFor10kgPetPerDay: 15, notes: 'Cocer 12 min' },
      { name: 'Taurina felina', category: 'supplement_calcium', baseGramsFor10kgPetPerDay: 0.5, notes: 'Al templar' },
      { name: 'Condroprotectores felinos', category: 'supplement_calcium', baseGramsFor10kgPetPerDay: 1, notes: 'Glucosamina/condroitina' },
      { name: 'Aceite de linaza', category: 'healthy_fat', baseGramsFor10kgPetPerDay: 2, notes: 'En crudo' },
      { name: 'Cáscara de huevo molida', category: 'supplement_calcium', baseGramsFor10kgPetPerDay: 2, notes: 'Calcio' }
    ],
    instructions: [
      'Cocer el pavo 20 minutos y triturar.',
      'Cocer las judías 12 minutos y picar diminuto.',
      'Mezclar en templado e incorporar la taurina, los condroprotectores y la cáscara de huevo.'
    ],
    storageInfo: 'Nevera 48h, congelador 2 meses.',
    macronutrients: { proteinPct: 56, fatPct: 22, fiberCarbPct: 3, moisturePct: 79 }
  },
  {
    id: 'cat-sen-07',
    title: 'Trucha con Calabaza para Gatos Senior',
    frenchTitle: 'Truite de Montagne & Potiron Velouté Chat Senior',
    species: 'cat',
    growthStage: 'senior',
    category: 'joint_omega3',
    categoryLabel: 'Pescado Fresco Antiinflamatorio & Fibra Amable',
    description: 'Trucha 12 min y calabaza 15 min. Terminar con taurina, aceite de salmón y cáscara de huevo.',
    kcalPer100g: 125,
    prepTimeMin: 15,
    cookTimeMin: 15,
    difficulty: 'Fácil',
    suitability: 'Gatos mayores con dientes débiles que agradecen una textura en crema suave',
    clinicalBenefits: ['Textura fácil de lamer', 'Grasas omega 3 que desinflaman encías y articulaciones', 'Taurina'],
    ingredients: [
      { name: 'Trucha al vapor sin espinas', category: 'protein', baseGramsFor10kgPetPerDay: 100, notes: 'Cocer 12 min' },
      { name: 'Calabaza cocida', category: 'vegetable', baseGramsFor10kgPetPerDay: 18, notes: 'Cocer 15 min' },
      { name: 'Taurina felina', category: 'supplement_calcium', baseGramsFor10kgPetPerDay: 0.5, notes: 'Al templar' },
      { name: 'Aceite de salmón', category: 'healthy_fat', baseGramsFor10kgPetPerDay: 2, notes: 'Omega 3' },
      { name: 'Cáscara de huevo molida', category: 'supplement_calcium', baseGramsFor10kgPetPerDay: 2, notes: 'Calcio' }
    ],
    instructions: [
      'Cocinar la trucha al vapor 12 minutos revisando que no queden espinas.',
      'Cocer la calabaza 15 minutos y chafarla.',
      'Unir todo con tenedor y agregar taurina, aceite de salmón y calcio al templar.'
    ],
    storageInfo: 'Nevera 48 horas.',
    macronutrients: { proteinPct: 53, fatPct: 26, fiberCarbPct: 3, moisturePct: 78 }
  },
  {
    id: 'cat-sen-08',
    title: 'Conejo con Calabacín para Gatos Senior',
    frenchTitle: 'Lapin Délicat aux Courgettes & Glucosamine Chat Senior',
    species: 'cat',
    growthStage: 'senior',
    category: 'joint_omega3',
    categoryLabel: 'Asimilación Fácil & Glucosamina Senior',
    description: 'Cocer conejo 35 min y calabacín 10 min. Añadir taurina, glucosamina y cáscara de huevo.',
    kcalPer100g: 120,
    prepTimeMin: 15,
    cookTimeMin: 35,
    difficulty: 'Fácil',
    suitability: 'Gatos maduros con hipersensibilidad gástrica y rigidez matutina',
    clinicalBenefits: ['Proteína digestible que no cansa el estómago', 'Glucosamina protectora articular', 'Taurina'],
    ingredients: [
      { name: 'Carne de conejo deshuesada', category: 'protein', baseGramsFor10kgPetPerDay: 105, notes: 'Cocer 35 min' },
      { name: 'Calabacín cocido en dados blandos', category: 'vegetable', baseGramsFor10kgPetPerDay: 18, notes: 'Cocer 10 min' },
      { name: 'Taurina felina', category: 'supplement_calcium', baseGramsFor10kgPetPerDay: 0.5, notes: 'Al templar' },
      { name: 'Glucosamina felina', category: 'supplement_calcium', baseGramsFor10kgPetPerDay: 1, notes: 'Articular' },
      { name: 'Aceite de linaza', category: 'healthy_fat', baseGramsFor10kgPetPerDay: 2, notes: 'En crudo' },
      { name: 'Cáscara de huevo molida', category: 'supplement_calcium', baseGramsFor10kgPetPerDay: 2, notes: 'Calcio' }
    ],
    instructions: [
      'Cocer el conejo 35 minutos y retirar escrupulosamente los huesos.',
      'Cocer el calabacín 10 minutos y machacar con tenedor.',
      'Mezclar en templado e integrar la taurina, la glucosamina, el aceite y el calcio.'
    ],
    storageInfo: 'Nevera 48h, congelador 2 meses.',
    macronutrients: { proteinPct: 58, fatPct: 22, fiberCarbPct: 3, moisturePct: 79 }
  },
  {
    id: 'cat-sen-09',
    title: 'Pollo con Corazón y Calabaza para Gatos Senior',
    frenchTitle: 'Poulet Cœur de Volaille & Potiron Chat Senior',
    species: 'cat',
    growthStage: 'senior',
    category: 'vitality_gourmet',
    categoryLabel: 'Soporte Miocárdico & Tránsito Suave',
    description: 'Cocer pollo 20 min, corazón 7 min y calabaza 15 min. Añadir taurina, omega 3 y cáscara de huevo.',
    kcalPer100g: 125,
    prepTimeMin: 15,
    cookTimeMin: 20,
    difficulty: 'Fácil',
    suitability: 'Gatos mayores con soplo o debilidad cardiovascular senil',
    clinicalBenefits: ['L-carnitina y taurina naturales para bombear sangre con eficiencia', 'Calabaza emoliente', 'Calcio'],
    ingredients: [
      { name: 'Pechuga de pollo cocida', category: 'protein', baseGramsFor10kgPetPerDay: 80, notes: 'Cocer 20 min' },
      { name: 'Corazón de pollo picado', category: 'organ_meat', baseGramsFor10kgPetPerDay: 25, notes: 'Cocer 7 min' },
      { name: 'Calabaza cocida', category: 'vegetable', baseGramsFor10kgPetPerDay: 15, notes: 'Cocer 15 min' },
      { name: 'Taurina felina', category: 'supplement_calcium', baseGramsFor10kgPetPerDay: 0.5, notes: 'Al templar' },
      { name: 'Aceite de salmón', category: 'healthy_fat', baseGramsFor10kgPetPerDay: 2, notes: 'Omega 3' },
      { name: 'Cáscara de huevo molida', category: 'supplement_calcium', baseGramsFor10kgPetPerDay: 2, notes: 'Calcio' }
    ],
    instructions: [
      'Cocer el pollo 20 minutos con los corazones los últimos 7 minutos.',
      'Cocer la calabaza 15 minutos y aplastar en puré fino.',
      'Picar fino, mezclar en tibio y agregar taurina, aceite de salmón y cáscara de huevo molida.'
    ],
    storageInfo: 'Nevera 48h, congelador 2 meses.',
    macronutrients: { proteinPct: 56, fatPct: 24, fiberCarbPct: 3, moisturePct: 78 }
  },
  {
    id: 'cat-sen-10',
    title: 'Bacalao con Judías Verdes para Gatos Senior',
    frenchTitle: 'Cabillaud Vapeur aux Fins Haricots Chat Senior',
    species: 'cat',
    growthStage: 'senior',
    category: 'joint_omega3',
    categoryLabel: 'Pescado Blanco Magro & Condroprotectores',
    description: 'Bacalao al vapor 10 min y judías 12 min. Incorporar taurina, condroprotectores y cáscara de huevo.',
    kcalPer100g: 105,
    prepTimeMin: 15,
    cookTimeMin: 12,
    difficulty: 'Fácil',
    suitability: 'Gatos mayores que necesitan una dieta hipolipídica y soporte articular',
    clinicalBenefits: ['Mínima grasa para cuidar hígado y páncreas sénior', 'Condroprotectores para artrosis', 'Taurina'],
    ingredients: [
      { name: 'Bacalao fresco al vapor desespinado', category: 'protein', baseGramsFor10kgPetPerDay: 110, notes: 'Al vapor 10 min' },
      { name: 'Judías verdes cocidas picadas fino', category: 'vegetable', baseGramsFor10kgPetPerDay: 15, notes: 'Cocer 12 min' },
      { name: 'Taurina felina', category: 'supplement_calcium', baseGramsFor10kgPetPerDay: 0.5, notes: 'Al templar' },
      { name: 'Condroprotectores felinos', category: 'supplement_calcium', baseGramsFor10kgPetPerDay: 1, notes: 'Glucosamina/condroitina' },
      { name: 'Aceite de salmón', category: 'healthy_fat', baseGramsFor10kgPetPerDay: 2, notes: 'Omega 3' },
      { name: 'Cáscara de huevo molida', category: 'supplement_calcium', baseGramsFor10kgPetPerDay: 2, notes: 'Calcio' }
    ],
    instructions: [
      'Cocinar el bacalao al vapor 10 minutos y revisar meticulosamente la ausencia de espinas.',
      'Cocer las judías 12 minutos y triturar en migas.',
      'Unir todo e incorporar taurina, condroprotectores, aceite y calcio en tibio.'
    ],
    storageInfo: 'Nevera 48 horas.',
    macronutrients: { proteinPct: 55, fatPct: 19, fiberCarbPct: 3, moisturePct: 82 }
  },
  {
    id: 'cat-sen-11',
    title: 'Pavo con Calabacín y Espinaca para Gatos Senior',
    frenchTitle: 'Dinde Tendre au Calabacín & Pousses d’Épinards Chat Senior',
    species: 'cat',
    growthStage: 'senior',
    category: 'sensitive_digestion',
    categoryLabel: 'Hidratación & Cuidado Antioxidante',
    description: 'Cocer pavo 20 min, calabacín 10 min y espinaca 5 min. Añadir taurina, aceite de linaza y cáscara de huevo.',
    kcalPer100g: 115,
    prepTimeMin: 15,
    cookTimeMin: 20,
    difficulty: 'Fácil',
    suitability: 'Gatos mayores con tendencia a la sequedad de mucosas',
    clinicalBenefits: ['Verduras de alta humedad', 'Pavo magro que conserva musculatura', 'Taurina'],
    ingredients: [
      { name: 'Pechuga de pavo cocida', category: 'protein', baseGramsFor10kgPetPerDay: 100, notes: 'Cocer 20 min' },
      { name: 'Calabacín cocido', category: 'vegetable', baseGramsFor10kgPetPerDay: 12, notes: 'Cocer 10 min' },
      { name: 'Espinacas escaldadas', category: 'vegetable', baseGramsFor10kgPetPerDay: 5, notes: 'Escaldar 5 min' },
      { name: 'Taurina felina', category: 'supplement_calcium', baseGramsFor10kgPetPerDay: 0.5, notes: 'Al templar' },
      { name: 'Aceite de linaza', category: 'healthy_fat', baseGramsFor10kgPetPerDay: 2, notes: 'En crudo' },
      { name: 'Cáscara de huevo molida', category: 'supplement_calcium', baseGramsFor10kgPetPerDay: 2, notes: 'Calcio' }
    ],
    instructions: [
      'Cocer el pavo 20 minutos y triturar.',
      'Cocer el calabacín 10 minutos y escaldar las espinacas 5 minutos machacando en puré verde suave.',
      'Integrar en tibio con taurina, aceite de linaza y cáscara de huevo.'
    ],
    storageInfo: 'Nevera 48h, congelador 2 meses.',
    macronutrients: { proteinPct: 56, fatPct: 22, fiberCarbPct: 3, moisturePct: 80 }
  },
  {
    id: 'cat-sen-12',
    title: 'Salmón con Calabacín para Gatos Senior',
    frenchTitle: 'Saumon Délicat aux Courgettes & Glucosamine Chat Senior',
    species: 'cat',
    growthStage: 'senior',
    category: 'joint_omega3',
    categoryLabel: 'Lípidos Antiinflamatorios & Glucosamina',
    description: 'Hornear salmón 12 min y cocer calabacín 10 min. Añadir taurina, glucosamina y cáscara de huevo.',
    kcalPer100g: 130,
    prepTimeMin: 15,
    cookTimeMin: 15,
    difficulty: 'Fácil',
    suitability: 'Gatos maduros con signos de artrosis en rodillas o codos',
    clinicalBenefits: ['Sinergia de glucosamina y ácidos grasos omega 3 marinos', 'Calabacín hidratante', 'Taurina'],
    ingredients: [
      { name: 'Salmón fresco horneado sin espinas', category: 'protein', baseGramsFor10kgPetPerDay: 95, notes: 'Hornear 12 min' },
      { name: 'Calabacín cocido en puré', category: 'vegetable', baseGramsFor10kgPetPerDay: 18, notes: 'Cocer 10 min' },
      { name: 'Taurina felina', category: 'supplement_calcium', baseGramsFor10kgPetPerDay: 0.5, notes: 'Al templar' },
      { name: 'Glucosamina felina', category: 'supplement_calcium', baseGramsFor10kgPetPerDay: 1, notes: 'Articular' },
      { name: 'Aceite de salmón', category: 'healthy_fat', baseGramsFor10kgPetPerDay: 2, notes: 'Omega 3' },
      { name: 'Cáscara de huevo en polvo', category: 'supplement_calcium', baseGramsFor10kgPetPerDay: 2, notes: 'Calcio' }
    ],
    instructions: [
      'Hornear el salmón 12 minutos comprobando minuciosamente la ausencia de espinas.',
      'Cocer el calabacín 10 minutos y aplastar fino.',
      'Mezclar en templado y añadir taurina, glucosamina, aceite y cáscara de huevo molida.'
    ],
    storageInfo: 'Nevera 48 horas.',
    macronutrients: { proteinPct: 52, fatPct: 27, fiberCarbPct: 3, moisturePct: 78 }
  },
  {
    id: 'cat-sen-13',
    title: 'Conejo con Judías Verdes para Gatos Senior',
    frenchTitle: 'Lapin Délicat aux Haricots Verts Chat Senior',
    species: 'cat',
    growthStage: 'senior',
    category: 'sensitive_digestion',
    categoryLabel: 'Carne Magra Hipoalergénica & Saciedad',
    description: 'Cocer conejo 35 min y judías 12 min. Terminar con taurina, aceite de salmón y cáscara de huevo.',
    kcalPer100g: 115,
    prepTimeMin: 15,
    cookTimeMin: 35,
    difficulty: 'Fácil',
    suitability: 'Gatos mayores que pasan la mayor parte del día durmiendo y requieren pocas calorías',
    clinicalBenefits: ['Mantiene la masa magra sin provocar incremento de adiposidad', 'Taurina', 'Calcio'],
    ingredients: [
      { name: 'Conejo deshuesado cocido', category: 'protein', baseGramsFor10kgPetPerDay: 105, notes: 'Cocer 35 min' },
      { name: 'Judías verdes cocidas picadas', category: 'vegetable', baseGramsFor10kgPetPerDay: 15, notes: 'Cocer 12 min' },
      { name: 'Taurina felina', category: 'supplement_calcium', baseGramsFor10kgPetPerDay: 0.5, notes: 'Al templar' },
      { name: 'Aceite de salmón', category: 'healthy_fat', baseGramsFor10kgPetPerDay: 2, notes: 'Omega 3' },
      { name: 'Cáscara de huevo molida', category: 'supplement_calcium', baseGramsFor10kgPetPerDay: 2, notes: 'Calcio' }
    ],
    instructions: [
      'Cocer el conejo 35 minutos y desmigar meticulosamente descartando huesos.',
      'Cocer las judías 12 minutos y cortar muy menudo.',
      'Mezclar con la taurina, el aceite de salmón y el calcio al templar.'
    ],
    storageInfo: 'Nevera 48h, congelador 2 meses.',
    macronutrients: { proteinPct: 58, fatPct: 21, fiberCarbPct: 3, moisturePct: 79 }
  },
  {
    id: 'cat-sen-14',
    title: 'Trucha con Calabacín y Espinaca para Gatos Senior',
    frenchTitle: 'Truite de Ruisseau Courgettes & Épinards Chat Senior',
    species: 'cat',
    growthStage: 'senior',
    category: 'joint_omega3',
    categoryLabel: 'Perfil Pescado Suave & Antiinflamatorio Renal',
    description: 'Trucha 12 min, calabacín 10 min y espinaca 5 min. Añadir taurina, omega 3 y cáscara de huevo.',
    kcalPer100g: 120,
    prepTimeMin: 15,
    cookTimeMin: 15,
    difficulty: 'Fácil',
    suitability: 'Gatos mayores con tendencia a la deshidratación y rigidez articular',
    clinicalBenefits: ['Antioxidantes botánicos en cantidades felinas seguras', 'Omega 3 puro', 'Taurina'],
    ingredients: [
      { name: 'Trucha desespinada al vapor', category: 'protein', baseGramsFor10kgPetPerDay: 100, notes: 'Cocer 12 min' },
      { name: 'Calabacín cocido', category: 'vegetable', baseGramsFor10kgPetPerDay: 12, notes: 'Cocer 10 min' },
      { name: 'Espinacas escaldadas', category: 'vegetable', baseGramsFor10kgPetPerDay: 5, notes: 'Escaldar 5 min' },
      { name: 'Taurina felina', category: 'supplement_calcium', baseGramsFor10kgPetPerDay: 0.5, notes: 'Al templar' },
      { name: 'Aceite de salmón', category: 'healthy_fat', baseGramsFor10kgPetPerDay: 2, notes: 'Omega 3' },
      { name: 'Cáscara de huevo en polvo', category: 'supplement_calcium', baseGramsFor10kgPetPerDay: 2, notes: 'Calcio' }
    ],
    instructions: [
      'Cocinar la trucha al vapor 12 minutos retirando espinas minuciosamente.',
      'Cocer las verduras y machacarlas con su agua de cocción en puré.',
      'Unir todo con la taurina, el aceite de salmón y la cáscara de huevo en templado.'
    ],
    storageInfo: 'Nevera 48 horas.',
    macronutrients: { proteinPct: 53, fatPct: 25, fiberCarbPct: 3, moisturePct: 79 }
  },
  {
    id: 'cat-sen-15',
    title: 'Pollo con Hígado y Calabaza para Gatos Senior',
    frenchTitle: 'Poulet aux Éclats de Foie Potiron & Condroprotecteurs Chat Senior',
    species: 'cat',
    growthStage: 'senior',
    category: 'joint_omega3',
    categoryLabel: 'Vitalidad Ocular, Articular & Condroprotectores',
    description: 'Cocer pollo 20 min, hígado 7 min y calabaza 15 min. Incorporar taurina, condroprotectores y cáscara de huevo.',
    kcalPer100g: 125,
    prepTimeMin: 15,
    cookTimeMin: 20,
    difficulty: 'Fácil',
    suitability: 'Gatos mayores con pérdida sensorial y necesidad de soporte articular',
    clinicalBenefits: ['Vitamina A para la córnea y retina envejecida', 'Condroprotectores para artrosis', 'Taurina'],
    ingredients: [
      { name: 'Pechuga de pollo cocida', category: 'protein', baseGramsFor10kgPetPerDay: 85, notes: 'Cocer 20 min' },
      { name: 'Hígado de pollo fresco', category: 'organ_meat', baseGramsFor10kgPetPerDay: 10, notes: 'Cocer 7 min' },
      { name: 'Calabaza cocida', category: 'vegetable', baseGramsFor10kgPetPerDay: 18, notes: 'Cocer 15 min' },
      { name: 'Taurina felina', category: 'supplement_calcium', baseGramsFor10kgPetPerDay: 0.5, notes: 'Al templar' },
      { name: 'Condroprotectores felinos', category: 'supplement_calcium', baseGramsFor10kgPetPerDay: 1, notes: 'Glucosamina/condroitina' },
      { name: 'Cáscara de huevo molida', category: 'supplement_calcium', baseGramsFor10kgPetPerDay: 2, notes: 'Calcio' }
    ],
    instructions: [
      'Cocer el pollo 20 minutos con el hígado los últimos 7 minutos.',
      'Cocer la calabaza 15 minutos y aplastar en puré fino.',
      'Picar las carnes, incorporar al puré y añadir taurina, condroprotectores y calcio en templado.'
    ],
    storageInfo: 'Nevera 48h, congelador 2 meses.',
    macronutrients: { proteinPct: 56, fatPct: 24, fiberCarbPct: 3, moisturePct: 78 }
  },
  {
    id: 'cat-sen-16',
    title: 'Pavo con Calabaza y Espinaca para Gatos Senior',
    frenchTitle: 'Dinde au Potiron Fondant & Glucosamine Chat Senior',
    species: 'cat',
    growthStage: 'senior',
    category: 'joint_omega3',
    categoryLabel: 'Glucosamina & Protección Digestiva',
    description: 'Cocer pavo 20 min, calabaza 15 min y espinaca 5 min. Añadir taurina, glucosamina y cáscara de huevo.',
    kcalPer100g: 115,
    prepTimeMin: 15,
    cookTimeMin: 20,
    difficulty: 'Fácil',
    suitability: 'Gatos mayores con articulaciones doloridas y digestión sensible',
    clinicalBenefits: ['Efecto antiinflamatorio de la glucosamina y la calabaza hidratante', 'Taurina', 'Calcio'],
    ingredients: [
      { name: 'Pavo cocido troceado', category: 'protein', baseGramsFor10kgPetPerDay: 100, notes: 'Cocer 20 min' },
      { name: 'Calabaza cocida', category: 'vegetable', baseGramsFor10kgPetPerDay: 12, notes: 'Cocer 15 min' },
      { name: 'Espinacas escaldadas', category: 'vegetable', baseGramsFor10kgPetPerDay: 5, notes: 'Escaldar 5 min' },
      { name: 'Taurina felina', category: 'supplement_calcium', baseGramsFor10kgPetPerDay: 0.5, notes: 'Al templar' },
      { name: 'Glucosamina felina', category: 'supplement_calcium', baseGramsFor10kgPetPerDay: 1, notes: 'Articular' },
      { name: 'Cáscara de huevo molida', category: 'supplement_calcium', baseGramsFor10kgPetPerDay: 2, notes: 'Calcio' }
    ],
    instructions: [
      'Cocer el pavo 20 minutos y triturar.',
      'Cocer la calabaza 15 minutos y escaldar las espinacas 5 minutos aplastando bien.',
      'Mezclar en templado con la taurina, la glucosamina y la cáscara de huevo molida.'
    ],
    storageInfo: 'Nevera 48h, congelador 2 meses.',
    macronutrients: { proteinPct: 56, fatPct: 22, fiberCarbPct: 3, moisturePct: 80 }
  },
  {
    id: 'cat-sen-17',
    title: 'Bacalao con Calabaza para Gatos Senior',
    frenchTitle: 'Cabillaud au Velouté de Potiron Chat Senior',
    species: 'cat',
    growthStage: 'senior',
    category: 'sensitive_digestion',
    categoryLabel: 'Pescado Blanco Ligero & Hidratación Emoliente',
    description: 'Bacalao al vapor 10 min y calabaza 15 min. Terminar con taurina, aceite de salmón y cáscara de huevo.',
    kcalPer100g: 105,
    prepTimeMin: 10,
    cookTimeMin: 15,
    difficulty: 'Fácil',
    suitability: 'Gatos senior convalecientes o con estómago que rechaza carnes densas',
    clinicalBenefits: ['Facilidad extrema de deglución y tránsito gástrico', 'Taurina', 'Calcio'],
    ingredients: [
      { name: 'Bacalao al vapor sin espinas', category: 'protein', baseGramsFor10kgPetPerDay: 110, notes: 'Al vapor 10 min' },
      { name: 'Calabaza muy tierna cocida', category: 'vegetable', baseGramsFor10kgPetPerDay: 20, notes: 'Cocer 15 min' },
      { name: 'Taurina felina', category: 'supplement_calcium', baseGramsFor10kgPetPerDay: 0.5, notes: 'Al templar' },
      { name: 'Aceite de salmón', category: 'healthy_fat', baseGramsFor10kgPetPerDay: 2, notes: 'Omega 3' },
      { name: 'Cáscara de huevo molida', category: 'supplement_calcium', baseGramsFor10kgPetPerDay: 2, notes: 'Calcio' }
    ],
    instructions: [
      'Cocinar el bacalao al vapor 10 minutos y comprobar meticulosamente que no tenga espinas.',
      'Cocer la calabaza 15 minutos y aplastar en puré fino.',
      'Integrar en templado junto a la taurina, el aceite de salmón y la cáscara de huevo molida.'
    ],
    storageInfo: 'Nevera 48 horas.',
    macronutrients: { proteinPct: 54, fatPct: 20, fiberCarbPct: 3, moisturePct: 82 }
  },
  {
    id: 'cat-sen-18',
    title: 'Salmón con Judías Verdes para Gatos Senior',
    frenchTitle: 'Saumon Rose aux Haricots Verts & Condroprotecteurs Chat Senior',
    species: 'cat',
    growthStage: 'senior',
    category: 'joint_omega3',
    categoryLabel: 'Ácidos Grasos Esenciales & Condroprotectores',
    description: 'Hornear salmón 12 min y cocer judías 12 min. Incorporar taurina, condroprotectores y cáscara de huevo.',
    kcalPer100g: 130,
    prepTimeMin: 15,
    cookTimeMin: 15,
    difficulty: 'Fácil',
    suitability: 'Gatos mayores con dolor al acicalarse o al bajar del sofá',
    clinicalBenefits: ['Alta eficacia desinflamatoria marina', 'Condroprotectores para regeneración articular', 'Taurina'],
    ingredients: [
      { name: 'Lomo de salmón horneado sin espinas', category: 'protein', baseGramsFor10kgPetPerDay: 95, notes: 'Hornear 12 min' },
      { name: 'Judías verdes cocidas picadas fino', category: 'vegetable', baseGramsFor10kgPetPerDay: 15, notes: 'Cocer 12 min' },
      { name: 'Taurina felina', category: 'supplement_calcium', baseGramsFor10kgPetPerDay: 0.5, notes: 'Al templar' },
      { name: 'Condroprotectores felinos', category: 'supplement_calcium', baseGramsFor10kgPetPerDay: 1, notes: 'Glucosamina/condroitina' },
      { name: 'Aceite de salmón', category: 'healthy_fat', baseGramsFor10kgPetPerDay: 2, notes: 'Omega 3' },
      { name: 'Cáscara de huevo molida', category: 'supplement_calcium', baseGramsFor10kgPetPerDay: 2, notes: 'Calcio' }
    ],
    instructions: [
      'Hornear el salmón 12 minutos y revisar meticulosamente la presencia de espinas.',
      'Cocer las judías 12 minutos y triturar en migas suaves.',
      'Mezclar en templado e incorporar taurina, condroprotectores, aceite y calcio.'
    ],
    storageInfo: 'Nevera 48 horas.',
    macronutrients: { proteinPct: 52, fatPct: 28, fiberCarbPct: 3, moisturePct: 77 }
  },
  {
    id: 'cat-sen-19',
    title: 'Conejo con Calabacín y Espinaca para Gatos Senior',
    frenchTitle: 'Lapin Tendre Duo Vert Chat Senior',
    species: 'cat',
    growthStage: 'senior',
    category: 'sensitive_digestion',
    categoryLabel: 'Digestión Ligera & Cuidado de la Vejez',
    description: 'Cocer conejo 35 min, calabacín 10 min y espinaca 5 min. Añadir taurina, omega 3 y cáscara de huevo.',
    kcalPer100g: 120,
    prepTimeMin: 15,
    cookTimeMin: 35,
    difficulty: 'Fácil',
    suitability: 'Gatos mayores con función renal o hepática que requiere proteína ultra noble',
    clinicalBenefits: ['Cero sobrecarga de nitrógeno en sangre', 'Omega 3 que favorece la perfusión microvascular renal', 'Taurina'],
    ingredients: [
      { name: 'Carne de conejo deshuesada', category: 'protein', baseGramsFor10kgPetPerDay: 105, notes: 'Cocer 35 min' },
      { name: 'Calabacín cocido', category: 'vegetable', baseGramsFor10kgPetPerDay: 12, notes: 'Cocer 10 min' },
      { name: 'Espinacas escaldadas', category: 'vegetable', baseGramsFor10kgPetPerDay: 5, notes: 'Escaldar 5 min' },
      { name: 'Taurina felina', category: 'supplement_calcium', baseGramsFor10kgPetPerDay: 0.5, notes: 'Al templar' },
      { name: 'Aceite de salmón', category: 'healthy_fat', baseGramsFor10kgPetPerDay: 2, notes: 'Omega 3' },
      { name: 'Cáscara de huevo molida', category: 'supplement_calcium', baseGramsFor10kgPetPerDay: 2, notes: 'Calcio' }
    ],
    instructions: [
      'Cocer el conejo 35 minutos y desmenuzar con las manos descartando huesos.',
      'Cocer las verduras y machacar en puré.',
      'Integrar en tibio con la taurina, el aceite de salmón y la cáscara de huevo en polvo.'
    ],
    storageInfo: 'Nevera 48h, congelador 2 meses.',
    macronutrients: { proteinPct: 57, fatPct: 22, fiberCarbPct: 3, moisturePct: 79 }
  },
  {
    id: 'cat-sen-20',
    title: 'Pollo con Calabaza y Judías Verdes para Gatos Senior',
    frenchTitle: 'Poulet aux Deux Fibres Douces & Glucosamine Chat Senior',
    species: 'cat',
    growthStage: 'senior',
    category: 'joint_omega3',
    categoryLabel: 'Fibra Doble Digestiva & Glucosamina',
    description: 'Cocer pollo 20 min, calabaza 15 min y judías 12 min. Añadir taurina, glucosamina y cáscara de huevo.',
    kcalPer100g: 120,
    prepTimeMin: 15,
    cookTimeMin: 20,
    difficulty: 'Fácil',
    suitability: 'Gatos mayores sedentarios con constipación y molestias articulares',
    clinicalBenefits: ['Calabaza y judías que ablandan el bolo fecal', 'Glucosamina para articulaciones', 'Taurina'],
    ingredients: [
      { name: 'Pechuga de pollo cocida', category: 'protein', baseGramsFor10kgPetPerDay: 100, notes: 'Cocer 20 min' },
      { name: 'Calabaza cocida', category: 'vegetable', baseGramsFor10kgPetPerDay: 12, notes: 'Cocer 15 min' },
      { name: 'Judías verdes cocidas', category: 'vegetable', baseGramsFor10kgPetPerDay: 8, notes: 'Cocer 12 min' },
      { name: 'Taurina felina', category: 'supplement_calcium', baseGramsFor10kgPetPerDay: 0.5, notes: 'Al templar' },
      { name: 'Glucosamina felina', category: 'supplement_calcium', baseGramsFor10kgPetPerDay: 1, notes: 'Articular' },
      { name: 'Cáscara de huevo molida', category: 'supplement_calcium', baseGramsFor10kgPetPerDay: 2, notes: 'Calcio' }
    ],
    instructions: [
      'Cocer el pollo 20 minutos y triturar.',
      'Cocer los vegetales y aplastar fino.',
      'Mezclar en templado e incorporar la taurina, la glucosamina y la cáscara de huevo molida.'
    ],
    storageInfo: 'Nevera 48h, congelador 2 meses.',
    macronutrients: { proteinPct: 55, fatPct: 23, fiberCarbPct: 4, moisturePct: 79 }
  },
  {
    id: 'cat-sen-21',
    title: 'Codorniz con Calabacín para Gatos Senior ⭐',
    frenchTitle: 'Caille Fondante aux Courgettes & Condroprotecteurs Chat Senior',
    species: 'cat',
    growthStage: 'senior',
    category: 'joint_omega3',
    categoryLabel: 'Receta Premium Caza Delicada & Condroprotectores',
    description: 'Premium. Hornear codorniz 25 min y cocer calabacín 10 min. Añadir taurina, condroprotectores y cáscara de huevo.',
    kcalPer100g: 135,
    prepTimeMin: 15,
    cookTimeMin: 25,
    difficulty: 'Media',
    suitability: 'Gatos mayores inapetentes que necesitan estimulación olfativa y nutrición articular',
    clinicalBenefits: ['Palatabilidad superior de caza menor tierna', 'Condroprotectores para cartílago sinovial', 'Taurina'],
    ingredients: [
      { name: 'Carne de codorniz sin huesos', category: 'protein', baseGramsFor10kgPetPerDay: 100, notes: 'Hornear 25 min' },
      { name: 'Calabacín cocido en dados suaves', category: 'vegetable', baseGramsFor10kgPetPerDay: 15, notes: 'Cocer 10 min' },
      { name: 'Taurina felina', category: 'supplement_calcium', baseGramsFor10kgPetPerDay: 0.5, notes: 'Al templar' },
      { name: 'Condroprotectores felinos', category: 'supplement_calcium', baseGramsFor10kgPetPerDay: 1, notes: 'Articular' },
      { name: 'Aceite de salmón', category: 'healthy_fat', baseGramsFor10kgPetPerDay: 2, notes: 'Omega 3' },
      { name: 'Cáscara de huevo molida', category: 'supplement_calcium', baseGramsFor10kgPetPerDay: 2, notes: 'Calcio' }
    ],
    instructions: [
      'Hornear la codorniz 25 minutos y desmigar meticulosamente descartando todos los huesos.',
      'Cocer el calabacín 10 minutos y aplastar fino.',
      'Integrar en templado con taurina, condroprotectores, aceite y calcio.'
    ],
    storageInfo: 'Nevera 48h, congelador 2 meses.',
    macronutrients: { proteinPct: 56, fatPct: 26, fiberCarbPct: 3, moisturePct: 77 }
  },
  {
    id: 'cat-sen-22',
    title: 'Faisán con Calabaza para Gatos Senior ⭐',
    frenchTitle: 'Faisan des Bois au Potiron & Glucosamine Chat Senior',
    species: 'cat',
    growthStage: 'senior',
    category: 'joint_omega3',
    categoryLabel: 'Receta Premium Caza Silvestre & Glucosamina Senior',
    description: 'Premium. Hornear faisán 35 min y cocer calabaza 15 min. Terminar con taurina, glucosamina y cáscara de huevo.',
    kcalPer100g: 135,
    prepTimeMin: 15,
    cookTimeMin: 35,
    difficulty: 'Media',
    suitability: 'Gatos mayores con artrosis crónica que precisan carne magra biológicamente apropiada',
    clinicalBenefits: ['Proteína libre de alérgenos comunes', 'Glucosamina protectora', 'Taurina'],
    ingredients: [
      { name: 'Carne de faisán deshuesada', category: 'protein', baseGramsFor10kgPetPerDay: 100, notes: 'Hornear 35 min' },
      { name: 'Calabaza cocida', category: 'vegetable', baseGramsFor10kgPetPerDay: 15, notes: 'Cocer 15 min' },
      { name: 'Taurina felina', category: 'supplement_calcium', baseGramsFor10kgPetPerDay: 0.5, notes: 'Al templar' },
      { name: 'Glucosamina felina', category: 'supplement_calcium', baseGramsFor10kgPetPerDay: 1, notes: 'Articular' },
      { name: 'Aceite de linaza', category: 'healthy_fat', baseGramsFor10kgPetPerDay: 2, notes: 'En crudo' },
      { name: 'Cáscara de huevo molida', category: 'supplement_calcium', baseGramsFor10kgPetPerDay: 2, notes: 'Calcio' }
    ],
    instructions: [
      'Hornear el faisán 35 minutos retirando escrupulosamente cualquier hueso.',
      'Cocer la calabaza 15 minutos y aplastar en puré fino.',
      'Mezclar en templado e incorporar la taurina, la glucosamina, el aceite y el calcio.'
    ],
    storageInfo: 'Nevera 48h, congelador 2 meses.',
    macronutrients: { proteinPct: 57, fatPct: 24, fiberCarbPct: 3, moisturePct: 77 }
  },
  {
    id: 'cat-sen-23',
    title: 'Caballa con Calabacín para Gatos Senior ⭐',
    frenchTitle: 'Maquereau Rôti aux Courgettes & Omega 3 Chat Senior',
    species: 'cat',
    growthStage: 'senior',
    category: 'joint_omega3',
    categoryLabel: 'Receta Premium Omega 3 Puro & Alivio Articular',
    description: 'Premium. Hornear caballa 15 min y cocer calabacín 10 min. Añadir taurina, omega 3 y cáscara de huevo.',
    kcalPer100g: 135,
    prepTimeMin: 15,
    cookTimeMin: 15,
    difficulty: 'Fácil',
    suitability: 'Gatos mayores con inflamación sistémica o rigidez articular pronunciada',
    clinicalBenefits: ['Pescado azul con la mayor proporción natural de ácidos antiinflamatorios', 'Taurina', 'Calcio'],
    ingredients: [
      { name: 'Filetes de caballa horneados sin espinas', category: 'protein', baseGramsFor10kgPetPerDay: 95, notes: 'Hornear 15 min' },
      { name: 'Calabacín cocido suave', category: 'vegetable', baseGramsFor10kgPetPerDay: 18, notes: 'Cocer 10 min' },
      { name: 'Taurina felina', category: 'supplement_calcium', baseGramsFor10kgPetPerDay: 0.5, notes: 'Al templar' },
      { name: 'Aceite de salmón', category: 'healthy_fat', baseGramsFor10kgPetPerDay: 2, notes: 'Omega 3' },
      { name: 'Cáscara de huevo en polvo', category: 'supplement_calcium', baseGramsFor10kgPetPerDay: 2, notes: 'Calcio' }
    ],
    instructions: [
      'Hornear la caballa 15 minutos y desmigar minuciosamente asegurando cero espinas.',
      'Cocer el calabacín 10 minutos y aplastar.',
      'Unir en tibio con taurina, omega 3 y cáscara de huevo molida.'
    ],
    storageInfo: 'Nevera 48 horas.',
    macronutrients: { proteinPct: 53, fatPct: 29, fiberCarbPct: 3, moisturePct: 76 }
  },
  {
    id: 'cat-sen-24',
    title: 'Conejo con Espinaca para Gatos Senior ⭐',
    frenchTitle: 'Lapin Braisé aux Épinards & Condroprotecteurs Chat Senior',
    species: 'cat',
    growthStage: 'senior',
    category: 'joint_omega3',
    categoryLabel: 'Receta Premium Asimilación Pura & Condroprotectores',
    description: 'Premium. Cocer conejo 35 min y espinaca 5 min. Incorporar taurina, condroprotectores y cáscara de huevo.',
    kcalPer100g: 120,
    prepTimeMin: 15,
    cookTimeMin: 35,
    difficulty: 'Fácil',
    suitability: 'Gatos mayores con historial de vómitos alimentarios y dolor de espalda',
    clinicalBenefits: ['Proteína novel hipoalergénica', 'Condroprotectores para articulaciones', 'Taurina'],
    ingredients: [
      { name: 'Carne de conejo deshuesada', category: 'protein', baseGramsFor10kgPetPerDay: 105, notes: 'Cocer 35 min' },
      { name: 'Espinacas tiernas escaldadas', category: 'vegetable', baseGramsFor10kgPetPerDay: 10, notes: 'Escaldar 5 min' },
      { name: 'Taurina felina', category: 'supplement_calcium', baseGramsFor10kgPetPerDay: 0.5, notes: 'Al templar' },
      { name: 'Condroprotectores felinos', category: 'supplement_calcium', baseGramsFor10kgPetPerDay: 1, notes: 'Glucosamina/condroitina' },
      { name: 'Aceite de salmón', category: 'healthy_fat', baseGramsFor10kgPetPerDay: 2, notes: 'Omega 3' },
      { name: 'Cáscara de huevo molida', category: 'supplement_calcium', baseGramsFor10kgPetPerDay: 2, notes: 'Calcio' }
    ],
    instructions: [
      'Cocer el conejo 35 minutos y deshebrar con mucho cuidado de retirar huesos.',
      'Escaldar las espinacas 5 minutos y picar finamente.',
      'Mezclar en templado e incorporar la taurina, los condroprotectores y el calcio.'
    ],
    storageInfo: 'Nevera 48h, congelador 2 meses.',
    macronutrients: { proteinPct: 57, fatPct: 22, fiberCarbPct: 3, moisturePct: 79 }
  },
  {
    id: 'cat-sen-25',
    title: 'Pato con Calabaza para Gatos Senior ⭐',
    frenchTitle: 'Canard Fondant au Potiron & Glucosamine Chat Senior',
    species: 'cat',
    growthStage: 'senior',
    category: 'joint_omega3',
    categoryLabel: 'Receta Premium Sabor Exquisito & Glucosamina Senior',
    description: 'Premium. Hornear pato 35 min y cocer calabaza 15 min. Terminar con taurina, glucosamina y cáscara de huevo.',
    kcalPer100g: 135,
    prepTimeMin: 15,
    cookTimeMin: 35,
    difficulty: 'Fácil',
    suitability: 'Gatos de edad avanzada con apetito caprichoso que necesitan glucosamina',
    clinicalBenefits: ['Palatabilidad natural de ave noble', 'Glucosamina para aliviar la marcha rígida', 'Taurina'],
    ingredients: [
      { name: 'Carne magra de pato horneada', category: 'protein', baseGramsFor10kgPetPerDay: 95, notes: 'Hornear 35 min' },
      { name: 'Calabaza cocida', category: 'vegetable', baseGramsFor10kgPetPerDay: 18, notes: 'Cocer 15 min' },
      { name: 'Taurina felina', category: 'supplement_calcium', baseGramsFor10kgPetPerDay: 0.5, notes: 'Al templar' },
      { name: 'Glucosamina felina', category: 'supplement_calcium', baseGramsFor10kgPetPerDay: 1, notes: 'Articular' },
      { name: 'Aceite de salmón', category: 'healthy_fat', baseGramsFor10kgPetPerDay: 2, notes: 'Omega 3' },
      { name: 'Cáscara de huevo molida', category: 'supplement_calcium', baseGramsFor10kgPetPerDay: 2, notes: 'Calcio' }
    ],
    instructions: [
      'Hornear el pato 35 minutos escurriendo el exceso graso.',
      'Cocer la calabaza 15 minutos y aplastar fino.',
      'Mezclar en templado e incorporar taurina, glucosamina, aceite de salmón y cáscara de huevo.'
    ],
    storageInfo: 'Nevera 48h, congelador 2 meses.',
    macronutrients: { proteinPct: 54, fatPct: 27, fiberCarbPct: 3, moisturePct: 77 }
  },
  {
    id: 'cat-sen-26',
    title: 'Trucha con Judías Verdes para Gatos Senior ⭐',
    frenchTitle: 'Truite de Ligne Haricots Fins & Omega 3 Chat Senior',
    species: 'cat',
    growthStage: 'senior',
    category: 'joint_omega3',
    categoryLabel: 'Receta Premium Pescado de Río & Articulaciones',
    description: 'Premium. Trucha 12 min y judías verdes 12 min. Añadir taurina, aceite de salmón y cáscara de huevo.',
    kcalPer100g: 125,
    prepTimeMin: 15,
    cookTimeMin: 15,
    difficulty: 'Fácil',
    suitability: 'Gatos mayores que precisan una dieta ligera rica en omega 3',
    clinicalBenefits: ['Bajo tenor de sodio natural', 'Soporte articular y circulatorio', 'Taurina'],
    ingredients: [
      { name: 'Trucha fresca al vapor sin espinas', category: 'protein', baseGramsFor10kgPetPerDay: 100, notes: 'Cocer 12 min' },
      { name: 'Judías verdes cocidas tiernas', category: 'vegetable', baseGramsFor10kgPetPerDay: 15, notes: 'Cocer 12 min' },
      { name: 'Taurina felina', category: 'supplement_calcium', baseGramsFor10kgPetPerDay: 0.5, notes: 'Al templar' },
      { name: 'Aceite de salmón', category: 'healthy_fat', baseGramsFor10kgPetPerDay: 2, notes: 'Omega 3' },
      { name: 'Cáscara de huevo en polvo', category: 'supplement_calcium', baseGramsFor10kgPetPerDay: 2, notes: 'Calcio' }
    ],
    instructions: [
      'Cocinar la trucha al vapor 12 minutos retirando escrupulosamente toda espina.',
      'Cocer las judías 12 minutos y trocear fino.',
      'Unir todo en tibio y agregar taurina, aceite de salmón y cáscara de huevo.'
    ],
    storageInfo: 'Nevera 48 horas.',
    macronutrients: { proteinPct: 53, fatPct: 26, fiberCarbPct: 3, moisturePct: 78 }
  },
  {
    id: 'cat-sen-27',
    title: 'Salmón con Calabacín y Espinaca para Gatos Senior ⭐',
    frenchTitle: 'Saumon Rose aux Feuilles d’Épinards & Courgettes Chat Senior',
    species: 'cat',
    growthStage: 'senior',
    category: 'joint_omega3',
    categoryLabel: 'Receta Premium Doble Antioxidante & Omega 3',
    description: 'Premium. Hornear salmón 12 min, calabacín 10 min y espinaca 5 min. Incorporar taurina, omega 3 y cáscara de huevo.',
    kcalPer100g: 130,
    prepTimeMin: 15,
    cookTimeMin: 15,
    difficulty: 'Fácil',
    suitability: 'Gatos mayores con opacidad del cristalino o rigidez postural',
    clinicalBenefits: ['Luteína botánica combinada con DHA marino', 'Taurina para miocardio', 'Calcio'],
    ingredients: [
      { name: 'Salmón al horno sin espinas', category: 'protein', baseGramsFor10kgPetPerDay: 95, notes: 'Hornear 12 min' },
      { name: 'Calabacín cocido', category: 'vegetable', baseGramsFor10kgPetPerDay: 12, notes: 'Cocer 10 min' },
      { name: 'Espinacas escaldadas', category: 'vegetable', baseGramsFor10kgPetPerDay: 5, notes: 'Escaldar 5 min' },
      { name: 'Taurina felina', category: 'supplement_calcium', baseGramsFor10kgPetPerDay: 0.5, notes: 'Al templar' },
      { name: 'Aceite de salmón', category: 'healthy_fat', baseGramsFor10kgPetPerDay: 2, notes: 'Omega 3' },
      { name: 'Cáscara de huevo molida', category: 'supplement_calcium', baseGramsFor10kgPetPerDay: 2, notes: 'Calcio' }
    ],
    instructions: [
      'Hornear el salmón 12 minutos asegurando la ausencia total de espinas.',
      'Cocer el calabacín y escaldar las espinacas aplastando en puré verde suave.',
      'Mezclar en templado e incorporar taurina, aceite de salmón y cáscara de huevo.'
    ],
    storageInfo: 'Nevera 48 horas.',
    macronutrients: { proteinPct: 52, fatPct: 27, fiberCarbPct: 3, moisturePct: 78 }
  },
  {
    id: 'cat-sen-28',
    title: 'Pavo con Hígado y Calabaza para Gatos Senior ⭐',
    frenchTitle: 'Dinde au Foie Tendre Potiron & Condroprotecteurs Chat Senior',
    species: 'cat',
    growthStage: 'senior',
    category: 'joint_omega3',
    categoryLabel: 'Receta Premium Vitamina A & Condroprotectores',
    description: 'Premium. Cocer pavo 20 min, hígado 7 min y calabaza 15 min. Añadir taurina, condroprotectores y cáscara de huevo.',
    kcalPer100g: 125,
    prepTimeMin: 15,
    cookTimeMin: 20,
    difficulty: 'Fácil',
    suitability: 'Gatos mayores con pelaje ralo y falta de fuerza articular',
    clinicalBenefits: ['Vitamina A biodisponible', 'Condroprotectores para regeneración articular', 'Taurina'],
    ingredients: [
      { name: 'Pechuga de pavo cocida', category: 'protein', baseGramsFor10kgPetPerDay: 90, notes: 'Cocer 20 min' },
      { name: 'Hígado de pavo o pollo', category: 'organ_meat', baseGramsFor10kgPetPerDay: 10, notes: 'Cocer 7 min' },
      { name: 'Calabaza cocida', category: 'vegetable', baseGramsFor10kgPetPerDay: 18, notes: 'Cocer 15 min' },
      { name: 'Taurina felina', category: 'supplement_calcium', baseGramsFor10kgPetPerDay: 0.5, notes: 'Al templar' },
      { name: 'Condroprotectores felinos', category: 'supplement_calcium', baseGramsFor10kgPetPerDay: 1, notes: 'Articular' },
      { name: 'Cáscara de huevo molida', category: 'supplement_calcium', baseGramsFor10kgPetPerDay: 2, notes: 'Calcio' }
    ],
    instructions: [
      'Cocer el pavo 20 minutos y el hígado en los últimos 7 minutos.',
      'Cocer la calabaza 15 minutos y aplastar fino.',
      'Desmigar las carnes, unir al puré y mezclar con taurina, condroprotectores y calcio en templado.'
    ],
    storageInfo: 'Nevera 48h, congelador 2 meses.',
    macronutrients: { proteinPct: 56, fatPct: 24, fiberCarbPct: 3, moisturePct: 78 }
  },
  {
    id: 'cat-sen-29',
    title: 'Bacalao con Espinaca para Gatos Senior ⭐',
    frenchTitle: 'Cabillaud Vapeur Épinards & Glucosamine Chat Senior',
    species: 'cat',
    growthStage: 'senior',
    category: 'joint_omega3',
    categoryLabel: 'Receta Premium Cuidado Renal & Glucosamina Senior',
    description: 'Premium. Bacalao al vapor 10 min y espinaca 5 min. Terminar con taurina, glucosamina y cáscara de huevo.',
    kcalPer100g: 105,
    prepTimeMin: 10,
    cookTimeMin: 10,
    difficulty: 'Fácil',
    suitability: 'Gatos mayores con riñones frágiles que necesitan alivio en sus articulaciones',
    clinicalBenefits: ['Mínimo residuo metabólico nitrogenado', 'Glucosamina protectora sinovial', 'Taurina'],
    ingredients: [
      { name: 'Bacalao fresco al vapor desespinado', category: 'protein', baseGramsFor10kgPetPerDay: 110, notes: 'Al vapor 10 min' },
      { name: 'Espinacas escaldadas picadas', category: 'vegetable', baseGramsFor10kgPetPerDay: 12, notes: 'Escaldar 5 min' },
      { name: 'Taurina felina', category: 'supplement_calcium', baseGramsFor10kgPetPerDay: 0.5, notes: 'Al templar' },
      { name: 'Glucosamina felina', category: 'supplement_calcium', baseGramsFor10kgPetPerDay: 1, notes: 'Articular' },
      { name: 'Aceite de linaza', category: 'healthy_fat', baseGramsFor10kgPetPerDay: 2, notes: 'En crudo' },
      { name: 'Cáscara de huevo en polvo', category: 'supplement_calcium', baseGramsFor10kgPetPerDay: 2, notes: 'Calcio' }
    ],
    instructions: [
      'Cocinar el bacalao al vapor 10 minutos retirando todas las espinas.',
      'Escaldar las espinacas 5 minutos y machacar con tenedor.',
      'Mezclar en templado e incorporar la taurina, la glucosamina, el aceite de linaza y la cáscara de huevo.'
    ],
    storageInfo: 'Nevera 48 horas.',
    macronutrients: { proteinPct: 55, fatPct: 20, fiberCarbPct: 3, moisturePct: 82 }
  },
  {
    id: 'cat-sen-30',
    title: 'Pollo con Calabaza y Condroprotectores para Gatos Senior ⭐',
    frenchTitle: 'Poulet Tendre Potiron & Cure Articulaire Chat Senior',
    species: 'cat',
    growthStage: 'senior',
    category: 'joint_omega3',
    categoryLabel: 'Receta Premium Cuidado Articular & Flora Digestiva',
    description: 'Premium. Cocer pollo 20 min y calabaza 15 min. Incorporar taurina, condroprotectores y cáscara de huevo.',
    kcalPer100g: 120,
    prepTimeMin: 15,
    cookTimeMin: 20,
    difficulty: 'Fácil',
    suitability: 'Gatos mayores para mantener la agilidad y el bienestar diario',
    clinicalBenefits: ['Preserva el grosor del cartílago hialino', 'Calabaza emoliente contra heces secas', 'Taurina'],
    ingredients: [
      { name: 'Pechuga de pollo cocida', category: 'protein', baseGramsFor10kgPetPerDay: 100, notes: 'Cocer 20 min' },
      { name: 'Calabaza cocida en puré', category: 'vegetable', baseGramsFor10kgPetPerDay: 20, notes: 'Cocer 15 min' },
      { name: 'Taurina felina', category: 'supplement_calcium', baseGramsFor10kgPetPerDay: 0.5, notes: 'Al templar' },
      { name: 'Condroprotectores felinos', category: 'supplement_calcium', baseGramsFor10kgPetPerDay: 1, notes: 'Glucosamina/condroitina' },
      { name: 'Aceite de salmón', category: 'healthy_fat', baseGramsFor10kgPetPerDay: 2, notes: 'Omega 3' },
      { name: 'Cáscara de huevo molida', category: 'supplement_calcium', baseGramsFor10kgPetPerDay: 2, notes: 'Calcio' }
    ],
    instructions: [
      'Cocer el pollo 20 minutos y desmigar finamente.',
      'Cocer la calabaza 15 minutos formando un puré suave.',
      'Mezclar en templado e incorporar taurina, condroprotectores, aceite de salmón y cáscara de huevo.'
    ],
    storageInfo: 'Nevera 48h, congelador 2 meses.',
    macronutrients: { proteinPct: 56, fatPct: 23, fiberCarbPct: 3, moisturePct: 79 }
  }
];
