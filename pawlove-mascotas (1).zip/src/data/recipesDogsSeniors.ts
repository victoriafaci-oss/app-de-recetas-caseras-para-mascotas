import { Recipe } from '../types';

export const DOG_SENIOR_RECIPES: Recipe[] = [
  {
    id: 'dog-sen-01',
    title: 'Conejo Guisado con Arroz y Zanahoria para Perros Senior',
    frenchTitle: 'Lapin Braisé au Riz Tendre & Carottes Senior',
    species: 'dog',
    growthStage: 'senior',
    category: 'sensitive_digestion',
    categoryLabel: 'Digestión Fácil & Baja Grasa Senior',
    description: 'Cocer conejo 35 min, arroz 25 min y zanahoria 15 min. Añadir aceite de salmón, probióticos y cáscara de huevo.',
    kcalPer100g: 120,
    prepTimeMin: 15,
    cookTimeMin: 35,
    difficulty: 'Fácil',
    suitability: 'Perros senior (+7 años) que necesitan proteína magra digestiva para evitar sarcopenia',
    clinicalBenefits: ['Proteína magra sin fatiga renal ni hepática', 'Arroz sobrecocido emoliente para tracto intestinal lento', 'Probióticos y Omega 3'],
    ingredients: [
      { name: 'Carne de conejo deshuesada', category: 'protein', baseGramsFor10kgPetPerDay: 190, notes: 'Cocer 35 min' },
      { name: 'Arroz blanco bien cocido', category: 'fiber_carb', baseGramsFor10kgPetPerDay: 60, notes: 'Cocer 25 min' },
      { name: 'Zanahoria muy tierna', category: 'vegetable', baseGramsFor10kgPetPerDay: 50, notes: 'Cocer 15 min' },
      { name: 'Aceite de salmón', category: 'healthy_fat', baseGramsFor10kgPetPerDay: 3, notes: 'Omega 3' },
      { name: 'Probióticos caninos', category: 'supplement_calcium', baseGramsFor10kgPetPerDay: 3, notes: 'Al templar' },
      { name: 'Cáscara de huevo molida', category: 'supplement_calcium', baseGramsFor10kgPetPerDay: 4, notes: 'Calcio' }
    ],
    instructions: [
      'Cocer el conejo 35 minutos y desmigar meticulosamente retirando huesos.',
      'Cocer el arroz 25 minutos hasta que esté muy tierno y la zanahoria 15 minutos.',
      'Mezclar todo y agregar aceite de salmón, probióticos y cáscara de huevo en templado.'
    ],
    storageInfo: 'Nevera 3 días, congelador 2 meses.',
    macronutrients: { proteinPct: 46, fatPct: 14, fiberCarbPct: 24, moisturePct: 79 }
  },
  {
    id: 'dog-sen-02',
    title: 'Cordero con Arroz Integral para Perros Senior',
    frenchTitle: 'Agneau Fondant au Riz Complet Senior',
    species: 'dog',
    growthStage: 'senior',
    category: 'vitality_gourmet',
    categoryLabel: 'Reconfortante & Tránsito Intestinal',
    description: 'Estofar cordero 35 min y cocer arroz integral 25 min. Incorporar probióticos, cáscara de huevo y dejar templar.',
    kcalPer100g: 135,
    prepTimeMin: 15,
    cookTimeMin: 35,
    difficulty: 'Fácil',
    suitability: 'Perros mayores frioleros o inapetentes que necesitan aromas intensos',
    clinicalBenefits: ['L-carnitina y zinc para función muscular y sensorial', 'Fibra insoluble para prevenir estreñimiento en perros mayores', 'Probióticos'],
    ingredients: [
      { name: 'Cordero magro desgrasado', category: 'protein', baseGramsFor10kgPetPerDay: 180, notes: 'Estofar 35 min' },
      { name: 'Arroz integral muy cocido', category: 'fiber_carb', baseGramsFor10kgPetPerDay: 60, notes: 'Cocer 25 min' },
      { name: 'Calabacín tierno cocido', category: 'vegetable', baseGramsFor10kgPetPerDay: 45, notes: 'Cocer 10 min' },
      { name: 'Probióticos caninos', category: 'supplement_calcium', baseGramsFor10kgPetPerDay: 3, notes: 'Al templar' },
      { name: 'Cáscara de huevo molida', category: 'supplement_calcium', baseGramsFor10kgPetPerDay: 4, notes: 'Calcio' }
    ],
    instructions: [
      'Estofar el cordero 35 minutos escurriendo cualquier exceso graso.',
      'Cocer el arroz integral 25 minutos y el calabacín 10 minutos.',
      'Unir todo machacando ligeramente e incorporar probióticos y calcio en templado.'
    ],
    storageInfo: 'Nevera 3 días, congelador 2 meses.',
    macronutrients: { proteinPct: 47, fatPct: 17, fiberCarbPct: 22, moisturePct: 77 }
  },
  {
    id: 'dog-sen-03',
    title: 'Bacalao con Calabaza y Zanahoria para Perros Senior',
    frenchTitle: 'Cabillaud Délicat Potimarron & Condroprotecteurs',
    species: 'dog',
    growthStage: 'senior',
    category: 'joint_omega3',
    categoryLabel: 'Articular & Condroprotectores Senior',
    description: 'Bacalao al vapor 10 min, calabaza 15 min y zanahoria 15 min. Añadir aceite de linaza y condroprotectores.',
    kcalPer100g: 105,
    prepTimeMin: 10,
    cookTimeMin: 15,
    difficulty: 'Fácil',
    suitability: 'Perros senior con artrosis, rigidez de caderas y digestión lenta',
    clinicalBenefits: ['Condroprotectores para regeneración de la matriz cartilaginosa', 'Mínimo fósforo y grasa para cuidar riñón senior', 'Linaza'],
    ingredients: [
      { name: 'Bacalao fresco al vapor desespinado', category: 'protein', baseGramsFor10kgPetPerDay: 210, notes: 'Al vapor 10 min' },
      { name: 'Calabaza cocida', category: 'vegetable', baseGramsFor10kgPetPerDay: 60, notes: 'Cocer 15 min' },
      { name: 'Zanahoria tierna', category: 'vegetable', baseGramsFor10kgPetPerDay: 50, notes: 'Cocer 15 min' },
      { name: 'Condroprotectores (glucosamina/condroitina)', category: 'supplement_calcium', baseGramsFor10kgPetPerDay: 2, notes: 'Apoyo articular senior' },
      { name: 'Aceite de linaza', category: 'healthy_fat', baseGramsFor10kgPetPerDay: 3, notes: 'En crudo' },
      { name: 'Cáscara de huevo molida', category: 'supplement_calcium', baseGramsFor10kgPetPerDay: 4, notes: 'Calcio' }
    ],
    instructions: [
      'Cocinar el bacalao al vapor 10 minutos y comprobar ausencia de espinas.',
      'Hervir la calabaza y zanahoria 15 minutos y aplastar en puré suave.',
      'Mezclar e integrar condroprotectores, aceite de linaza y cáscara de huevo.'
    ],
    storageInfo: 'Nevera 48h, congelador 2 meses.',
    macronutrients: { proteinPct: 47, fatPct: 11, fiberCarbPct: 22, moisturePct: 82 }
  },
  {
    id: 'dog-sen-04',
    title: 'Trucha con Arroz Salvaje para Perros Senior',
    frenchTitle: 'Truite de Montagne au Riz Sauvage Senior',
    species: 'dog',
    growthStage: 'senior',
    category: 'joint_omega3',
    categoryLabel: 'Omega 3 Cerebral & Articular',
    description: 'Trucha 12 min y arroz salvaje 30 min. Terminar con aceite de salmón, probióticos y cáscara de huevo.',
    kcalPer100g: 125,
    prepTimeMin: 15,
    cookTimeMin: 30,
    difficulty: 'Fácil',
    suitability: 'Perros senior con síndrome de disfunción cognitiva o desgaste osteoarticular',
    clinicalBenefits: ['DHA para preservar sinapsis cerebrales en perros ancianos', 'Arroz salvaje rico en manganeso y zinc', 'Probióticos'],
    ingredients: [
      { name: 'Trucha limpia desespinada', category: 'protein', baseGramsFor10kgPetPerDay: 190, notes: 'Cocer 12 min' },
      { name: 'Arroz salvaje bien cocido', category: 'fiber_carb', baseGramsFor10kgPetPerDay: 55, notes: 'Cocer 30 min' },
      { name: 'Calabacín al vapor', category: 'vegetable', baseGramsFor10kgPetPerDay: 45, notes: 'Cocer 10 min' },
      { name: 'Aceite de salmón', category: 'healthy_fat', baseGramsFor10kgPetPerDay: 4, notes: 'Omega 3' },
      { name: 'Probióticos caninos', category: 'supplement_calcium', baseGramsFor10kgPetPerDay: 3, notes: 'Al templar' },
      { name: 'Cáscara de huevo en polvo', category: 'supplement_calcium', baseGramsFor10kgPetPerDay: 4, notes: 'Calcio' }
    ],
    instructions: [
      'Cocer el arroz salvaje 30 minutos.',
      'Cocinar la trucha 12 minutos y desmenuzar con las manos verificando espinas.',
      'Mezclar todo con el aceite de salmón, probióticos y calcio en templado.'
    ],
    storageInfo: 'Nevera 48h, congelador 2 meses.',
    macronutrients: { proteinPct: 45, fatPct: 16, fiberCarbPct: 24, moisturePct: 78 }
  },
  {
    id: 'dog-sen-05',
    title: 'Pavo con Lenteja Roja para Perros Senior',
    frenchTitle: 'Dinde Douce aux Lentilles Corail & Glucosamine',
    species: 'dog',
    growthStage: 'senior',
    category: 'sensitive_digestion',
    categoryLabel: 'Proteína Blanca & Glucosamina Senior',
    description: 'Cocer pavo 20 min y lenteja roja 15 min. Añadir glucosamina, aceite de linaza y cáscara de huevo.',
    kcalPer100g: 125,
    prepTimeMin: 15,
    cookTimeMin: 20,
    difficulty: 'Fácil',
    suitability: 'Perros senior que toleran mal carbohidratos pesados o granos',
    clinicalBenefits: ['Lenteja roja sin hollejo que no genera gases', 'Pavo magro con triptófano para descanso nocturno reparador', 'Glucosamina'],
    ingredients: [
      { name: 'Pechuga de pavo', category: 'protein', baseGramsFor10kgPetPerDay: 190, notes: 'Cocer 20 min' },
      { name: 'Lenteja roja cocida cremosa', category: 'fiber_carb', baseGramsFor10kgPetPerDay: 55, notes: 'Cocer 15 min' },
      { name: 'Calabaza suave', category: 'vegetable', baseGramsFor10kgPetPerDay: 45, notes: 'Cocer 12 min' },
      { name: 'Glucosamina canina', category: 'supplement_calcium', baseGramsFor10kgPetPerDay: 2, notes: 'Protector articular' },
      { name: 'Aceite de linaza', category: 'healthy_fat', baseGramsFor10kgPetPerDay: 3, notes: 'En crudo' },
      { name: 'Cáscara de huevo molida', category: 'supplement_calcium', baseGramsFor10kgPetPerDay: 4, notes: 'Calcio' }
    ],
    instructions: [
      'Hervir el pavo 20 minutos y trocear fino.',
      'Cocer la lenteja roja 15 minutos con la calabaza hasta consistencia de puré.',
      'Mezclar e incorporar la glucosamina, el aceite de linaza y la cáscara de huevo.'
    ],
    storageInfo: 'Nevera 3 días, congelador 2 meses.',
    macronutrients: { proteinPct: 48, fatPct: 14, fiberCarbPct: 23, moisturePct: 78 }
  },
  {
    id: 'dog-sen-06',
    title: 'Salmón con Calabaza y Zanahoria para Perros Senior',
    frenchTitle: 'Saumon Délicat au Potiron & Carottes Senior',
    species: 'dog',
    growthStage: 'senior',
    category: 'joint_omega3',
    categoryLabel: 'Piel Madura, Articulaciones & Probióticos',
    description: 'Hornear salmón 12 min, calabaza 15 min y zanahoria 15 min. Añadir omega 3, probióticos y cáscara de huevo.',
    kcalPer100g: 130,
    prepTimeMin: 15,
    cookTimeMin: 15,
    difficulty: 'Fácil',
    suitability: 'Perros ancianos con piel fina, pérdida de densidad en pelaje y dolor articular',
    clinicalBenefits: ['Acción antiinflamatoria sistémica por ácidos grasos marinos', 'Calabaza reconfortante digestiva', 'Probióticos'],
    ingredients: [
      { name: 'Salmón horneado sin espinas', category: 'protein', baseGramsFor10kgPetPerDay: 190, notes: 'Hornear 12 min' },
      { name: 'Calabaza cocida', category: 'vegetable', baseGramsFor10kgPetPerDay: 55, notes: 'Cocer 15 min' },
      { name: 'Zanahoria cocida', category: 'vegetable', baseGramsFor10kgPetPerDay: 45, notes: 'Cocer 15 min' },
      { name: 'Aceite de salmón / Omega 3', category: 'healthy_fat', baseGramsFor10kgPetPerDay: 4, notes: 'Al templar' },
      { name: 'Probióticos caninos', category: 'supplement_calcium', baseGramsFor10kgPetPerDay: 3, notes: 'Al servir' },
      { name: 'Cáscara de huevo molida', category: 'supplement_calcium', baseGramsFor10kgPetPerDay: 4, notes: 'Calcio' }
    ],
    instructions: [
      'Hornear el salmón 12 minutos y desmenuzar con tenedor revisando espinas.',
      'Hervir la calabaza y la zanahoria 15 minutos y machacar.',
      'Mezclar todo y agregar el aceite omega 3, los probióticos y la cáscara de huevo al templar.'
    ],
    storageInfo: 'Nevera 48h, congelador 2 meses.',
    macronutrients: { proteinPct: 45, fatPct: 18, fiberCarbPct: 22, moisturePct: 78 }
  },
  {
    id: 'dog-sen-07',
    title: 'Pollo con Hígado y Arroz Integral para Perros Senior',
    frenchTitle: 'Poulet au Foie & Riz Complet Senior',
    species: 'dog',
    growthStage: 'senior',
    category: 'vitality_gourmet',
    categoryLabel: 'Hierro & Vitaminas B para Longevidad',
    description: 'Cocer pollo 20 min, hígado 7 min y arroz integral 25 min. Incorporar probióticos, cáscara de huevo y dejar templar.',
    kcalPer100g: 130,
    prepTimeMin: 15,
    cookTimeMin: 25,
    difficulty: 'Fácil',
    suitability: 'Perros mayores con menor vitalidad y necesidad de soporte hematopoyético',
    clinicalBenefits: ['Hígado en dosis controlada para aporte de vitamina A y B12', 'Arroz integral para tránsito intestinal regular', 'Probióticos'],
    ingredients: [
      { name: 'Pechuga de pollo', category: 'protein', baseGramsFor10kgPetPerDay: 175, notes: 'Cocer 20 min' },
      { name: 'Hígado de pollo fresco', category: 'protein', baseGramsFor10kgPetPerDay: 15, notes: 'Cocer 7 min' },
      { name: 'Arroz integral cocido', category: 'fiber_carb', baseGramsFor10kgPetPerDay: 60, notes: 'Cocer 25 min' },
      { name: 'Probióticos caninos', category: 'supplement_calcium', baseGramsFor10kgPetPerDay: 3, notes: 'Al templar' },
      { name: 'Cáscara de huevo en polvo', category: 'supplement_calcium', baseGramsFor10kgPetPerDay: 4, notes: 'Calcio' }
    ],
    instructions: [
      'Cocer el pollo 20 minutos añadiendo el hígado en los últimos 7 minutos.',
      'Cocer el arroz integral 25 minutos.',
      'Picar las carnes fino, unir al arroz y añadir los probióticos y la cáscara de huevo al templar.'
    ],
    storageInfo: 'Nevera 3 días, congelador 2 meses.',
    macronutrients: { proteinPct: 49, fatPct: 15, fiberCarbPct: 24, moisturePct: 77 }
  },
  {
    id: 'dog-sen-08',
    title: 'Merluza con Boniato y Calabacín para Perros Senior',
    frenchTitle: 'Colin Fin à la Patate Douce & Condroprotecteurs',
    species: 'dog',
    growthStage: 'senior',
    category: 'joint_omega3',
    categoryLabel: 'Alta Asimilación & Condroprotección',
    description: 'Merluza al vapor 10 min, boniato 20 min y calabacín 10 min. Añadir aceite de linaza y condroprotectores.',
    kcalPer100g: 110,
    prepTimeMin: 15,
    cookTimeMin: 20,
    difficulty: 'Fácil',
    suitability: 'Perros mayores con dentadura delicada y dolores articulares',
    clinicalBenefits: ['Textura blanda que no exige fuerza mandibular', 'Condroprotectores para proteger cartílagos', 'Aceite de linaza'],
    ingredients: [
      { name: 'Lomos de merluza sin espinas', category: 'protein', baseGramsFor10kgPetPerDay: 210, notes: 'Al vapor 10 min' },
      { name: 'Boniato cocido pelado', category: 'fiber_carb', baseGramsFor10kgPetPerDay: 60, notes: 'Cocer 20 min' },
      { name: 'Calabacín en dados tiernos', category: 'vegetable', baseGramsFor10kgPetPerDay: 45, notes: 'Cocer 10 min' },
      { name: 'Condroprotectores (glucosamina)', category: 'supplement_calcium', baseGramsFor10kgPetPerDay: 2, notes: 'Articular' },
      { name: 'Aceite de linaza', category: 'healthy_fat', baseGramsFor10kgPetPerDay: 3, notes: 'En crudo' },
      { name: 'Cáscara de huevo en polvo', category: 'supplement_calcium', baseGramsFor10kgPetPerDay: 4, notes: 'Calcio' }
    ],
    instructions: [
      'Cocer la merluza al vapor 10 minutos y revisar espinas minuciosamente.',
      'Cocer el boniato 20 minutos y el calabacín 10 minutos.',
      'Aplastar con tenedor y mezclar con la glucosamina, el aceite de linaza y la cáscara de huevo.'
    ],
    storageInfo: 'Nevera 48h, congelador 2 meses.',
    macronutrients: { proteinPct: 45, fatPct: 12, fiberCarbPct: 24, moisturePct: 81 }
  },
  {
    id: 'dog-sen-09',
    title: 'Pato con Quinoa y Manzana para Perros Senior',
    frenchTitle: 'Canard au Quinoa & Purée de Pomme Senior',
    species: 'dog',
    growthStage: 'senior',
    category: 'vitality_gourmet',
    categoryLabel: 'Antioxidantes Naturales & Palatabilidad',
    description: 'Hornear pato 40 min, quinoa 15 min y manzana cocida 8 min. Terminar con probióticos, aceite de salmón y cáscara de huevo.',
    kcalPer100g: 135,
    prepTimeMin: 15,
    cookTimeMin: 40,
    difficulty: 'Fácil',
    suitability: 'Perros senior que han perdido el sentido del olfato y necesitan olores apetitosos',
    clinicalBenefits: ['Pectina de manzana para atrapar toxinas colónicas', 'Pato aromático que incentiva la ingesta', 'Probióticos y Omega 3'],
    ingredients: [
      { name: 'Carne magra de pato sin grasa sobrante', category: 'protein', baseGramsFor10kgPetPerDay: 180, notes: 'Hornear 40 min' },
      { name: 'Quinoa cocida', category: 'fiber_carb', baseGramsFor10kgPetPerDay: 55, notes: 'Cocer 15 min' },
      { name: 'Manzana pelada cocida en compota', category: 'vegetable', baseGramsFor10kgPetPerDay: 40, notes: 'Cocer 8 min' },
      { name: 'Aceite de salmón', category: 'healthy_fat', baseGramsFor10kgPetPerDay: 4, notes: 'Omega 3' },
      { name: 'Probióticos caninos', category: 'supplement_calcium', baseGramsFor10kgPetPerDay: 3, notes: 'Al templar' },
      { name: 'Cáscara de huevo molida', category: 'supplement_calcium', baseGramsFor10kgPetPerDay: 4, notes: 'Calcio' }
    ],
    instructions: [
      'Hornear el pato 40 minutos escurriendo bien la grasa.',
      'Cocer la quinoa 15 minutos y la manzana 8 minutos hasta formar compota.',
      'Mezclar todo e incorporar probióticos, aceite de salmón y cáscara de huevo al templar.'
    ],
    storageInfo: 'Nevera 3 días, congelador 2 meses.',
    macronutrients: { proteinPct: 47, fatPct: 18, fiberCarbPct: 23, moisturePct: 76 }
  },
  {
    id: 'dog-sen-10',
    title: 'Conejo con Arroz Integral y Zanahoria para Perros Senior',
    frenchTitle: 'Lapin Mijoté au Riz Complet & Glucosamine',
    species: 'dog',
    growthStage: 'senior',
    category: 'joint_omega3',
    categoryLabel: 'Glucosamina & Protección Articular Senior',
    description: 'Cocer conejo 35 min, arroz integral 25 min y zanahoria 15 min. Añadir glucosamina, aceite de linaza y cáscara de huevo.',
    kcalPer100g: 125,
    prepTimeMin: 15,
    cookTimeMin: 35,
    difficulty: 'Fácil',
    suitability: 'Perros senior con movilidad reducida y necesidad de control de peso',
    clinicalBenefits: ['Proteína muy magra que no favorece el sobrepeso', 'Glucosamina para amortiguación articular', 'Linaza vegetal'],
    ingredients: [
      { name: 'Carne de conejo deshuesada', category: 'protein', baseGramsFor10kgPetPerDay: 190, notes: 'Cocer 35 min' },
      { name: 'Arroz integral muy cocido', category: 'fiber_carb', baseGramsFor10kgPetPerDay: 60, notes: 'Cocer 25 min' },
      { name: 'Zanahoria tierna picada', category: 'vegetable', baseGramsFor10kgPetPerDay: 45, notes: 'Cocer 15 min' },
      { name: 'Glucosamina canina', category: 'supplement_calcium', baseGramsFor10kgPetPerDay: 2, notes: 'Articular' },
      { name: 'Aceite de linaza', category: 'healthy_fat', baseGramsFor10kgPetPerDay: 3, notes: 'En crudo' },
      { name: 'Cáscara de huevo molida', category: 'supplement_calcium', baseGramsFor10kgPetPerDay: 4, notes: 'Calcio' }
    ],
    instructions: [
      'Cocer el conejo 35 minutos y desmigar meticulosamente descartando huesos.',
      'Cocer el arroz integral 25 minutos y la zanahoria 15 minutos.',
      'Unir todo con la glucosamina, el aceite de linaza y la cáscara de huevo molida.'
    ],
    storageInfo: 'Nevera 3 días, congelador 2 meses.',
    macronutrients: { proteinPct: 48, fatPct: 14, fiberCarbPct: 23, moisturePct: 78 }
  },
  {
    id: 'dog-sen-11',
    title: 'Ternera con Patata y Zanahoria para Perros Senior',
    frenchTitle: 'Bœuf Tendre aux Pommes de Terre & Carottes Senior',
    species: 'dog',
    growthStage: 'senior',
    category: 'vitality_gourmet',
    categoryLabel: 'Palatabilidad Suave & Fuerza',
    description: 'Cocer ternera 30 min, patata 20 min y zanahoria 15 min. Incorporar aceite de salmón, cáscara de huevo y dejar templar.',
    kcalPer100g: 135,
    prepTimeMin: 15,
    cookTimeMin: 30,
    difficulty: 'Fácil',
    suitability: 'Perros mayores que conservan buen apetito y requieren mantener masa muscular',
    clinicalBenefits: ['Hierro y creatina para vitalidad muscular', 'Patata suave sin irritantes', 'Omega 3 marino'],
    ingredients: [
      { name: 'Ternera magra en trozos pequeños', category: 'protein', baseGramsFor10kgPetPerDay: 180, notes: 'Cocer 30 min' },
      { name: 'Patata cocida pelada', category: 'fiber_carb', baseGramsFor10kgPetPerDay: 65, notes: 'Cocer 20 min' },
      { name: 'Zanahoria en dados tiernos', category: 'vegetable', baseGramsFor10kgPetPerDay: 45, notes: 'Cocer 15 min' },
      { name: 'Aceite de salmón', category: 'healthy_fat', baseGramsFor10kgPetPerDay: 4, notes: 'Omega 3' },
      { name: 'Cáscara de huevo en polvo', category: 'supplement_calcium', baseGramsFor10kgPetPerDay: 4, notes: 'Calcio' }
    ],
    instructions: [
      'Cocer la ternera magra 30 minutos.',
      'Cocer la patata 20 minutos y la zanahoria 15 minutos.',
      'Mezclar todo aplastando ligeramente con tenedor e incorporar aceite de salmón y calcio al templar.'
    ],
    storageInfo: 'Nevera 3 días, congelador 2 meses.',
    macronutrients: { proteinPct: 48, fatPct: 17, fiberCarbPct: 23, moisturePct: 77 }
  },
  {
    id: 'dog-sen-12',
    title: 'Bacalao con Arroz Integral y Espinaca para Perros Senior',
    frenchTitle: 'Cabillaud au Riz Brun & Épinards Senior',
    species: 'dog',
    growthStage: 'senior',
    category: 'sensitive_digestion',
    categoryLabel: 'Digestibilidad Máxima & Perfil Suave',
    description: 'Bacalao al vapor 10 min, arroz integral 25 min y espinaca 5 min. Añadir omega 3, probióticos y cáscara de huevo.',
    kcalPer100g: 115,
    prepTimeMin: 15,
    cookTimeMin: 25,
    difficulty: 'Fácil',
    suitability: 'Perros ancianos con digestiones pesadas o problemas de acumulación lipídica',
    clinicalBenefits: ['Pescado blanco sin grasa que reposa el páncreas', 'Arroz integral rico en magnesio', 'Probióticos'],
    ingredients: [
      { name: 'Bacalao fresco al vapor sin espinas', category: 'protein', baseGramsFor10kgPetPerDay: 210, notes: 'Al vapor 10 min' },
      { name: 'Arroz integral cocido', category: 'fiber_carb', baseGramsFor10kgPetPerDay: 60, notes: 'Cocer 25 min' },
      { name: 'Espinacas tiernas escaldadas', category: 'vegetable', baseGramsFor10kgPetPerDay: 35, notes: 'Escaldar 5 min' },
      { name: 'Omega 3 / Aceite de salmón', category: 'healthy_fat', baseGramsFor10kgPetPerDay: 4, notes: 'Al templar' },
      { name: 'Probióticos caninos', category: 'supplement_calcium', baseGramsFor10kgPetPerDay: 3, notes: 'Al servir' },
      { name: 'Cáscara de huevo molida', category: 'supplement_calcium', baseGramsFor10kgPetPerDay: 4, notes: 'Calcio' }
    ],
    instructions: [
      'Cocinar el bacalao 10 minutos al vapor y desmigar revisando espinas.',
      'Cocer el arroz 25 minutos y escaldar la espinaca 5 minutos.',
      'Mezclar e incorporar el omega 3, los probióticos y la cáscara de huevo.'
    ],
    storageInfo: 'Nevera 48h, congelador 2 meses.',
    macronutrients: { proteinPct: 47, fatPct: 12, fiberCarbPct: 24, moisturePct: 80 }
  },
  {
    id: 'dog-sen-13',
    title: 'Pavo con Calabaza y Verduras para Perros Senior',
    frenchTitle: 'Dinde Fondante au Potiron & Légumes Doux Senior',
    species: 'dog',
    growthStage: 'senior',
    category: 'sensitive_digestion',
    categoryLabel: 'Fibra Digestiva & Probióticos',
    description: 'Cocer pavo 20 min, calabaza 15 min y verduras suaves 10 min. Terminar con aceite de linaza, probióticos y cáscara de huevo.',
    kcalPer100g: 120,
    prepTimeMin: 15,
    cookTimeMin: 20,
    difficulty: 'Fácil',
    suitability: 'Perros mayores con propensión a estreñimiento o colapso digestivo',
    clinicalBenefits: ['Calabaza hidratante con fibra mucilaginosa', 'Pavo ligero de fácil degradación enzimática', 'Probióticos'],
    ingredients: [
      { name: 'Pechuga de pavo troceada', category: 'protein', baseGramsFor10kgPetPerDay: 190, notes: 'Cocer 20 min' },
      { name: 'Calabaza en dados', category: 'vegetable', baseGramsFor10kgPetPerDay: 60, notes: 'Cocer 15 min' },
      { name: 'Verduras suaves (calabacín picado)', category: 'vegetable', baseGramsFor10kgPetPerDay: 45, notes: 'Cocer 10 min' },
      { name: 'Aceite de linaza', category: 'healthy_fat', baseGramsFor10kgPetPerDay: 3, notes: 'En crudo' },
      { name: 'Probióticos caninos', category: 'supplement_calcium', baseGramsFor10kgPetPerDay: 3, notes: 'Al templar' },
      { name: 'Cáscara de huevo molida', category: 'supplement_calcium', baseGramsFor10kgPetPerDay: 4, notes: 'Calcio' }
    ],
    instructions: [
      'Cocer el pavo 20 minutos.',
      'Cocer la calabaza 15 minutos y el calabacín 10 minutos.',
      'Triturar las verduras, desmigar el pavo y añadir el aceite de linaza, probióticos y calcio en templado.'
    ],
    storageInfo: 'Nevera 3 días, congelador 2 meses.',
    macronutrients: { proteinPct: 48, fatPct: 13, fiberCarbPct: 22, moisturePct: 79 }
  },
  {
    id: 'dog-sen-14',
    title: 'Salmón con Arroz Blanco y Verduras para Perros Senior',
    frenchTitle: 'Saumon Rose au Riz Blanc Moelleux Senior',
    species: 'dog',
    growthStage: 'senior',
    category: 'joint_omega3',
    categoryLabel: 'Omega 3 Puro & Digestión Delicada',
    description: 'Hornear salmón 12 min, arroz blanco 18 min y verduras suaves 10 min. Añadir omega 3, cáscara de huevo y servir templado.',
    kcalPer100g: 135,
    prepTimeMin: 15,
    cookTimeMin: 18,
    difficulty: 'Fácil',
    suitability: 'Perros ancianos convalecientes o con estómago que tolera mal granos integrales',
    clinicalBenefits: ['Arroz blanco de asimilación ultra rápida', 'EPA y DHA para amortiguar el envejecimiento celular', 'Calcio'],
    ingredients: [
      { name: 'Lomo de salmón horneado sin espinas', category: 'protein', baseGramsFor10kgPetPerDay: 190, notes: 'Hornear 12 min' },
      { name: 'Arroz blanco cocido', category: 'fiber_carb', baseGramsFor10kgPetPerDay: 65, notes: 'Cocer 18 min' },
      { name: 'Verduras suaves (calabacín y zanahoria)', category: 'vegetable', baseGramsFor10kgPetPerDay: 45, notes: 'Cocer 10 min' },
      { name: 'Aceite de salmón', category: 'healthy_fat', baseGramsFor10kgPetPerDay: 3, notes: 'Omega 3' },
      { name: 'Cáscara de huevo en polvo', category: 'supplement_calcium', baseGramsFor10kgPetPerDay: 4, notes: 'Calcio' }
    ],
    instructions: [
      'Hornear el salmón 12 minutos y asegurar ausencia total de espinas.',
      'Cocer el arroz blanco 18 minutos y las verduras suaves 10 minutos.',
      'Mezclar todo con el aceite de salmón y la cáscara de huevo al servir templado.'
    ],
    storageInfo: 'Nevera 48h, congelador 2 meses.',
    macronutrients: { proteinPct: 45, fatPct: 18, fiberCarbPct: 24, moisturePct: 77 }
  },
  {
    id: 'dog-sen-15',
    title: 'Pollo con Calabaza y Probióticos para Perros Senior',
    frenchTitle: 'Poulet Tendre au Potiron & Probiotiques Senior',
    species: 'dog',
    growthStage: 'senior',
    category: 'sensitive_digestion',
    categoryLabel: 'Equilibrio de Flora Intestinal Senior',
    description: 'Cocer pollo 20 min, calabaza 15 min y mezclar cuando esté templado. Añadir probióticos, aceite de salmón y cáscara de huevo.',
    kcalPer100g: 125,
    prepTimeMin: 15,
    cookTimeMin: 20,
    difficulty: 'Fácil',
    suitability: 'Perros senior que han recibido antibióticos o sufren disbiosis intestinal',
    clinicalBenefits: ['Repoblación de cepas bacterianas benéficas', 'Carne blanca no irritante', 'Omega 3 antiinflamatorio'],
    ingredients: [
      { name: 'Pechuga de pollo cocida', category: 'protein', baseGramsFor10kgPetPerDay: 190, notes: 'Cocer 20 min' },
      { name: 'Calabaza cocida', category: 'vegetable', baseGramsFor10kgPetPerDay: 80, notes: 'Cocer 15 min' },
      { name: 'Probióticos caninos', category: 'supplement_calcium', baseGramsFor10kgPetPerDay: 4, notes: 'Al templar' },
      { name: 'Aceite de salmón', category: 'healthy_fat', baseGramsFor10kgPetPerDay: 4, notes: 'Omega 3' },
      { name: 'Cáscara de huevo molida', category: 'supplement_calcium', baseGramsFor10kgPetPerDay: 4, notes: 'Calcio' }
    ],
    instructions: [
      'Cocer el pollo 20 minutos y deshebrar con tenedor.',
      'Cocer la calabaza 15 minutos y aplastar en puré fino.',
      'Mezclar todo en templado y añadir probióticos, aceite de salmón y cáscara de huevo.'
    ],
    storageInfo: 'Nevera 3 días, congelador 2 meses.',
    macronutrients: { proteinPct: 47, fatPct: 15, fiberCarbPct: 21, moisturePct: 78 }
  },
  {
    id: 'dog-sen-16',
    title: 'Merluza con Calabaza y Verduras para Perros Senior',
    frenchTitle: 'Colin Vapeur aux Légumes du Marché Senior',
    species: 'dog',
    growthStage: 'senior',
    category: 'sensitive_digestion',
    categoryLabel: 'Receta Ligera & Digestión Amable',
    description: 'Merluza al vapor 10 min, calabaza 15 min y verduras suaves 10 min. Receta ligera, digestiva y equilibrada.',
    kcalPer100g: 105,
    prepTimeMin: 15,
    cookTimeMin: 15,
    difficulty: 'Fácil',
    suitability: 'Perros mayores en reposo o con tendencia al letargo gástrico',
    clinicalBenefits: ['Mínimo impacto digestivo que promueve el descanso', 'Verduras ricas en agua y potasio', 'Calcio'],
    ingredients: [
      { name: 'Merluza limpia desespinada', category: 'protein', baseGramsFor10kgPetPerDay: 210, notes: 'Al vapor 10 min' },
      { name: 'Calabaza cocida', category: 'vegetable', baseGramsFor10kgPetPerDay: 55, notes: 'Cocer 15 min' },
      { name: 'Verduras suaves (calabacín y judía tierna)', category: 'vegetable', baseGramsFor10kgPetPerDay: 45, notes: 'Cocer 10 min' },
      { name: 'Aceite de linaza', category: 'healthy_fat', baseGramsFor10kgPetPerDay: 3, notes: 'En crudo' },
      { name: 'Cáscara de huevo en polvo', category: 'supplement_calcium', baseGramsFor10kgPetPerDay: 4, notes: 'Calcio' }
    ],
    instructions: [
      'Cocinar la merluza al vapor 10 minutos y verificar que no haya espinas.',
      'Cocer la calabaza 15 minutos y las verduras suaves 10 minutos.',
      'Unir todo con el aceite de linaza y la cáscara de huevo.'
    ],
    storageInfo: 'Nevera 48 horas.',
    macronutrients: { proteinPct: 46, fatPct: 11, fiberCarbPct: 21, moisturePct: 82 }
  },
  {
    id: 'dog-sen-17',
    title: 'Ternera Molida con Patata y Zanahoria para Perros Senior',
    frenchTitle: 'Haché de Bœuf Moelleux aux Pommes de Terre Senior',
    species: 'dog',
    growthStage: 'senior',
    category: 'vitality_gourmet',
    categoryLabel: 'Energía Suave & Buena Palatabilidad',
    description: 'Ternera molida 20 min, patata 20 min y zanahoria 15 min. Aporta energía suave y excelente palatabilidad sin esfuerzo mandibular.',
    kcalPer100g: 135,
    prepTimeMin: 10,
    cookTimeMin: 20,
    difficulty: 'Fácil',
    suitability: 'Perros ancianos con problemas periodontales o pérdida de piezas dentales',
    clinicalBenefits: ['Carne picada que no requiere ser triturada con molares', 'Aporte de carnitina para vitalidad', 'Calcio'],
    ingredients: [
      { name: 'Carne picada de ternera magra', category: 'protein', baseGramsFor10kgPetPerDay: 180, notes: 'Cocinar 20 min' },
      { name: 'Patata cocida en puré', category: 'fiber_carb', baseGramsFor10kgPetPerDay: 65, notes: 'Cocer 20 min' },
      { name: 'Zanahoria cocida machacada', category: 'vegetable', baseGramsFor10kgPetPerDay: 45, notes: 'Cocer 15 min' },
      { name: 'Aceite de salmón', category: 'healthy_fat', baseGramsFor10kgPetPerDay: 4, notes: 'Omega 3' },
      { name: 'Cáscara de huevo en polvo', category: 'supplement_calcium', baseGramsFor10kgPetPerDay: 4, notes: 'Calcio' }
    ],
    instructions: [
      'Cocinar la ternera molida 20 minutos a fuego suave.',
      'Cocer la patata 20 minutos y la zanahoria 15 minutos, aplastando como puré.',
      'Integrar y agregar aceite de salmón y cáscara de huevo molida.'
    ],
    storageInfo: 'Nevera 3 días, congelador 2 meses.',
    macronutrients: { proteinPct: 48, fatPct: 17, fiberCarbPct: 22, moisturePct: 77 }
  },
  {
    id: 'dog-sen-18',
    title: 'Bacalao con Arroz Germinado y Espinaca para Perros Senior',
    frenchTitle: 'Cabillaud au Riz Germé & Feuilles Tendres Senior',
    species: 'dog',
    growthStage: 'senior',
    category: 'sensitive_digestion',
    categoryLabel: 'Alta Digestibilidad & Perfil Amable',
    description: 'Bacalao al vapor 10 min, arroz germinado 20 min y espinaca 5 min. Alta digestibilidad y perfil suave para el organismo sénior.',
    kcalPer100g: 115,
    prepTimeMin: 15,
    cookTimeMin: 20,
    difficulty: 'Fácil',
    suitability: 'Perros mayores con sensibilidad intestinal o alergias cutáneas',
    clinicalBenefits: ['Enzimas germinadas que facilitan la absorción de nutrientes', 'Pescado magro sin grasas pesadas', 'Calcio'],
    ingredients: [
      { name: 'Bacalao fresco desespinado', category: 'protein', baseGramsFor10kgPetPerDay: 210, notes: 'Al vapor 10 min' },
      { name: 'Arroz germinado cocido', category: 'fiber_carb', baseGramsFor10kgPetPerDay: 60, notes: 'Cocer 20 min' },
      { name: 'Espinacas tiernas', category: 'vegetable', baseGramsFor10kgPetPerDay: 35, notes: 'Escaldar 5 min' },
      { name: 'Aceite de linaza', category: 'healthy_fat', baseGramsFor10kgPetPerDay: 3, notes: 'En crudo' },
      { name: 'Cáscara de huevo molida', category: 'supplement_calcium', baseGramsFor10kgPetPerDay: 4, notes: 'Calcio' }
    ],
    instructions: [
      'Cocer el arroz germinado 20 minutos.',
      'Cocinar el bacalao al vapor 10 minutos y escaldar la espinaca 5 minutos.',
      'Desmigar el bacalao comprobando espinas y mezclar con aceite de linaza y calcio.'
    ],
    storageInfo: 'Nevera 48 horas.',
    macronutrients: { proteinPct: 46, fatPct: 12, fiberCarbPct: 23, moisturePct: 80 }
  },
  {
    id: 'dog-sen-19',
    title: 'Pato con Batata Morada y Manzana para Perros Senior',
    frenchTitle: 'Canard Confit à la Patate Violette Senior',
    species: 'dog',
    growthStage: 'senior',
    category: 'vitality_gourmet',
    categoryLabel: 'Sabor Intenso & Antioxidantes',
    description: 'Hornear pato 40 min, batata morada 25 min y manzana cocida 8 min. Rico en sabor y antioxidantes que frenan el envejecimiento.',
    kcalPer100g: 140,
    prepTimeMin: 15,
    cookTimeMin: 40,
    difficulty: 'Fácil',
    suitability: 'Perros mayores inapetentes que necesitan estimulación sensorial y antioxidante',
    clinicalBenefits: ['Antocianinas de la batata morada que protegen la microcirculación cerebral', 'Pato aromático', 'Calcio'],
    ingredients: [
      { name: 'Carne magra de pato desgrasada', category: 'protein', baseGramsFor10kgPetPerDay: 180, notes: 'Hornear 40 min' },
      { name: 'Batata morada cocida pelada', category: 'fiber_carb', baseGramsFor10kgPetPerDay: 60, notes: 'Cocer 25 min' },
      { name: 'Manzana pelada cocida en compota', category: 'vegetable', baseGramsFor10kgPetPerDay: 40, notes: 'Cocer 8 min' },
      { name: 'Aceite de salmón', category: 'healthy_fat', baseGramsFor10kgPetPerDay: 4, notes: 'Omega 3' },
      { name: 'Cáscara de huevo en polvo', category: 'supplement_calcium', baseGramsFor10kgPetPerDay: 4, notes: 'Calcio' }
    ],
    instructions: [
      'Hornear el pato 40 minutos desgrasando bien el fondo.',
      'Cocer la batata morada 25 minutos y la manzana 8 minutos hasta consistencia suave.',
      'Picar las carnes, integrar con la compota y el puré, y agregar aceite de salmón y cáscara de huevo.'
    ],
    storageInfo: 'Nevera 3 días, congelador 2 meses.',
    macronutrients: { proteinPct: 47, fatPct: 18, fiberCarbPct: 23, moisturePct: 76 }
  },
  {
    id: 'dog-sen-20',
    title: 'Conejo con Lenteja Roja y Verduras para Perros Senior',
    frenchTitle: 'Lapin aux Lentilles Corail & Légumes Doux Senior',
    species: 'dog',
    growthStage: 'senior',
    category: 'sensitive_digestion',
    categoryLabel: 'Proteína Magra & Fácil Asimilación',
    description: 'Cocer conejo 35 min, lenteja roja 15 min y verduras suaves 10 min. Proteína magra y fácil de digerir para estómagos maduros.',
    kcalPer100g: 125,
    prepTimeMin: 15,
    cookTimeMin: 35,
    difficulty: 'Fácil',
    suitability: 'Perros ancianos propensos a pancreatitis o digestiones pesadas',
    clinicalBenefits: ['Bajísimo tenor lipídico', 'Lenteja roja suave como vehículo proteico vegetal complementario', 'Calcio'],
    ingredients: [
      { name: 'Carne de conejo deshuesada', category: 'protein', baseGramsFor10kgPetPerDay: 190, notes: 'Cocer 35 min' },
      { name: 'Lenteja roja cocida cremosa', category: 'fiber_carb', baseGramsFor10kgPetPerDay: 50, notes: 'Cocer 15 min' },
      { name: 'Verduras suaves (calabacín y zanahoria)', category: 'vegetable', baseGramsFor10kgPetPerDay: 45, notes: 'Cocer 10 min' },
      { name: 'Aceite de salmón', category: 'healthy_fat', baseGramsFor10kgPetPerDay: 3, notes: 'Omega 3' },
      { name: 'Cáscara de huevo molida', category: 'supplement_calcium', baseGramsFor10kgPetPerDay: 4, notes: 'Calcio' }
    ],
    instructions: [
      'Guisar el conejo 35 minutos y desmigar meticulosamente descartando huesos.',
      'Cocer la lenteja roja 15 minutos y las verduras suaves 10 minutos.',
      'Integrar todo con el aceite de salmón y la cáscara de huevo molida.'
    ],
    storageInfo: 'Nevera 3 días, congelador 2 meses.',
    macronutrients: { proteinPct: 48, fatPct: 13, fiberCarbPct: 23, moisturePct: 78 }
  },
  {
    id: 'dog-sen-21',
    title: 'Codorniz con Quinoa y Zanahoria para Perros Senior ⭐',
    frenchTitle: 'Caille Rôtie au Quinoa & Purée de Carottes Senior',
    species: 'dog',
    growthStage: 'senior',
    category: 'vitality_gourmet',
    categoryLabel: 'Receta Premium Textura Delicada',
    description: 'Premium. Hornear codorniz 30 min, quinoa 15 min y zanahoria 15 min. Muy nutritiva y de textura delicada.',
    kcalPer100g: 135,
    prepTimeMin: 15,
    cookTimeMin: 30,
    difficulty: 'Media',
    suitability: 'Perros ancianos que requieren bocados tiernos y densidad nutritiva en poco volumen',
    clinicalBenefits: ['Proteína suave de caza que estimula el consumo', 'Quinoa con bajo residuo glucémico', 'Calcio'],
    ingredients: [
      { name: 'Carne de codorniz deshuesada con cuidado', category: 'protein', baseGramsFor10kgPetPerDay: 180, notes: 'Hornear 30 min' },
      { name: 'Quinoa cocida', category: 'fiber_carb', baseGramsFor10kgPetPerDay: 55, notes: 'Cocer 15 min' },
      { name: 'Zanahoria muy cocida', category: 'vegetable', baseGramsFor10kgPetPerDay: 45, notes: 'Cocer 15 min' },
      { name: 'Aceite de salmón', category: 'healthy_fat', baseGramsFor10kgPetPerDay: 3, notes: 'Omega 3' },
      { name: 'Cáscara de huevo molida', category: 'supplement_calcium', baseGramsFor10kgPetPerDay: 4, notes: 'Calcio' }
    ],
    instructions: [
      'Hornear la codorniz 30 minutos y desmigar finamente eliminando todos los huesos.',
      'Cocer la quinoa 15 minutos y la zanahoria 15 minutos.',
      'Mezclar todo agregando aceite de salmón y cáscara de huevo en templado.'
    ],
    storageInfo: 'Nevera 3 días, congelador 2 meses.',
    macronutrients: { proteinPct: 49, fatPct: 16, fiberCarbPct: 22, moisturePct: 77 }
  },
  {
    id: 'dog-sen-22',
    title: 'Faisán con Boniato Morado y Quinoa para Perros Senior ⭐',
    frenchTitle: 'Faisan Sauvage au Boniato Violet & Quinoa Senior',
    species: 'dog',
    growthStage: 'senior',
    category: 'vitality_gourmet',
    categoryLabel: 'Receta Premium Antioxidante & Regenerativa',
    description: 'Premium. Hornear faisán 40 min, boniato morado 25 min y quinoa 15 min. Receta antioxidante y regenerativa para la etapa sénior.',
    kcalPer100g: 135,
    prepTimeMin: 15,
    cookTimeMin: 40,
    difficulty: 'Media',
    suitability: 'Perros mayores en protocolo de longevidad activa y rejuvenecimiento celular',
    clinicalBenefits: ['Faisán silvestre de altísima biodisponibilidad', 'Antocianinas potentes de batata morada', 'Quinoa sin alérgenos'],
    ingredients: [
      { name: 'Carne de faisán deshuesada', category: 'protein', baseGramsFor10kgPetPerDay: 180, notes: 'Hornear 40 min' },
      { name: 'Boniato morado cocido pelado', category: 'fiber_carb', baseGramsFor10kgPetPerDay: 60, notes: 'Cocer 25 min' },
      { name: 'Quinoa cocida', category: 'fiber_carb', baseGramsFor10kgPetPerDay: 45, notes: 'Cocer 15 min' },
      { name: 'Aceite de linaza', category: 'healthy_fat', baseGramsFor10kgPetPerDay: 4, notes: 'En crudo' },
      { name: 'Cáscara de huevo en polvo', category: 'supplement_calcium', baseGramsFor10kgPetPerDay: 4, notes: 'Calcio' }
    ],
    instructions: [
      'Hornear el faisán 40 minutos revisando minuciosamente que no queden huesos.',
      'Cocer el boniato morado 25 minutos y la quinoa 15 minutos.',
      'Desmenuzar la carne, unir a la batata y quinoa, y aderezar con aceite de linaza y calcio.'
    ],
    storageInfo: 'Nevera 3 días, congelador 2 meses.',
    macronutrients: { proteinPct: 48, fatPct: 15, fiberCarbPct: 23, moisturePct: 77 }
  },
  {
    id: 'dog-sen-23',
    title: 'Caballa con Arroz Integral y Calabacín para Perros Senior ⭐',
    frenchTitle: 'Maquereau Rôti au Four Riz Complet Senior',
    species: 'dog',
    growthStage: 'senior',
    category: 'joint_omega3',
    categoryLabel: 'Receta Premium Omega 3 & Digestión Amable',
    description: 'Premium. Caballa al horno 15 min, arroz integral 25 min y calabacín 10 min. Aporta omega 3 y digestión amable.',
    kcalPer100g: 140,
    prepTimeMin: 15,
    cookTimeMin: 25,
    difficulty: 'Fácil',
    suitability: 'Perros mayores con dolor lumbar o articular moderado',
    clinicalBenefits: ['Pescado azul pequeño con máxima concentración de EPA', 'Calabacín hidratante y diurético suave', 'Calcio'],
    ingredients: [
      { name: 'Filetes de caballa desespinados', category: 'protein', baseGramsFor10kgPetPerDay: 180, notes: 'Hornear 15 min' },
      { name: 'Arroz integral muy cocido', category: 'fiber_carb', baseGramsFor10kgPetPerDay: 55, notes: 'Cocer 25 min' },
      { name: 'Calabacín cocido', category: 'vegetable', baseGramsFor10kgPetPerDay: 45, notes: 'Cocer 10 min' },
      { name: 'Aceite de oliva virgen extra', category: 'healthy_fat', baseGramsFor10kgPetPerDay: 3, notes: 'En crudo' },
      { name: 'Cáscara de huevo molida', category: 'supplement_calcium', baseGramsFor10kgPetPerDay: 4, notes: 'Calcio' }
    ],
    instructions: [
      'Hornear la caballa 15 minutos a 170°C y desmigar con tenedor revisando espinas.',
      'Cocer el arroz integral 25 minutos y el calabacín 10 minutos.',
      'Integrar todo con el aceite y la cáscara de huevo molida.'
    ],
    storageInfo: 'Nevera 48 horas.',
    macronutrients: { proteinPct: 46, fatPct: 19, fiberCarbPct: 22, moisturePct: 76 }
  },
  {
    id: 'dog-sen-24',
    title: 'Trucha con Quinoa Roja y Verduras para Perros Senior ⭐',
    frenchTitle: 'Truite Dorée au Quinoa Rouge & Légumes Senior',
    species: 'dog',
    growthStage: 'senior',
    category: 'joint_omega3',
    categoryLabel: 'Receta Premium Ligera, Completa y Sabrosa',
    description: 'Premium. Trucha al vapor 12 min, quinoa roja 15 min y verduras suaves 10 min. Ligera, completa y sabrosa.',
    kcalPer100g: 130,
    prepTimeMin: 15,
    cookTimeMin: 15,
    difficulty: 'Fácil',
    suitability: 'Perros ancianos con tendencia a la pesadez postprandial',
    clinicalBenefits: ['Digestión no inflamatoria', 'Antioxidantes de quinoa roja que protegen células renales', 'Calcio'],
    ingredients: [
      { name: 'Trucha fresca desespinada', category: 'protein', baseGramsFor10kgPetPerDay: 190, notes: 'Al vapor 12 min' },
      { name: 'Quinoa roja cocida', category: 'fiber_carb', baseGramsFor10kgPetPerDay: 55, notes: 'Cocer 15 min' },
      { name: 'Verduras suaves (calabaza y calabacín)', category: 'vegetable', baseGramsFor10kgPetPerDay: 45, notes: 'Cocer 10 min' },
      { name: 'Aceite de salmón', category: 'healthy_fat', baseGramsFor10kgPetPerDay: 3, notes: 'Omega 3' },
      { name: 'Cáscara de huevo en polvo', category: 'supplement_calcium', baseGramsFor10kgPetPerDay: 4, notes: 'Calcio' }
    ],
    instructions: [
      'Cocinar la trucha al vapor 12 minutos desmigando sin espinas.',
      'Cocer la quinoa roja 15 minutos y las verduras suaves 10 minutos.',
      'Mezclar todo e incorporar el aceite de salmón y la cáscara de huevo en templado.'
    ],
    storageInfo: 'Nevera 48 horas.',
    macronutrients: { proteinPct: 45, fatPct: 17, fiberCarbPct: 23, moisturePct: 78 }
  },
  {
    id: 'dog-sen-25',
    title: 'Pato con Batata Morada y Manzana para Perros Senior ⭐',
    frenchTitle: 'Magret au Four Batate Morada Senior Gourmet',
    species: 'dog',
    growthStage: 'senior',
    category: 'vitality_gourmet',
    categoryLabel: 'Receta Premium Enérgica y Muy Apetecible',
    description: 'Premium. Hornear pato 40 min, batata morada 25 min y manzana cocida 8 min. Plato energético y muy apetecible.',
    kcalPer100g: 140,
    prepTimeMin: 15,
    cookTimeMin: 40,
    difficulty: 'Fácil',
    suitability: 'Perros senior que necesitan recuperar peso tras una convalecencia',
    clinicalBenefits: ['Grasa saludable que aporta calorías limpias sin sobrecargar volumen', 'Fibra saciante y suave', 'Calcio'],
    ingredients: [
      { name: 'Carne magra de pato', category: 'protein', baseGramsFor10kgPetPerDay: 180, notes: 'Hornear 40 min' },
      { name: 'Batata morada cocida', category: 'fiber_carb', baseGramsFor10kgPetPerDay: 60, notes: 'Cocer 25 min' },
      { name: 'Manzana pelada cocida en compota', category: 'vegetable', baseGramsFor10kgPetPerDay: 40, notes: 'Cocer 8 min' },
      { name: 'Aceite de salmón', category: 'healthy_fat', baseGramsFor10kgPetPerDay: 4, notes: 'Omega 3' },
      { name: 'Cáscara de huevo molida', category: 'supplement_calcium', baseGramsFor10kgPetPerDay: 4, notes: 'Calcio' }
    ],
    instructions: [
      'Hornear el pato 40 minutos escurriendo el jugo graso.',
      'Cocer la batata morada 25 minutos y la manzana 8 minutos hasta consistencia compota.',
      'Unir todo machacando ligeramente y agregar aceite de salmón y calcio al templar.'
    ],
    storageInfo: 'Nevera 3 días, congelador 2 meses.',
    macronutrients: { proteinPct: 47, fatPct: 18, fiberCarbPct: 23, moisturePct: 76 }
  },
  {
    id: 'dog-sen-26',
    title: 'Conejo con Lenteja Roja y Verduras para Perros Senior ⭐',
    frenchTitle: 'Lapin Mijoté Doux aux Lentilles Corail Senior',
    species: 'dog',
    growthStage: 'senior',
    category: 'sensitive_digestion',
    categoryLabel: 'Receta Premium para Digestiones Sensibles',
    description: 'Premium. Cocer conejo 35 min, lenteja roja 15 min y verduras suaves 10 min. Ideal para digestiones sensibles en edad avanzada.',
    kcalPer100g: 125,
    prepTimeMin: 15,
    cookTimeMin: 35,
    difficulty: 'Fácil',
    suitability: 'Perros mayores con episodios recurrentes de heces blandas o náuseas',
    clinicalBenefits: ['Lenteja roja sin oligosacáridos pesados', 'Conejo hipoalergénico de mínima grasa', 'Calcio'],
    ingredients: [
      { name: 'Carne de conejo deshuesada', category: 'protein', baseGramsFor10kgPetPerDay: 190, notes: 'Cocer 35 min' },
      { name: 'Lenteja roja cocida', category: 'fiber_carb', baseGramsFor10kgPetPerDay: 50, notes: 'Cocer 15 min' },
      { name: 'Verduras suaves (calabacín y zanahoria)', category: 'vegetable', baseGramsFor10kgPetPerDay: 45, notes: 'Cocer 10 min' },
      { name: 'Aceite de linaza', category: 'healthy_fat', baseGramsFor10kgPetPerDay: 3, notes: 'En crudo' },
      { name: 'Cáscara de huevo molida', category: 'supplement_calcium', baseGramsFor10kgPetPerDay: 4, notes: 'Calcio' }
    ],
    instructions: [
      'Cocer el conejo 35 minutos y retirar meticulosamente cualquier hueso.',
      'Cocer la lenteja roja 15 minutos y las verduras suaves 10 minutos.',
      'Mezclar todo e incorporar el aceite de linaza y la cáscara de huevo en polvo.'
    ],
    storageInfo: 'Nevera 3 días, congelador 2 meses.',
    macronutrients: { proteinPct: 48, fatPct: 13, fiberCarbPct: 23, moisturePct: 78 }
  },
  {
    id: 'dog-sen-27',
    title: 'Salmón con Calabaza y Probióticos para Perros Senior ⭐',
    frenchTitle: 'Saumon au Potiron & Probiotiques Flora Senior',
    species: 'dog',
    growthStage: 'senior',
    category: 'joint_omega3',
    categoryLabel: 'Receta Premium Flora Intestinal & Articulaciones',
    description: 'Premium. Hornear salmón 12 min y calabaza 15 min. Añadir probióticos para apoyar la flora intestinal y longevidad celular.',
    kcalPer100g: 130,
    prepTimeMin: 15,
    cookTimeMin: 15,
    difficulty: 'Fácil',
    suitability: 'Perros de edad avanzada que requieren soporte inmunológico mucosal',
    clinicalBenefits: ['Probióticos que fortalecen la barrera hematoencefálica e intestinal', 'Omega-3 marino antiinflamatorio', 'Calcio'],
    ingredients: [
      { name: 'Lomo de salmón sin espinas', category: 'protein', baseGramsFor10kgPetPerDay: 190, notes: 'Hornear 12 min' },
      { name: 'Calabaza cocida', category: 'vegetable', baseGramsFor10kgPetPerDay: 80, notes: 'Cocer 15 min' },
      { name: 'Probióticos caninos', category: 'supplement_calcium', baseGramsFor10kgPetPerDay: 4, notes: 'Al templar' },
      { name: 'Aceite de oliva virgen extra', category: 'healthy_fat', baseGramsFor10kgPetPerDay: 3, notes: 'En crudo' },
      { name: 'Cáscara de huevo en polvo', category: 'supplement_calcium', baseGramsFor10kgPetPerDay: 4, notes: 'Calcio' }
    ],
    instructions: [
      'Hornear el salmón 12 minutos y desmigar verificando que no queden espinas.',
      'Cocer la calabaza 15 minutos y aplastar en puré homogéneo.',
      'Unir ambos y espolvorear los probióticos, aceite y calcio al templar.'
    ],
    storageInfo: 'Nevera 48h, congelador 2 meses.',
    macronutrients: { proteinPct: 45, fatPct: 18, fiberCarbPct: 22, moisturePct: 78 }
  },
  {
    id: 'dog-sen-28',
    title: 'Cordero con Boniato y Glucosamina para Perros Senior ⭐',
    frenchTitle: 'Agneau au Boniato & Glucosamine Confort Senior',
    species: 'dog',
    growthStage: 'senior',
    category: 'joint_omega3',
    categoryLabel: 'Receta Premium Cuidado Articular Senior',
    description: 'Premium. Estofar cordero 35 min y boniato 25 min. Incorporar glucosamina para el cuidado articular y la movilidad en la vejez.',
    kcalPer100g: 140,
    prepTimeMin: 15,
    cookTimeMin: 35,
    difficulty: 'Fácil',
    suitability: 'Perros ancianos con displasia o desgaste de columna y caderas',
    clinicalBenefits: ['Soporte directo para la lubricación sinovial', 'Cordero nutritivo de digestión suave', 'Calcio'],
    ingredients: [
      { name: 'Cordero magro desgrasado', category: 'protein', baseGramsFor10kgPetPerDay: 180, notes: 'Estofar 35 min' },
      { name: 'Boniato cocido pelado', category: 'fiber_carb', baseGramsFor10kgPetPerDay: 65, notes: 'Cocer 25 min' },
      { name: 'Glucosamina canina', category: 'supplement_calcium', baseGramsFor10kgPetPerDay: 2, notes: 'Protector articular' },
      { name: 'Aceite de salmón', category: 'healthy_fat', baseGramsFor10kgPetPerDay: 4, notes: 'Omega 3' },
      { name: 'Cáscara de huevo molida', category: 'supplement_calcium', baseGramsFor10kgPetPerDay: 4, notes: 'Calcio' }
    ],
    instructions: [
      'Estofar el cordero 35 minutos hasta tiernísimo.',
      'Cocer el boniato 25 minutos y machacar con tenedor.',
      'Mezclar todo con la glucosamina, el aceite de salmón y la cáscara de huevo molida.'
    ],
    storageInfo: 'Nevera 3 días, congelador 2 meses.',
    macronutrients: { proteinPct: 47, fatPct: 18, fiberCarbPct: 22, moisturePct: 76 }
  },
  {
    id: 'dog-sen-29',
    title: 'Bacalao con Arroz Germinado y Espinaca para Perros Senior ⭐',
    frenchTitle: 'Cabillaud Vapeur au Riz Germé Senior Douceur',
    species: 'dog',
    growthStage: 'senior',
    category: 'sensitive_digestion',
    categoryLabel: 'Receta Premium Suave, Completa y Fácil de Procesar',
    description: 'Premium. Bacalao al vapor 10 min, arroz germinado 20 min y espinaca 5 min. Suave, completa y fácil de procesar.',
    kcalPer100g: 115,
    prepTimeMin: 15,
    cookTimeMin: 20,
    difficulty: 'Fácil',
    suitability: 'Perros mayores en días de digestión frágil',
    clinicalBenefits: ['Mínimo residuo metabólico nitrogenado', 'Minerales biodisponibles', 'Calcio'],
    ingredients: [
      { name: 'Bacalao fresco al vapor desespinado', category: 'protein', baseGramsFor10kgPetPerDay: 210, notes: 'Al vapor 10 min' },
      { name: 'Arroz germinado cocido', category: 'fiber_carb', baseGramsFor10kgPetPerDay: 60, notes: 'Cocer 20 min' },
      { name: 'Espinacas tiernas', category: 'vegetable', baseGramsFor10kgPetPerDay: 35, notes: 'Escaldar 5 min' },
      { name: 'Aceite de linaza', category: 'healthy_fat', baseGramsFor10kgPetPerDay: 3, notes: 'En crudo' },
      { name: 'Cáscara de huevo molida', category: 'supplement_calcium', baseGramsFor10kgPetPerDay: 4, notes: 'Calcio' }
    ],
    instructions: [
      'Cocer el arroz germinado 20 minutos.',
      'Cocinar el bacalao al vapor 10 minutos y escaldar las espinacas 5 minutos.',
      'Integrar con el aceite de linaza y la cáscara de huevo molida.'
    ],
    storageInfo: 'Nevera 48 horas.',
    macronutrients: { proteinPct: 46, fatPct: 12, fiberCarbPct: 23, moisturePct: 81 }
  },
  {
    id: 'dog-sen-30',
    title: 'Pollo con Hígado y Quinoa para Perros Senior ⭐',
    frenchTitle: 'Poule au Quinoa & Foie Moelleux Senior',
    species: 'dog',
    growthStage: 'senior',
    category: 'vitality_gourmet',
    categoryLabel: 'Receta Premium Palatabilidad & Nutrientes Senior',
    description: 'Premium. Cocer pollo 20 min, hígado 7 min y quinoa 15 min. Alta palatabilidad y buen aporte de nutrientes esenciales para la etapa dorada.',
    kcalPer100g: 135,
    prepTimeMin: 15,
    cookTimeMin: 20,
    difficulty: 'Fácil',
    suitability: 'Perros senior que disfrutan de un plato sabroso y completo',
    clinicalBenefits: ['Zinc, selenio y vitaminas del complejo B de origen natural', 'Quinoa ligera', 'Calcio'],
    ingredients: [
      { name: 'Pechuga de pollo cocida', category: 'protein', baseGramsFor10kgPetPerDay: 180, notes: 'Cocer 20 min' },
      { name: 'Hígado de pollo fresco', category: 'protein', baseGramsFor10kgPetPerDay: 15, notes: 'Cocer 7 min' },
      { name: 'Quinoa cocida', category: 'fiber_carb', baseGramsFor10kgPetPerDay: 55, notes: 'Cocer 15 min' },
      { name: 'Aceite de salmón', category: 'healthy_fat', baseGramsFor10kgPetPerDay: 4, notes: 'Omega 3' },
      { name: 'Cáscara de huevo en polvo', category: 'supplement_calcium', baseGramsFor10kgPetPerDay: 4, notes: 'Calcio' }
    ],
    instructions: [
      'Cocer el pollo 20 minutos añadiendo el hígado en los últimos 7 minutos.',
      'Cocer la quinoa 15 minutos y escurrir.',
      'Picar fino las carnes, unir a la quinoa y añadir el aceite de salmón y la cáscara de huevo en templado.'
    ],
    storageInfo: 'Nevera 3 días, congelador 2 meses.',
    macronutrients: { proteinPct: 51, fatPct: 15, fiberCarbPct: 22, moisturePct: 76 }
  }
];
