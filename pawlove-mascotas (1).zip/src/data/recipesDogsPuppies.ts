import { Recipe } from '../types';

export const DOG_PUPPY_RECIPES: Recipe[] = [
  {
    id: 'dog-pup-01',
    title: 'Pollo con Arroz y Calabaza para Cachorros',
    frenchTitle: 'Poulet Tendre au Riz & Potimarron Chiot',
    species: 'dog',
    growthStage: 'puppy_kitten',
    category: 'sensitive_digestion',
    categoryLabel: 'Crecimiento & Digestión Suave',
    description: 'Receta básica de crecimiento rica en energía y fácil digestión. Hervir pollo 20–25 min, arroz 18–20 min y calabaza 15 min.',
    kcalPer100g: 135,
    prepTimeMin: 15,
    cookTimeMin: 25,
    difficulty: 'Fácil',
    suitability: 'Cachorros en crecimiento activo (2 a 12 meses)',
    clinicalBenefits: [
      'Proteína de fácil digestión para desarrollo muscular sin fatiga gástrica',
      'Fibra suave de calabaza que protege la microbiota del cachorro',
      'Aporte de DHA (aceite de salmón) para desarrollo neurológico y cognitivo'
    ],
    ingredients: [
      { name: 'Pechuga o muslo de pollo deshuesado', category: 'protein', baseGramsFor10kgPetPerDay: 200, notes: 'Hervir 20-25 min' },
      { name: 'Arroz blanco cocido', category: 'fiber_carb', baseGramsFor10kgPetPerDay: 70, notes: 'Hervir 18-20 min' },
      { name: 'Calabaza cocida al vapor', category: 'vegetable', baseGramsFor10kgPetPerDay: 50, notes: 'Cocer 15 min y machacar' },
      { name: 'Aceite de salmón salvaje (Omega 3)', category: 'healthy_fat', baseGramsFor10kgPetPerDay: 4, notes: 'Añadir al final templado' },
      { name: 'Cáscara de huevo molida (Calcio)', category: 'supplement_calcium', baseGramsFor10kgPetPerDay: 5, notes: 'Calcio bioasimilable para huesos' }
    ],
    instructions: [
      'Hervir la pechuga de pollo durante 20-25 minutos en agua sin sal.',
      'Cocer el arroz blanco durante 18-20 minutos hasta que quede muy blando.',
      'Cocer la calabaza durante 15 minutos al vapor o hervida y aplastar con tenedor.',
      'Mezclar todos los ingredientes y añadir el aceite de salmón y la cáscara de huevo al final cuando esté templado.'
    ],
    chefTips: 'Para cachorros muy pequeños, triturar ligeramente hasta obtener textura papilla.',
    storageInfo: 'Conservar en nevera hasta 3 días o congelar en porciones.',
    macronutrients: { proteinPct: 48, fatPct: 18, fiberCarbPct: 24, moisturePct: 78 }
  },
  {
    id: 'dog-pup-02',
    title: 'Pavo con Patata y Zanahoria para Cachorros',
    frenchTitle: 'Dinde Douce aux Pommes de Terre & Carottes',
    species: 'dog',
    growthStage: 'puppy_kitten',
    category: 'vitality_gourmet',
    categoryLabel: 'Vitalidad & Crecimiento',
    description: 'Hervir pavo 25 min, patata 20 min y zanahoria 15 min. Incorporar probióticos al final cuando la mezcla esté templada.',
    kcalPer100g: 130,
    prepTimeMin: 15,
    cookTimeMin: 25,
    difficulty: 'Fácil',
    suitability: 'Cachorros en fase de desarrollo óseo y muscular',
    clinicalBenefits: ['Pavo hipoalergénico de alta asimilación', 'Betacarotenos para desarrollo visual', 'Probióticos para maduración inmune'],
    ingredients: [
      { name: 'Pechuga o solomillo de pavo', category: 'protein', baseGramsFor10kgPetPerDay: 200, notes: 'Hervir 25 min' },
      { name: 'Patata cocida sin piel', category: 'fiber_carb', baseGramsFor10kgPetPerDay: 65, notes: 'Hervir 20 min' },
      { name: 'Zanahoria rallada o en dados cocida', category: 'vegetable', baseGramsFor10kgPetPerDay: 45, notes: 'Hervir 15 min' },
      { name: 'Probióticos caninos o kéfir de cabra', category: 'supplement_calcium', baseGramsFor10kgPetPerDay: 5, notes: 'Añadir en frío' },
      { name: 'Cáscara de huevo en polvo', category: 'supplement_calcium', baseGramsFor10kgPetPerDay: 5, notes: 'Calcio esencial' }
    ],
    instructions: [
      'Hervir el pavo durante 25 minutos.',
      'Cocer la patata pelada 20 minutos y la zanahoria 15 minutos.',
      'Trocear fino y dejar enfriar hasta que esté templado.',
      'Incorporar los probióticos y la cáscara de huevo molida antes de servir.'
    ],
    storageInfo: 'Nevera 3 días, congelador 2 meses.',
    macronutrients: { proteinPct: 46, fatPct: 16, fiberCarbPct: 26, moisturePct: 77 }
  },
  {
    id: 'dog-pup-03',
    title: 'Merluza con Patata y Calabacín para Cachorros',
    frenchTitle: 'Colin Doux & Courgettes Chiot',
    species: 'dog',
    growthStage: 'puppy_kitten',
    category: 'sensitive_digestion',
    categoryLabel: 'Digestión Ligera & Pelaje',
    description: 'Merluza al vapor 10–12 min, patata 20 min y calabacín 10 min. Añadir aceite de linaza y cáscara de huevo al servir.',
    kcalPer100g: 115,
    prepTimeMin: 10,
    cookTimeMin: 20,
    difficulty: 'Fácil',
    suitability: 'Cachorros con estómago sensible o intolerancias cárnicas',
    clinicalBenefits: ['Proteína marina limpia libre de alérgenos comunes', 'Aceite de linaza rico en ALA', 'Calabacín hidratante con electrolitos'],
    ingredients: [
      { name: 'Lomos limpios de merluza sin espinas', category: 'protein', baseGramsFor10kgPetPerDay: 220, notes: 'Cocer al vapor 10-12 min' },
      { name: 'Patata cocida al vapor', category: 'fiber_carb', baseGramsFor10kgPetPerDay: 70, notes: 'Cocer 20 min' },
      { name: 'Calabacín pelado en dados', category: 'vegetable', baseGramsFor10kgPetPerDay: 50, notes: 'Cocer 10 min' },
      { name: 'Aceite de linaza de primera presión', category: 'healthy_fat', baseGramsFor10kgPetPerDay: 4, notes: 'Añadir en crudo' },
      { name: 'Cáscara de huevo en polvo', category: 'supplement_calcium', baseGramsFor10kgPetPerDay: 5, notes: 'Aporte de calcio' }
    ],
    instructions: [
      'Cocinar la merluza al vapor 10-12 minutos comprobando minuciosamente ausencia de espinas.',
      'Hervir la patata 20 minutos y el calabacín 10 minutos.',
      'Mezclar desmenuzando con tenedor y agregar aceite de linaza y cáscara de huevo al servir.'
    ],
    storageInfo: 'Consumir en 48 horas en frío.',
    macronutrients: { proteinPct: 44, fatPct: 14, fiberCarbPct: 25, moisturePct: 80 }
  },
  {
    id: 'dog-pup-04',
    title: 'Ternera con Boniato y Espinaca para Cachorros',
    frenchTitle: 'Veau Fermier à la Patate Douce Chiot',
    species: 'dog',
    growthStage: 'puppy_kitten',
    category: 'vitality_gourmet',
    categoryLabel: 'Hierro & Vitalidad Crecimiento',
    description: 'Cocer la ternera 20–25 min, el boniato 18–20 min y la espinaca 3–5 min. Añadir omega 3 y cáscara de huevo al final.',
    kcalPer100g: 140,
    prepTimeMin: 15,
    cookTimeMin: 25,
    difficulty: 'Fácil',
    suitability: 'Cachorros activos de razas medianas y grandes',
    clinicalBenefits: ['Alto aporte de hierro hemo y zinc para oxigenación tisular', 'Boniato con antioxidantes de bajo índice glucémico', 'Omega 3 antiinflamatorio'],
    ingredients: [
      { name: 'Carne magra de ternera picada o en dados', category: 'protein', baseGramsFor10kgPetPerDay: 190, notes: 'Cocer 20-25 min' },
      { name: 'Boniato cocido', category: 'fiber_carb', baseGramsFor10kgPetPerDay: 60, notes: 'Cocer 18-20 min' },
      { name: 'Hojas de espinaca fresca bien lavada', category: 'vegetable', baseGramsFor10kgPetPerDay: 30, notes: 'Escaldar 3-5 min' },
      { name: 'Aceite de salmón / Omega 3', category: 'healthy_fat', baseGramsFor10kgPetPerDay: 4, notes: 'Añadir al final' },
      { name: 'Cáscara de huevo molida', category: 'supplement_calcium', baseGramsFor10kgPetPerDay: 5, notes: 'Equilibrador Ca:P' }
    ],
    instructions: [
      'Cocer la ternera magra 20-25 minutos.',
      'Hervir el boniato pelado 18-20 minutos hasta que esté blando.',
      'Escaldar las espinacas los últimos 3-5 minutos.',
      'Integrar todo y suplementar con omega 3 y cáscara de huevo.'
    ],
    storageInfo: 'Nevera 3 días, congelador 2 meses.',
    macronutrients: { proteinPct: 50, fatPct: 18, fiberCarbPct: 22, moisturePct: 76 }
  },
  {
    id: 'dog-pup-05',
    title: 'Salmón con Arroz Integral y Brócoli para Cachorros',
    frenchTitle: 'Saumon Sauvage au Riz Brun & Brocoli',
    species: 'dog',
    growthStage: 'puppy_kitten',
    category: 'joint_omega3',
    categoryLabel: 'Desarrollo Cognitivo & Articular',
    description: 'Hornear o cocer el salmón 12–15 min, cocer arroz integral 25–30 min y brócoli 8–10 min. Terminar con aceite de salmón y cáscara de huevo.',
    kcalPer100g: 145,
    prepTimeMin: 15,
    cookTimeMin: 30,
    difficulty: 'Fácil',
    suitability: 'Cachorros en crecimiento para pelaje brillante y articulaciones sanas',
    clinicalBenefits: ['Rico en EPA/DHA de biodisponibilidad máxima', 'Sulforafano del brócoli como protector celular', 'Arroz integral con fibra prebiótica'],
    ingredients: [
      { name: 'Lomo de salmón fresco sin espinas', category: 'protein', baseGramsFor10kgPetPerDay: 190, notes: 'Hornear o cocer 12-15 min' },
      { name: 'Arroz integral muy cocido', category: 'fiber_carb', baseGramsFor10kgPetPerDay: 60, notes: 'Cocer 25-30 min' },
      { name: 'Ramilletes de brócoli al vapor', category: 'vegetable', baseGramsFor10kgPetPerDay: 40, notes: 'Cocer 8-10 min' },
      { name: 'Aceite de salmón', category: 'healthy_fat', baseGramsFor10kgPetPerDay: 3, notes: 'Añadir templado' },
      { name: 'Cáscara de huevo en polvo', category: 'supplement_calcium', baseGramsFor10kgPetPerDay: 5, notes: 'Calcio orgánico' }
    ],
    instructions: [
      'Cocer el salmón al vapor o al horno 12-15 minutos asegurándose de quitar piel y espinas.',
      'Cocer el arroz integral durante 25-30 minutos hasta consistencia blanda.',
      'Cocer el brócoli al vapor 8-10 minutos y picar fino.',
      'Mezclar y añadir el aceite de salmón y la cáscara de huevo.'
    ],
    storageInfo: 'Nevera 48h, congelador 2 meses.',
    macronutrients: { proteinPct: 45, fatPct: 22, fiberCarbPct: 23, moisturePct: 75 }
  },
  {
    id: 'dog-pup-06',
    title: 'Conejo con Avena y Zanahoria para Cachorros',
    frenchTitle: 'Lapin Délicat à l Avoine & Carottes',
    species: 'dog',
    growthStage: 'puppy_kitten',
    category: 'sensitive_digestion',
    categoryLabel: 'Proteína Novedosa & Digestibilidad',
    description: 'Guisar conejo 30 min, cocer avena 10–12 min y zanahoria 15 min. Añadir aceite de linaza y una pizca de cáscara de huevo al final.',
    kcalPer100g: 130,
    prepTimeMin: 15,
    cookTimeMin: 30,
    difficulty: 'Fácil',
    suitability: 'Cachorros con estómagos reactivos o digestión lenta',
    clinicalBenefits: ['Carne blanca hipoalergénica baja en colesterol', 'Betaglucanos de avena que suavizan el tracto entérico', 'Calcio para osificación'],
    ingredients: [
      { name: 'Carne magra de conejo deshuesada', category: 'protein', baseGramsFor10kgPetPerDay: 200, notes: 'Guisar 30 min' },
      { name: 'Copos de avena suave cocida', category: 'fiber_carb', baseGramsFor10kgPetPerDay: 50, notes: 'Cocer 10-12 min' },
      { name: 'Zanahoria troceada', category: 'vegetable', baseGramsFor10kgPetPerDay: 50, notes: 'Cocer 15 min' },
      { name: 'Aceite de linaza virgen', category: 'healthy_fat', baseGramsFor10kgPetPerDay: 4, notes: 'Añadir en crudo' },
      { name: 'Cáscara de huevo en polvo', category: 'supplement_calcium', baseGramsFor10kgPetPerDay: 5, notes: 'Añadir al final' }
    ],
    instructions: [
      'Guisar la carne de conejo en agua limpia 30 minutos retirando cualquier huesecillo.',
      'Cocer los copos de avena con agua caliente 10-12 minutos hasta formar papilla suave.',
      'Cocer la zanahoria 15 minutos y triturar.',
      'Mezclar todo con el aceite de linaza y la cáscara de huevo.'
    ],
    storageInfo: 'Nevera 3 días, congelador 2 meses.',
    macronutrients: { proteinPct: 47, fatPct: 15, fiberCarbPct: 26, moisturePct: 78 }
  },
  {
    id: 'dog-pup-07',
    title: 'Bacalao con Calabaza y Zanahoria para Cachorros',
    frenchTitle: 'Cabillaud Fondant Potiron & Carottes',
    species: 'dog',
    growthStage: 'puppy_kitten',
    category: 'sensitive_digestion',
    categoryLabel: 'Pescado Blanco & Confort Intestinal',
    description: 'Cocer el bacalao 8–10 min, calabaza 15 min y zanahoria 15–18 min. Mezclar con omega 3 y cáscara de huevo cuando esté templado.',
    kcalPer100g: 110,
    prepTimeMin: 10,
    cookTimeMin: 18,
    difficulty: 'Fácil',
    suitability: 'Cachorros en fase de transición de leche a comida sólida',
    clinicalBenefits: ['Pescado blanco magro sin grasa pesada', 'Fibra prebiótica y carotenos digestivos', 'Favorece heces firmes y regulares'],
    ingredients: [
      { name: 'Bacalao desalado fresco sin espinas', category: 'protein', baseGramsFor10kgPetPerDay: 220, notes: 'Cocer 8-10 min' },
      { name: 'Calabaza cocida', category: 'vegetable', baseGramsFor10kgPetPerDay: 60, notes: 'Cocer 15 min' },
      { name: 'Zanahoria cocida', category: 'vegetable', baseGramsFor10kgPetPerDay: 50, notes: 'Cocer 15-18 min' },
      { name: 'Aceite de pescado Omega 3', category: 'healthy_fat', baseGramsFor10kgPetPerDay: 4, notes: 'Añadir templado' },
      { name: 'Cáscara de huevo en polvo', category: 'supplement_calcium', baseGramsFor10kgPetPerDay: 5, notes: 'Calcio' }
    ],
    instructions: [
      'Cocer el bacalao en agua suave 8-10 minutos, desmenuzar revisando espinas.',
      'Cocer la calabaza y zanahoria juntas hasta que queden muy tiernas.',
      'Mezclar todo machacando con tenedor y añadir el omega 3 y calcio al templar.'
    ],
    storageInfo: 'Consumir en 48 horas.',
    macronutrients: { proteinPct: 46, fatPct: 12, fiberCarbPct: 24, moisturePct: 81 }
  },
  {
    id: 'dog-pup-08',
    title: 'Pato con Batata y Manzana para Cachorros',
    frenchTitle: 'Canard Confit à la Patate Douce & Pomme',
    species: 'dog',
    growthStage: 'puppy_kitten',
    category: 'vitality_gourmet',
    categoryLabel: 'Palatabilidad Suprema & Energía',
    description: 'Cocinar el pato 20–25 min, la batata 18–20 min y la manzana 5–7 min sin semillas. Añadir probióticos y cáscara de huevo al final.',
    kcalPer100g: 145,
    prepTimeMin: 15,
    cookTimeMin: 25,
    difficulty: 'Fácil',
    suitability: 'Cachorros inapetentes o de paladar exigente',
    clinicalBenefits: ['Pato rico en aminoácidos esenciales y sabor muy apetecible', 'Pectina de manzana para salud colónica', 'Probióticos que refuerzan defensas'],
    ingredients: [
      { name: 'Carne de pato magra desgrasada', category: 'protein', baseGramsFor10kgPetPerDay: 190, notes: 'Cocinar 20-25 min' },
      { name: 'Batata cocida pelada', category: 'fiber_carb', baseGramsFor10kgPetPerDay: 65, notes: 'Cocer 18-20 min' },
      { name: 'Manzana pelada y descorazonada sin semillas', category: 'vegetable', baseGramsFor10kgPetPerDay: 35, notes: 'Cocer 5-7 min' },
      { name: 'Probióticos en polvo', category: 'supplement_calcium', baseGramsFor10kgPetPerDay: 3, notes: 'Añadir en templado' },
      { name: 'Cáscara de huevo en polvo', category: 'supplement_calcium', baseGramsFor10kgPetPerDay: 5, notes: 'Aporte de calcio' }
    ],
    instructions: [
      'Cocinar la carne de pato 20-25 minutos eliminando grasa excedente.',
      'Cocer la batata 18-20 minutos y la manzana troceada 5-7 minutos.',
      'Integrar todo, dejar templar e incorporar los probióticos y calcio.'
    ],
    storageInfo: 'Nevera 3 días, congelador 2 meses.',
    macronutrients: { proteinPct: 45, fatPct: 20, fiberCarbPct: 25, moisturePct: 76 }
  },
  {
    id: 'dog-pup-09',
    title: 'Cordero con Quinoa y Verduras para Cachorros',
    frenchTitle: 'Agneau de Printemps au Quinoa & Légumes',
    species: 'dog',
    growthStage: 'puppy_kitten',
    category: 'vitality_gourmet',
    categoryLabel: 'Nutrición Completa & Vigor',
    description: 'Guisar cordero 30 min, cocer quinoa 15 min y verduras suaves 10–12 min. Terminar con aceite de salmón y cáscara de huevo.',
    kcalPer100g: 140,
    prepTimeMin: 15,
    cookTimeMin: 30,
    difficulty: 'Fácil',
    suitability: 'Cachorros de razas medianas o activas en crecimiento',
    clinicalBenefits: ['Cordero rico en L-carnitina y zinc bioasimilable', 'Quinoa con todos los aminoácidos esenciales', 'Verduras ricas en magnesio y potasio'],
    ingredients: [
      { name: 'Carne magra de cordero desgrasada', category: 'protein', baseGramsFor10kgPetPerDay: 190, notes: 'Guisar 30 min' },
      { name: 'Quinoa bien lavada y cocida', category: 'fiber_carb', baseGramsFor10kgPetPerDay: 60, notes: 'Cocer 15 min' },
      { name: 'Verduras suaves (calabacín y zanahoria)', category: 'vegetable', baseGramsFor10kgPetPerDay: 45, notes: 'Cocer 10-12 min' },
      { name: 'Aceite de salmón salvaje', category: 'healthy_fat', baseGramsFor10kgPetPerDay: 4, notes: 'Añadir al final' },
      { name: 'Cáscara de huevo molida', category: 'supplement_calcium', baseGramsFor10kgPetPerDay: 5, notes: 'Calcio' }
    ],
    instructions: [
      'Guisar el cordero durante 30 minutos retirando grasa flotante.',
      'Cocer la quinoa lavada 15 minutos en agua abundante y colar.',
      'Cocer las verduras suaves 10-12 minutos.',
      'Mezclar todo agregando aceite de salmón y calcio al servir.'
    ],
    storageInfo: 'Nevera 3 días, congelador 2 meses.',
    macronutrients: { proteinPct: 47, fatPct: 18, fiberCarbPct: 24, moisturePct: 76 }
  },
  {
    id: 'dog-pup-10',
    title: 'Trucha con Arroz Salvaje y Espinaca para Cachorros',
    frenchTitle: 'Truite de Rivière au Riz Sauvage & Épinards',
    species: 'dog',
    growthStage: 'puppy_kitten',
    category: 'joint_omega3',
    categoryLabel: 'Ácidos Grasos & Crecimiento Óptimo',
    description: 'Cocinar la trucha 10–12 min, el arroz salvaje 35–40 min y la espinaca 3–5 min. Añadir aceite de linaza y cáscara de huevo al servir.',
    kcalPer100g: 130,
    prepTimeMin: 15,
    cookTimeMin: 40,
    difficulty: 'Fácil',
    suitability: 'Cachorros con necesidad de soporte en pelaje, ojos y articulaciones',
    clinicalBenefits: ['Omega-3 de río para menor inflamación dérmica', 'Arroz salvaje rico en antioxidantes naturales y minerales', 'Espinaca rica en ácido fólico'],
    ingredients: [
      { name: 'Filetes de trucha limpia sin espinas', category: 'protein', baseGramsFor10kgPetPerDay: 200, notes: 'Cocinar 10-12 min' },
      { name: 'Arroz salvaje muy cocido', category: 'fiber_carb', baseGramsFor10kgPetPerDay: 55, notes: 'Cocer 35-40 min' },
      { name: 'Espinacas tiernas', category: 'vegetable', baseGramsFor10kgPetPerDay: 35, notes: 'Escaldar 3-5 min' },
      { name: 'Aceite de linaza', category: 'healthy_fat', baseGramsFor10kgPetPerDay: 4, notes: 'En crudo' },
      { name: 'Cáscara de huevo molida', category: 'supplement_calcium', baseGramsFor10kgPetPerDay: 5, notes: 'Calcio bioasimilable' }
    ],
    instructions: [
      'Cocer el arroz salvaje 35-40 minutos hasta que reviente el grano.',
      'Cocer la trucha al vapor o plancha 10-12 minutos y revisar espinas.',
      'Escaldar la espinaca 3-5 minutos.',
      'Integrar con aceite de linaza y cáscara de huevo molida.'
    ],
    storageInfo: 'Nevera 48h, congelador 2 meses.',
    macronutrients: { proteinPct: 46, fatPct: 17, fiberCarbPct: 25, moisturePct: 78 }
  },
  {
    id: 'dog-pup-11',
    title: 'Sardinas con Boniato y Calabacín para Cachorros',
    frenchTitle: 'Sardines Fraîches à la Patate Douce & Courgettes',
    species: 'dog',
    growthStage: 'puppy_kitten',
    category: 'joint_omega3',
    categoryLabel: 'Calcio Natural & Omega 3 Marino',
    description: 'Cocer las sardinas 8–10 min, el boniato 18–20 min y el calabacín 10 min. Mezclar con omega 3 y cáscara de huevo al final.',
    kcalPer100g: 135,
    prepTimeMin: 15,
    cookTimeMin: 20,
    difficulty: 'Fácil',
    suitability: 'Cachorros en crecimiento para articulaciones y dientes fuertes',
    clinicalBenefits: ['Pescado azul pequeño con mínima acumulación de metales pesados', 'EPA y DHA para desarrollo neurológico', 'Vitamina D natural'],
    ingredients: [
      { name: 'Sardinas frescas limpias evisceradas y sin espina central grande', category: 'protein', baseGramsFor10kgPetPerDay: 190, notes: 'Cocer 8-10 min' },
      { name: 'Boniato cocido en dados', category: 'fiber_carb', baseGramsFor10kgPetPerDay: 60, notes: 'Cocer 18-20 min' },
      { name: 'Calabacín en dados tiernos', category: 'vegetable', baseGramsFor10kgPetPerDay: 45, notes: 'Cocer 10 min' },
      { name: 'Omega 3 / Aceite de salmón', category: 'healthy_fat', baseGramsFor10kgPetPerDay: 3, notes: 'Añadir al final' },
      { name: 'Cáscara de huevo molida', category: 'supplement_calcium', baseGramsFor10kgPetPerDay: 4, notes: 'Calcio' }
    ],
    instructions: [
      'Cocer el boniato 18-20 min y el calabacín 10 min.',
      'Cocer las sardinas 8-10 min y desmigar con tenedor.',
      'Mezclar todo junto con el aceite omega 3 y la cáscara de huevo.'
    ],
    storageInfo: 'Consumir en 48 horas o congelar.',
    macronutrients: { proteinPct: 48, fatPct: 19, fiberCarbPct: 22, moisturePct: 77 }
  },
  {
    id: 'dog-pup-12',
    title: 'Pollo con Hígado y Arroz para Cachorros',
    frenchTitle: 'Poulet & Foie Tendre au Riz Blanc',
    species: 'dog',
    growthStage: 'puppy_kitten',
    category: 'vitality_gourmet',
    categoryLabel: 'Hierro & Vitamina A para Crecimiento',
    description: 'Cocer pollo 20 min, hígado 5–7 min y arroz 18–20 min. Añadir calcio en polvo o cáscara de huevo y dejar templar antes de servir.',
    kcalPer100g: 140,
    prepTimeMin: 15,
    cookTimeMin: 20,
    difficulty: 'Fácil',
    suitability: 'Cachorros con requerimientos elevados de micronutrientes y vitaminas del grupo B',
    clinicalBenefits: ['Aporte controlado de vitamina A y cobre mediante hígado', 'Hierro hemo para prevenir anemias nutricionales', 'Alta digestibilidad'],
    ingredients: [
      { name: 'Pechuga de pollo', category: 'protein', baseGramsFor10kgPetPerDay: 180, notes: 'Cocer 20 min' },
      { name: 'Hígado de pollo fresco', category: 'protein', baseGramsFor10kgPetPerDay: 20, notes: 'Cocer 5-7 min' },
      { name: 'Arroz blanco bien cocido', category: 'fiber_carb', baseGramsFor10kgPetPerDay: 70, notes: 'Cocer 18-20 min' },
      { name: 'Cáscara de huevo en polvo o calcio', category: 'supplement_calcium', baseGramsFor10kgPetPerDay: 5, notes: 'Añadir al templar' }
    ],
    instructions: [
      'Cocer el pollo 20 minutos y en los últimos 7 minutos añadir el hígado.',
      'Cocer el arroz blanco por separado 18-20 minutos.',
      'Picar fino las carnes, unir al arroz y espolvorear el calcio al templar.'
    ],
    storageInfo: 'Nevera 3 días, congelador 2 meses.',
    macronutrients: { proteinPct: 52, fatPct: 16, fiberCarbPct: 22, moisturePct: 76 }
  },
  {
    id: 'dog-pup-13',
    title: 'Pavo con Corazón y Calabaza para Cachorros',
    frenchTitle: 'Dinde & Cœur Énergétique au Potiron',
    species: 'dog',
    growthStage: 'puppy_kitten',
    category: 'vitality_gourmet',
    categoryLabel: 'Taurina Natural & Probióticos',
    description: 'Hervir el pavo y el corazón 20–25 min, calabaza 15 min. Incorporar probióticos y un poco de aceite de salmón al final.',
    kcalPer100g: 135,
    prepTimeMin: 15,
    cookTimeMin: 25,
    difficulty: 'Fácil',
    suitability: 'Cachorros activos para desarrollo cardiaco y vascular fuerte',
    clinicalBenefits: ['El corazón aporta taurina natural y coenzima Q10', 'Calabaza para regular motilidad intestinal', 'Probióticos para microbiota fuerte'],
    ingredients: [
      { name: 'Carne magra de pavo', category: 'protein', baseGramsFor10kgPetPerDay: 170, notes: 'Hervir 20-25 min' },
      { name: 'Corazón de pavo o pollo limpio', category: 'protein', baseGramsFor10kgPetPerDay: 30, notes: 'Hervir 20-25 min' },
      { name: 'Calabaza cocida', category: 'vegetable', baseGramsFor10kgPetPerDay: 60, notes: 'Hervir 15 min' },
      { name: 'Probióticos caninos', category: 'supplement_calcium', baseGramsFor10kgPetPerDay: 4, notes: 'Añadir al final' },
      { name: 'Aceite de salmón', category: 'healthy_fat', baseGramsFor10kgPetPerDay: 4, notes: 'Omega 3' },
      { name: 'Cáscara de huevo en polvo', category: 'supplement_calcium', baseGramsFor10kgPetPerDay: 5, notes: 'Calcio' }
    ],
    instructions: [
      'Hervir el pavo y el corazón juntos 20-25 minutos.',
      'Cocer la calabaza 15 minutos y triturar.',
      'Picar las carnes, unir a la calabaza y agregar probióticos y aceite de salmón al templar.'
    ],
    storageInfo: 'Nevera 3 días, congelador 2 meses.',
    macronutrients: { proteinPct: 50, fatPct: 18, fiberCarbPct: 21, moisturePct: 77 }
  },
  {
    id: 'dog-pup-14',
    title: 'Ternera Molida con Patata y Zanahoria para Cachorros',
    frenchTitle: 'Haché de Bœuf aux Pommes de Terre Chiot',
    species: 'dog',
    growthStage: 'puppy_kitten',
    category: 'vitality_gourmet',
    categoryLabel: 'Fácil Masticación & Crecimiento',
    description: 'Cocinar la ternera molida 10–12 min, patata 20 min y zanahoria 15 min. Terminar con cáscara de huevo y omega 3.',
    kcalPer100g: 140,
    prepTimeMin: 10,
    cookTimeMin: 20,
    difficulty: 'Fácil',
    suitability: 'Cachorros en fase de dentición o cambio de dientes',
    clinicalBenefits: ['Textura suave que no daña encías inflamadas por la dentición', 'Alta densidad calórica para cachorros juguetones', 'Calcio y fósforo balanceados'],
    ingredients: [
      { name: 'Carne picada magra de ternera', category: 'protein', baseGramsFor10kgPetPerDay: 190, notes: 'Cocinar 10-12 min' },
      { name: 'Patata cocida sin piel', category: 'fiber_carb', baseGramsFor10kgPetPerDay: 65, notes: 'Cocer 20 min' },
      { name: 'Zanahoria rallada', category: 'vegetable', baseGramsFor10kgPetPerDay: 45, notes: 'Cocer 15 min' },
      { name: 'Cáscara de huevo en polvo', category: 'supplement_calcium', baseGramsFor10kgPetPerDay: 5, notes: 'Calcio' },
      { name: 'Aceite de salmón / Omega 3', category: 'healthy_fat', baseGramsFor10kgPetPerDay: 4, notes: 'Añadir al final' }
    ],
    instructions: [
      'Cocinar la ternera picada en sartén sin aceite 10-12 minutos hasta que no esté cruda.',
      'Cocer la patata 20 min y la zanahoria 15 min, aplastar con tenedor.',
      'Mezclar carnes y verduras, agregando cáscara de huevo molida y omega 3.'
    ],
    storageInfo: 'Nevera 3 días, congelador 2 meses.',
    macronutrients: { proteinPct: 49, fatPct: 18, fiberCarbPct: 24, moisturePct: 76 }
  },
  {
    id: 'dog-pup-15',
    title: 'Salmón con Calabaza y Zanahoria para Cachorros',
    frenchTitle: 'Saumon Rose au Potimarron Doux Chiot',
    species: 'dog',
    growthStage: 'puppy_kitten',
    category: 'joint_omega3',
    categoryLabel: 'Piel Sana & Articulaciones Juveniles',
    description: 'Hornear el salmón 12–15 min, cocer calabaza 15 min y zanahoria 15 min. Añadir aceite de salmón y cáscara de huevo al servir.',
    kcalPer100g: 135,
    prepTimeMin: 15,
    cookTimeMin: 15,
    difficulty: 'Fácil',
    suitability: 'Cachorros propensos a caspa, piel seca o picores',
    clinicalBenefits: ['Concentración óptima de ácidos grasos marinos', 'Vitamina A en forma de carotenos vegetales seguros', 'Equilibrio Ca:P estricto'],
    ingredients: [
      { name: 'Lomo de salmón limpio de espinas', category: 'protein', baseGramsFor10kgPetPerDay: 200, notes: 'Hornear 12-15 min' },
      { name: 'Calabaza en dados', category: 'vegetable', baseGramsFor10kgPetPerDay: 50, notes: 'Cocer 15 min' },
      { name: 'Zanahoria en dados', category: 'vegetable', baseGramsFor10kgPetPerDay: 50, notes: 'Cocer 15 min' },
      { name: 'Aceite de salmón', category: 'healthy_fat', baseGramsFor10kgPetPerDay: 3, notes: 'Añadir al servir' },
      { name: 'Cáscara de huevo en polvo', category: 'supplement_calcium', baseGramsFor10kgPetPerDay: 5, notes: 'Calcio' }
    ],
    instructions: [
      'Hornear o cocer el salmón 12-15 minutos desmenuzando para asegurar cero espinas.',
      'Hervir la calabaza y la zanahoria 15 minutos hasta tiernas.',
      'Mezclar todo y servir con aceite de salmón y cáscara de huevo molida.'
    ],
    storageInfo: 'Nevera 48h, congelador 2 meses.',
    macronutrients: { proteinPct: 45, fatPct: 20, fiberCarbPct: 22, moisturePct: 78 }
  },
  {
    id: 'dog-pup-16',
    title: 'Conejo con Arroz Integral y Verduras para Cachorros',
    frenchTitle: 'Lapereau au Riz Complet & Légumes du Jardin',
    species: 'dog',
    growthStage: 'puppy_kitten',
    category: 'sensitive_digestion',
    categoryLabel: 'Fibra Digestiva & Carne Blanca',
    description: 'Guisar conejo 30–35 min, cocer arroz integral 25–30 min y verduras suaves 10 min. Terminar con aceite de linaza y cáscara de huevo.',
    kcalPer100g: 130,
    prepTimeMin: 15,
    cookTimeMin: 35,
    difficulty: 'Fácil',
    suitability: 'Cachorros que necesitan heces consistentes y digestiones ligeras',
    clinicalBenefits: ['Proteína hipoalergénica de fácil escisión enzimática', 'Fibra dietética insoluble para motilidad colónica', 'Omega 3 vegetal'],
    ingredients: [
      { name: 'Carne magra de conejo deshuesada', category: 'protein', baseGramsFor10kgPetPerDay: 200, notes: 'Guisar 30-35 min' },
      { name: 'Arroz integral bien cocido', category: 'fiber_carb', baseGramsFor10kgPetPerDay: 60, notes: 'Cocer 25-30 min' },
      { name: 'Verduras suaves (calabacín y judía verde)', category: 'vegetable', baseGramsFor10kgPetPerDay: 40, notes: 'Cocer 10 min' },
      { name: 'Aceite de linaza', category: 'healthy_fat', baseGramsFor10kgPetPerDay: 4, notes: 'Añadir al final' },
      { name: 'Cáscara de huevo molida', category: 'supplement_calcium', baseGramsFor10kgPetPerDay: 5, notes: 'Calcio' }
    ],
    instructions: [
      'Guisar el conejo 30-35 minutos asegurando extraer huesos.',
      'Cocer el arroz integral 25-30 minutos y las verduras suaves 10 minutos.',
      'Mezclar todo y agregar aceite de linaza y cáscara de huevo.'
    ],
    storageInfo: 'Nevera 3 días, congelador 2 meses.',
    macronutrients: { proteinPct: 47, fatPct: 15, fiberCarbPct: 25, moisturePct: 77 }
  },
  {
    id: 'dog-pup-17',
    title: 'Merluza con Boniato y Espinaca para Cachorros',
    frenchTitle: 'Merlu Blanc à la Patate Douce & Épinards',
    species: 'dog',
    growthStage: 'puppy_kitten',
    category: 'sensitive_digestion',
    categoryLabel: 'Minerales & Absorción Rápida',
    description: 'Cocer la merluza 10–12 min, boniato 18–20 min y espinaca 3–5 min. Añadir omega 3 y cáscara de huevo antes de servir.',
    kcalPer100g: 120,
    prepTimeMin: 15,
    cookTimeMin: 20,
    difficulty: 'Fácil',
    suitability: 'Cachorros convalecientes o con intolerancia a las aves',
    clinicalBenefits: ['Mínimo residuo gástrico y digestión no pesada', 'Boniato con potasio y betacarotenos', 'Omega 3 marino protector'],
    ingredients: [
      { name: 'Lomos de merluza fresca sin espinas', category: 'protein', baseGramsFor10kgPetPerDay: 220, notes: 'Cocer 10-12 min' },
      { name: 'Boniato cocido pelado', category: 'fiber_carb', baseGramsFor10kgPetPerDay: 65, notes: 'Cocer 18-20 min' },
      { name: 'Espinaca fresca escaldada', category: 'vegetable', baseGramsFor10kgPetPerDay: 30, notes: 'Cocer 3-5 min' },
      { name: 'Aceite de salmón', category: 'healthy_fat', baseGramsFor10kgPetPerDay: 4, notes: 'Añadir templado' },
      { name: 'Cáscara de huevo en polvo', category: 'supplement_calcium', baseGramsFor10kgPetPerDay: 5, notes: 'Calcio' }
    ],
    instructions: [
      'Cocer la merluza 10-12 minutos revisando minuciosamente espinas.',
      'Cocer el boniato 18-20 min y escaldar las espinacas los últimos 4 minutos.',
      'Triturar o desmigar y servir con aceite de salmón y cáscara de huevo molida.'
    ],
    storageInfo: 'Nevera 48h, congelador 2 meses.',
    macronutrients: { proteinPct: 45, fatPct: 14, fiberCarbPct: 25, moisturePct: 80 }
  },
  {
    id: 'dog-pup-18',
    title: 'Pato con Quinoa y Manzana para Cachorros',
    frenchTitle: 'Filet de Canard au Quinoa & Purée de Pomme',
    species: 'dog',
    growthStage: 'puppy_kitten',
    category: 'vitality_gourmet',
    categoryLabel: 'Energía Digestiva & Probióticos',
    description: 'Cocinar pato 20–25 min, quinoa 15 min y manzana 5 min sin semillas. Incorporar probióticos y cáscara de huevo al final.',
    kcalPer100g: 140,
    prepTimeMin: 15,
    cookTimeMin: 25,
    difficulty: 'Fácil',
    suitability: 'Cachorros enérgicos que necesitan desarrollo muscular fuerte',
    clinicalBenefits: ['Quinoa libre de gluten con perfil balanceado de carbohidratos', 'Manzana con ácido málico y pectina para enterocitos', 'Probióticos'],
    ingredients: [
      { name: 'Carne magra de pato troceada', category: 'protein', baseGramsFor10kgPetPerDay: 190, notes: 'Cocinar 20-25 min' },
      { name: 'Quinoa cocida', category: 'fiber_carb', baseGramsFor10kgPetPerDay: 60, notes: 'Cocer 15 min' },
      { name: 'Manzana pelada y sin semillas', category: 'vegetable', baseGramsFor10kgPetPerDay: 40, notes: 'Cocer 5 min' },
      { name: 'Probióticos caninos', category: 'supplement_calcium', baseGramsFor10kgPetPerDay: 3, notes: 'Añadir al final' },
      { name: 'Cáscara de huevo molida', category: 'supplement_calcium', baseGramsFor10kgPetPerDay: 5, notes: 'Calcio' }
    ],
    instructions: [
      'Cocinar el pato 20-25 minutos.',
      'Cocer la quinoa 15 minutos en abundante agua.',
      'Ablandar la manzana 5 minutos al vapor y machacar.',
      'Mezclar todo y espolvorear los probióticos y la cáscara de huevo en templado.'
    ],
    storageInfo: 'Nevera 3 días, congelador 2 meses.',
    macronutrients: { proteinPct: 48, fatPct: 18, fiberCarbPct: 23, moisturePct: 76 }
  },
  {
    id: 'dog-pup-19',
    title: 'Cordero con Patata y Calabacín para Cachorros',
    frenchTitle: 'Agneau Tendre aux Pommes de Terre & Courgettes',
    species: 'dog',
    growthStage: 'puppy_kitten',
    category: 'vitality_gourmet',
    categoryLabel: 'Sabor Tradicional & Densidad Energética',
    description: 'Guisar cordero 30 min, patata 20 min y calabacín 10 min. Añadir aceite de salmón y una pizca de cáscara de huevo al final.',
    kcalPer100g: 140,
    prepTimeMin: 15,
    cookTimeMin: 30,
    difficulty: 'Fácil',
    suitability: 'Cachorros en fase de crecimiento rápido',
    clinicalBenefits: ['Zinc y selenio para maduración inmunitaria', 'Patata como fuente limpia de glucógeno muscular', 'Omega 3 para retina y cerebro'],
    ingredients: [
      { name: 'Carne magra de cordero deshuesada', category: 'protein', baseGramsFor10kgPetPerDay: 190, notes: 'Guisar 30 min' },
      { name: 'Patata cocida pelada', category: 'fiber_carb', baseGramsFor10kgPetPerDay: 65, notes: 'Cocer 20 min' },
      { name: 'Calabacín en dados', category: 'vegetable', baseGramsFor10kgPetPerDay: 45, notes: 'Cocer 10 min' },
      { name: 'Aceite de salmón', category: 'healthy_fat', baseGramsFor10kgPetPerDay: 4, notes: 'Añadir al final' },
      { name: 'Cáscara de huevo molida', category: 'supplement_calcium', baseGramsFor10kgPetPerDay: 5, notes: 'Calcio' }
    ],
    instructions: [
      'Guisar el cordero 30 minutos retirando excedente graso.',
      'Cocer la patata 20 min y el calabacín 10 min.',
      'Picar todo fino y servir con aceite de salmón y cáscara de huevo molida.'
    ],
    storageInfo: 'Nevera 3 días, congelador 2 meses.',
    macronutrients: { proteinPct: 47, fatPct: 19, fiberCarbPct: 23, moisturePct: 76 }
  },
  {
    id: 'dog-pup-20',
    title: 'Bacalao con Arroz y Verduras para Cachorros',
    frenchTitle: 'Cabillaud Cuit au Riz Doux & Légumes Mixtes',
    species: 'dog',
    growthStage: 'puppy_kitten',
    category: 'sensitive_digestion',
    categoryLabel: 'Digestión Cero-Fatiga',
    description: 'Cocer bacalao 8–10 min, arroz 18–20 min y verduras suaves 10–12 min. Terminar con omega 3 y cáscara de huevo cuando esté templado.',
    kcalPer100g: 120,
    prepTimeMin: 15,
    cookTimeMin: 20,
    difficulty: 'Fácil',
    suitability: 'Cachorros tras episodios de diarrea o sensibilidad gástrica',
    clinicalBenefits: ['Muy baja presencia de lípidos pesados', 'Almidón gelatinizado de arroz para asentar el tránsito', 'Aporte de electrolitos y calcio'],
    ingredients: [
      { name: 'Bacalao fresco sin espinas', category: 'protein', baseGramsFor10kgPetPerDay: 210, notes: 'Cocer 8-10 min' },
      { name: 'Arroz blanco cocido', category: 'fiber_carb', baseGramsFor10kgPetPerDay: 65, notes: 'Cocer 18-20 min' },
      { name: 'Verduras suaves (calabaza y zanahoria)', category: 'vegetable', baseGramsFor10kgPetPerDay: 45, notes: 'Cocer 10-12 min' },
      { name: 'Omega 3 / Aceite de pescado', category: 'healthy_fat', baseGramsFor10kgPetPerDay: 4, notes: 'Añadir templado' },
      { name: 'Cáscara de huevo en polvo', category: 'supplement_calcium', baseGramsFor10kgPetPerDay: 5, notes: 'Calcio' }
    ],
    instructions: [
      'Cocer el bacalao 8-10 minutos y revisar minuciosamente espinas.',
      'Cocer el arroz 18-20 minutos y las verduras suaves 10-12 minutos.',
      'Mezclar desmenuzando con tenedor y agregar omega 3 y cáscara de huevo molida cuando esté templado.'
    ],
    storageInfo: 'Nevera 48h, congelador 2 meses.',
    macronutrients: { proteinPct: 46, fatPct: 13, fiberCarbPct: 26, moisturePct: 80 }
  },
  {
    id: 'dog-pup-21',
    title: 'Codorniz con Quinoa y Zanahoria para Cachorros ⭐',
    frenchTitle: 'Caille Fermière au Quinoa & Carottes Croquantes',
    species: 'dog',
    growthStage: 'puppy_kitten',
    category: 'vitality_gourmet',
    categoryLabel: 'Receta Premium de Alta Densidad',
    description: 'Premium. Guisar codorniz 25–30 min, cocer quinoa 15 min y zanahoria 15 min. Añadir cáscara de huevo y aceite de salmón al final.',
    kcalPer100g: 145,
    prepTimeMin: 15,
    cookTimeMin: 30,
    difficulty: 'Media',
    suitability: 'Cachorros de alta exigencia nutricional y cachorros que comen poco',
    clinicalBenefits: ['Proteína de ave de caza silvestre con alta biodisponibilidad', 'Densidad de micronutrientes (cobre, fósforo orgánico, hierro)', 'Palatabilidad excelente'],
    ingredients: [
      { name: 'Carne de codorniz deshuesada con cuidado', category: 'protein', baseGramsFor10kgPetPerDay: 190, notes: 'Guisar 25-30 min' },
      { name: 'Quinoa cocida', category: 'fiber_carb', baseGramsFor10kgPetPerDay: 60, notes: 'Cocer 15 min' },
      { name: 'Zanahoria en dados tiernos', category: 'vegetable', baseGramsFor10kgPetPerDay: 45, notes: 'Cocer 15 min' },
      { name: 'Aceite de salmón', category: 'healthy_fat', baseGramsFor10kgPetPerDay: 4, notes: 'Añadir al final' },
      { name: 'Cáscara de huevo en polvo', category: 'supplement_calcium', baseGramsFor10kgPetPerDay: 5, notes: 'Calcio' }
    ],
    instructions: [
      'Guisar la codorniz 25-30 minutos y desmigar meticulosamente eliminando todos los huesos.',
      'Cocer la quinoa 15 minutos y la zanahoria 15 minutos.',
      'Mezclar todo junto con el aceite de salmón y la cáscara de huevo molida.'
    ],
    storageInfo: 'Nevera 3 días, congelador 2 meses.',
    macronutrients: { proteinPct: 50, fatPct: 18, fiberCarbPct: 22, moisturePct: 76 }
  },
  {
    id: 'dog-pup-22',
    title: 'Faisán con Boniato y Espinaca para Cachorros ⭐',
    frenchTitle: 'Faisan Sauvage à la Patate Douce & Épinards',
    species: 'dog',
    growthStage: 'puppy_kitten',
    category: 'vitality_gourmet',
    categoryLabel: 'Receta Premium Regenerativa',
    description: 'Premium. Cocinar faisán 30–35 min, boniato 18–20 min y espinaca 3–5 min. Terminar con probióticos y cáscara de huevo.',
    kcalPer100g: 140,
    prepTimeMin: 15,
    cookTimeMin: 35,
    difficulty: 'Media',
    suitability: 'Cachorros de razas grandes que requieren proteína silvestre y desarrollo armónico',
    clinicalBenefits: ['Faisán con bajo contenido de grasa saturada y rico en B12', 'Boniato para soporte muscular', 'Probióticos para colonización intestinal'],
    ingredients: [
      { name: 'Carne de faisán deshuesada', category: 'protein', baseGramsFor10kgPetPerDay: 190, notes: 'Cocinar 30-35 min' },
      { name: 'Boniato cocido', category: 'fiber_carb', baseGramsFor10kgPetPerDay: 65, notes: 'Cocer 18-20 min' },
      { name: 'Espinaca fresca escaldada', category: 'vegetable', baseGramsFor10kgPetPerDay: 35, notes: 'Cocer 3-5 min' },
      { name: 'Probióticos en polvo', category: 'supplement_calcium', baseGramsFor10kgPetPerDay: 3, notes: 'Añadir al final' },
      { name: 'Cáscara de huevo molida', category: 'supplement_calcium', baseGramsFor10kgPetPerDay: 5, notes: 'Calcio' }
    ],
    instructions: [
      'Cocinar el faisán 30-35 minutos asegurando extraer huesos.',
      'Hervir el boniato 18-20 minutos y escaldar la espinaca 3-5 minutos.',
      'Mezclar todo e incorporar probióticos y cáscara de huevo molida al templar.'
    ],
    storageInfo: 'Nevera 3 días, congelador 2 meses.',
    macronutrients: { proteinPct: 49, fatPct: 16, fiberCarbPct: 24, moisturePct: 77 }
  },
  {
    id: 'dog-pup-23',
    title: 'Caballa con Arroz Integral y Calabacín para Cachorros ⭐',
    frenchTitle: 'Maquereau Bleu au Riz Complet & Courgettes',
    species: 'dog',
    growthStage: 'puppy_kitten',
    category: 'joint_omega3',
    categoryLabel: 'Receta Premium Omega 3 Puro',
    description: 'Premium. Cocer caballa 10–12 min, arroz integral 25–30 min y calabacín 10 min. Añadir aceite de linaza y cáscara de huevo al servir.',
    kcalPer100g: 145,
    prepTimeMin: 15,
    cookTimeMin: 30,
    difficulty: 'Fácil',
    suitability: 'Cachorros en crecimiento con necesidad de soporte neurosensorial',
    clinicalBenefits: ['Pescado azul rico en ácidos grasos poliinsaturados', 'Aceite de linaza con ácido alfa-linolénico', 'Fibra dietética integral'],
    ingredients: [
      { name: 'Filetes limpios de caballa fresca', category: 'protein', baseGramsFor10kgPetPerDay: 190, notes: 'Cocer 10-12 min' },
      { name: 'Arroz integral muy cocido', category: 'fiber_carb', baseGramsFor10kgPetPerDay: 60, notes: 'Cocer 25-30 min' },
      { name: 'Calabacín en dados', category: 'vegetable', baseGramsFor10kgPetPerDay: 45, notes: 'Cocer 10 min' },
      { name: 'Aceite de linaza', category: 'healthy_fat', baseGramsFor10kgPetPerDay: 4, notes: 'En crudo' },
      { name: 'Cáscara de huevo en polvo', category: 'supplement_calcium', baseGramsFor10kgPetPerDay: 5, notes: 'Calcio' }
    ],
    instructions: [
      'Cocer la caballa 10-12 minutos y revisar meticulosamente espinas.',
      'Cocer el arroz integral 25-30 min y el calabacín 10 min.',
      'Unir todo con el aceite de linaza y la cáscara de huevo en polvo al servir.'
    ],
    storageInfo: 'Consumir en 48 horas en frío.',
    macronutrients: { proteinPct: 47, fatPct: 20, fiberCarbPct: 22, moisturePct: 76 }
  },
  {
    id: 'dog-pup-24',
    title: 'Trucha con Quinoa Roja y Verduras para Cachorros ⭐',
    frenchTitle: 'Truite Dorée au Quinoa Rouge & Légumes',
    species: 'dog',
    growthStage: 'puppy_kitten',
    category: 'joint_omega3',
    categoryLabel: 'Receta Premium Antioxidante',
    description: 'Premium. Hornear trucha 12–15 min, cocer quinoa roja 15–18 min y verduras suaves 10 min. Incorporar omega 3 y cáscara de huevo al final.',
    kcalPer100g: 135,
    prepTimeMin: 15,
    cookTimeMin: 20,
    difficulty: 'Fácil',
    suitability: 'Cachorros enérgicos con necesidad de protección celular y articular',
    clinicalBenefits: ['Quinoa roja rica en antocianinas y flavonoides', 'Omega-3 de pescado de agua dulce', 'Excelente tolerancia'],
    ingredients: [
      { name: 'Trucha fresca desespinada', category: 'protein', baseGramsFor10kgPetPerDay: 200, notes: 'Hornear 12-15 min' },
      { name: 'Quinoa roja cocida', category: 'fiber_carb', baseGramsFor10kgPetPerDay: 60, notes: 'Cocer 15-18 min' },
      { name: 'Verduras suaves (calabaza y zanahoria)', category: 'vegetable', baseGramsFor10kgPetPerDay: 45, notes: 'Cocer 10 min' },
      { name: 'Aceite de salmón / Omega 3', category: 'healthy_fat', baseGramsFor10kgPetPerDay: 4, notes: 'Añadir al final' },
      { name: 'Cáscara de huevo en polvo', category: 'supplement_calcium', baseGramsFor10kgPetPerDay: 5, notes: 'Calcio' }
    ],
    instructions: [
      'Hornear los filetes de trucha 12-15 minutos y desmigar verificando espinas.',
      'Cocer la quinoa roja 15-18 minutos y las verduras suaves 10 minutos.',
      'Mezclar todos los ingredientes con el omega 3 y el calcio al templar.'
    ],
    storageInfo: 'Nevera 48h, congelador 2 meses.',
    macronutrients: { proteinPct: 46, fatPct: 18, fiberCarbPct: 24, moisturePct: 77 }
  },
  {
    id: 'dog-pup-25',
    title: 'Pato con Batata Morada y Manzana para Cachorros ⭐',
    frenchTitle: 'Canard Confit à la Patate Violette & Pommes Chiot',
    species: 'dog',
    growthStage: 'puppy_kitten',
    category: 'vitality_gourmet',
    categoryLabel: 'Receta Premium Antocianinas & Sabor',
    description: 'Premium. Cocinar pato 20–25 min, batata morada 20 min y manzana 5 min sin semillas. Añadir probióticos y cáscara de huevo al final.',
    kcalPer100g: 145,
    prepTimeMin: 15,
    cookTimeMin: 25,
    difficulty: 'Fácil',
    suitability: 'Cachorros en fase activa para desarrollo inmunitario de vanguardia',
    clinicalBenefits: ['Batata morada con altísimo contenido en antocianinas', 'Grasa monoinsaturada saludable de pato', 'Probióticos'],
    ingredients: [
      { name: 'Carne magra de pato', category: 'protein', baseGramsFor10kgPetPerDay: 190, notes: 'Cocinar 20-25 min' },
      { name: 'Batata morada cocida pelada', category: 'fiber_carb', baseGramsFor10kgPetPerDay: 65, notes: 'Cocer 20 min' },
      { name: 'Manzana pelada sin semillas', category: 'vegetable', baseGramsFor10kgPetPerDay: 35, notes: 'Cocer 5 min' },
      { name: 'Probióticos caninos', category: 'supplement_calcium', baseGramsFor10kgPetPerDay: 3, notes: 'Añadir al final' },
      { name: 'Cáscara de huevo en polvo', category: 'supplement_calcium', baseGramsFor10kgPetPerDay: 5, notes: 'Calcio' }
    ],
    instructions: [
      'Cocinar el pato 20-25 minutos.',
      'Cocer la batata morada 20 minutos y la manzana 5 minutos al vapor.',
      'Triturar o desmenuzar y mezclar con los probióticos y el calcio al templar.'
    ],
    storageInfo: 'Nevera 3 días, congelador 2 meses.',
    macronutrients: { proteinPct: 47, fatPct: 19, fiberCarbPct: 24, moisturePct: 76 }
  },
  {
    id: 'dog-pup-26',
    title: 'Conejo con Lenteja Roja y Verduras para Cachorros ⭐',
    frenchTitle: 'Lapin Tendre aux Lentilles Corail & Légumes',
    species: 'dog',
    growthStage: 'puppy_kitten',
    category: 'sensitive_digestion',
    categoryLabel: 'Receta Premium Legumbre Suave',
    description: 'Premium. Guisar conejo 30–35 min, cocer lenteja roja 12–15 min y verduras suaves 10 min. Terminar con aceite de salmón y cáscara de huevo.',
    kcalPer100g: 135,
    prepTimeMin: 15,
    cookTimeMin: 35,
    difficulty: 'Fácil',
    suitability: 'Cachorros para variedad de fuentes de fibra soluble y aminoácidos',
    clinicalBenefits: ['Lenteja roja desprovista de piel gruesa de muy fácil digestión', 'Aporte vegetal de hierro y folatos', 'Conejo magro digestivo'],
    ingredients: [
      { name: 'Carne de conejo deshuesada', category: 'protein', baseGramsFor10kgPetPerDay: 200, notes: 'Guisar 30-35 min' },
      { name: 'Lenteja roja pelada cocida', category: 'fiber_carb', baseGramsFor10kgPetPerDay: 55, notes: 'Cocer 12-15 min' },
      { name: 'Verduras suaves (calabaza y calabacín)', category: 'vegetable', baseGramsFor10kgPetPerDay: 40, notes: 'Cocer 10 min' },
      { name: 'Aceite de salmón', category: 'healthy_fat', baseGramsFor10kgPetPerDay: 4, notes: 'Añadir al final' },
      { name: 'Cáscara de huevo molida', category: 'supplement_calcium', baseGramsFor10kgPetPerDay: 5, notes: 'Calcio' }
    ],
    instructions: [
      'Guisar el conejo 30-35 minutos desmigando sin huesos.',
      'Hervir la lenteja roja 12-15 minutos hasta que quede cremosa.',
      'Cocer las verduras suaves 10 minutos.',
      'Integrar todo con el aceite de salmón y la cáscara de huevo molida.'
    ],
    storageInfo: 'Nevera 3 días, congelador 2 meses.',
    macronutrients: { proteinPct: 49, fatPct: 15, fiberCarbPct: 24, moisturePct: 77 }
  },
  {
    id: 'dog-pup-27',
    title: 'Salmón con Calabaza y Probióticos para Cachorros ⭐',
    frenchTitle: 'Saumon Doux au Potiron & Probiotiques Vivants',
    species: 'dog',
    growthStage: 'puppy_kitten',
    category: 'joint_omega3',
    categoryLabel: 'Receta Premium Flora & Articulaciones',
    description: 'Premium. Cocinar salmón 12–15 min y calabaza 15 min. Añadir probióticos cuando la mezcla esté templada, junto con cáscara de huevo.',
    kcalPer100g: 135,
    prepTimeMin: 15,
    cookTimeMin: 15,
    difficulty: 'Fácil',
    suitability: 'Cachorros en transición nutricional para evitar cólicos o heces blandas',
    clinicalBenefits: ['Calabaza como vehículo prebiótico natural', 'EPA y DHA de salmón fresco', 'Cepas probióticas viables'],
    ingredients: [
      { name: 'Salmón fresco limpio de espinas', category: 'protein', baseGramsFor10kgPetPerDay: 200, notes: 'Cocinar 12-15 min' },
      { name: 'Calabaza cocida tierna', category: 'vegetable', baseGramsFor10kgPetPerDay: 80, notes: 'Cocer 15 min' },
      { name: 'Probióticos caninos', category: 'supplement_calcium', baseGramsFor10kgPetPerDay: 4, notes: 'Añadir al final templado' },
      { name: 'Cáscara de huevo en polvo', category: 'supplement_calcium', baseGramsFor10kgPetPerDay: 5, notes: 'Calcio bioasimilable' }
    ],
    instructions: [
      'Cocinar el salmón al vapor 12-15 minutos revisando que no queden espinas.',
      'Cocer la calabaza 15 minutos y aplastar en puré fino.',
      'Mezclar ambos ingredientes y añadir los probióticos y el calcio una vez tibio.'
    ],
    storageInfo: 'Nevera 48h, congelador 2 meses.',
    macronutrients: { proteinPct: 46, fatPct: 20, fiberCarbPct: 20, moisturePct: 78 }
  },
  {
    id: 'dog-pup-28',
    title: 'Cordero con Boniato y Glucosamina para Cachorros ⭐',
    frenchTitle: 'Agneau & Patate Douce à la Glucosamine Protectrice',
    species: 'dog',
    growthStage: 'puppy_kitten',
    category: 'joint_omega3',
    categoryLabel: 'Receta Premium Soporte Osteoarticular',
    description: 'Premium. Guisar cordero 30 min y boniato 18–20 min. Añadir glucosamina, omega 3 y cáscara de huevo al final.',
    kcalPer100g: 145,
    prepTimeMin: 15,
    cookTimeMin: 30,
    difficulty: 'Fácil',
    suitability: 'Cachorros de razas grandes o gigantes con rápido crecimiento óseo',
    clinicalBenefits: ['Protección temprana del cartílago articular en crecimiento', 'Cordero nutritivo de digestión suave', 'Omega-3 de refuerzo'],
    ingredients: [
      { name: 'Carne magra de cordero', category: 'protein', baseGramsFor10kgPetPerDay: 190, notes: 'Guisar 30 min' },
      { name: 'Boniato cocido pelado', category: 'fiber_carb', baseGramsFor10kgPetPerDay: 70, notes: 'Cocer 18-20 min' },
      { name: 'Glucosamina canina en polvo', category: 'supplement_calcium', baseGramsFor10kgPetPerDay: 2, notes: 'Añadir al servir' },
      { name: 'Aceite de salmón', category: 'healthy_fat', baseGramsFor10kgPetPerDay: 4, notes: 'Omega 3' },
      { name: 'Cáscara de huevo molida', category: 'supplement_calcium', baseGramsFor10kgPetPerDay: 5, notes: 'Calcio' }
    ],
    instructions: [
      'Guisar el cordero 30 minutos retirando grasa flotante.',
      'Cocer el boniato 18-20 minutos y machacar con tenedor.',
      'Unir y suplementar con glucosamina, aceite de salmón y cáscara de huevo molida.'
    ],
    storageInfo: 'Nevera 3 días, congelador 2 meses.',
    macronutrients: { proteinPct: 48, fatPct: 19, fiberCarbPct: 22, moisturePct: 76 }
  },
  {
    id: 'dog-pup-29',
    title: 'Bacalao con Arroz Germinado y Espinaca para Cachorros ⭐',
    frenchTitle: 'Cabillaud au Riz Germé & Jeunes Pousses d Épinard',
    species: 'dog',
    growthStage: 'puppy_kitten',
    category: 'sensitive_digestion',
    categoryLabel: 'Receta Premium Enzimas Activas',
    description: 'Premium. Cocer bacalao 8–10 min, arroz germinado 18–20 min y espinaca 3–5 min. Terminar con aceite de linaza y cáscara de huevo.',
    kcalPer100g: 120,
    prepTimeMin: 15,
    cookTimeMin: 20,
    difficulty: 'Fácil',
    suitability: 'Cachorros que necesitan absorción mineral maximizada y ligereza',
    clinicalBenefits: ['El arroz germinado posee GABA y enzimas activadas', 'Bacalao suave rico en fósforo orgánico y selenio', 'Espinaca rica en hierro'],
    ingredients: [
      { name: 'Bacalao fresco desmigado sin espinas', category: 'protein', baseGramsFor10kgPetPerDay: 210, notes: 'Cocer 8-10 min' },
      { name: 'Arroz germinado cocido', category: 'fiber_carb', baseGramsFor10kgPetPerDay: 60, notes: 'Cocer 18-20 min' },
      { name: 'Espinacas tiernas', category: 'vegetable', baseGramsFor10kgPetPerDay: 35, notes: 'Escaldar 3-5 min' },
      { name: 'Aceite de linaza', category: 'healthy_fat', baseGramsFor10kgPetPerDay: 4, notes: 'En crudo' },
      { name: 'Cáscara de huevo molida', category: 'supplement_calcium', baseGramsFor10kgPetPerDay: 5, notes: 'Calcio' }
    ],
    instructions: [
      'Cocer el arroz germinado 18-20 minutos.',
      'Cocer el bacalao 8-10 minutos comprobando espinas y escaldar la espinaca 3-5 min.',
      'Mezclar todo agregando aceite de linaza y cáscara de huevo molida al final.'
    ],
    storageInfo: 'Nevera 48h, congelador 2 meses.',
    macronutrients: { proteinPct: 47, fatPct: 14, fiberCarbPct: 24, moisturePct: 80 }
  },
  {
    id: 'dog-pup-30',
    title: 'Pollo con Hígado y Quinoa para Cachorros ⭐',
    frenchTitle: 'Volaille Royale au Foie & Quinoa Blanc',
    species: 'dog',
    growthStage: 'puppy_kitten',
    category: 'vitality_gourmet',
    categoryLabel: 'Receta Premium Completa de Crecimiento',
    description: 'Premium. Cocer pollo 20 min, hígado 5–7 min y quinoa 15 min. Añadir probióticos, omega 3 y cáscara de huevo al servir.',
    kcalPer100g: 145,
    prepTimeMin: 15,
    cookTimeMin: 20,
    difficulty: 'Fácil',
    suitability: 'Cachorros en fase culminante de crecimiento para vitalidad y pelaje espectacular',
    clinicalBenefits: ['Densidad óptima de aminoácidos esenciales y oligoelementos', 'Quinoa sin alérgenos comunes', 'Probióticos + Omega 3 sinérgicos'],
    ingredients: [
      { name: 'Pechuga de pollo', category: 'protein', baseGramsFor10kgPetPerDay: 180, notes: 'Cocer 20 min' },
      { name: 'Hígado de pollo fresco', category: 'protein', baseGramsFor10kgPetPerDay: 20, notes: 'Cocer 5-7 min' },
      { name: 'Quinoa cocida', category: 'fiber_carb', baseGramsFor10kgPetPerDay: 60, notes: 'Cocer 15 min' },
      { name: 'Probióticos caninos', category: 'supplement_calcium', baseGramsFor10kgPetPerDay: 3, notes: 'Añadir al templar' },
      { name: 'Aceite de salmón', category: 'healthy_fat', baseGramsFor10kgPetPerDay: 4, notes: 'Omega 3' },
      { name: 'Cáscara de huevo en polvo', category: 'supplement_calcium', baseGramsFor10kgPetPerDay: 5, notes: 'Calcio' }
    ],
    instructions: [
      'Cocer el pollo 20 minutos y añadir el hígado los últimos 5-7 minutos.',
      'Cocer la quinoa 15 minutos en agua hirviendo y escurrir.',
      'Picar fino las carnes, integrar con la quinoa y añadir probióticos, aceite de salmón y calcio al templar.'
    ],
    storageInfo: 'Nevera 3 días, congelador 2 meses.',
    macronutrients: { proteinPct: 52, fatPct: 17, fiberCarbPct: 22, moisturePct: 76 }
  }
];
