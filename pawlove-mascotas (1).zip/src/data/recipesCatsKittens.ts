import { Recipe } from '../types';

export const CAT_KITTEN_RECIPES: Recipe[] = [
  {
    id: 'cat-kit-01',
    title: 'Pollo con Corazón e Hígado para Gatitos',
    frenchTitle: 'Poulet aux Cœurs & Foie Tendre pour Chaton',
    species: 'cat',
    growthStage: 'puppy_kitten',
    category: 'vitality_gourmet',
    categoryLabel: 'Carnívoro Estricto & Taurina Natural',
    description: 'Cocer pollo 20 min, corazón e hígado 7 min. Añadir taurina, aceite de salmón y cáscara de huevo.',
    kcalPer100g: 135,
    prepTimeMin: 15,
    cookTimeMin: 20,
    difficulty: 'Fácil',
    suitability: 'Gatitos en crecimiento rápido (2 a 12 meses)',
    clinicalBenefits: ['Taurina natural del miocardio (corazón) para visión y corazón', 'Vitamina A biodisponible de hígado', 'Calcio'],
    ingredients: [
      { name: 'Pechuga o contramuslo de pollo deshuesado', category: 'protein', baseGramsFor10kgPetPerDay: 85, notes: 'Cocer 20 min' },
      { name: 'Corazón de pollo (taurina concentrada)', category: 'organ_meat', baseGramsFor10kgPetPerDay: 30, notes: 'Cocer 7 min' },
      { name: 'Hígado de pollo fresco', category: 'organ_meat', baseGramsFor10kgPetPerDay: 10, notes: 'Cocer 7 min' },
      { name: 'Taurina en polvo grado felino', category: 'supplement_calcium', baseGramsFor10kgPetPerDay: 0.5, notes: 'Imprescindible en gatos' },
      { name: 'Aceite de salmón', category: 'healthy_fat', baseGramsFor10kgPetPerDay: 2, notes: 'DHA cerebral' },
      { name: 'Cáscara de huevo molida', category: 'supplement_calcium', baseGramsFor10kgPetPerDay: 2, notes: 'Calcio' }
    ],
    instructions: [
      'Cocer el pollo 20 minutos, añadiendo los corazones y el hígado en los últimos 7 minutos.',
      'Triturar o picar en dados minúsculos aptos para mandíbulas de gatito.',
      'Añadir la taurina en polvo, el aceite de salmón y la cáscara de huevo cuando esté templado.'
    ],
    storageInfo: 'Nevera 48h, congelador 2 meses.',
    macronutrients: { proteinPct: 56, fatPct: 28, fiberCarbPct: 4, moisturePct: 76 }
  },
  {
    id: 'cat-kit-02',
    title: 'Pavo con Huevo Cocido para Gatitos',
    frenchTitle: 'Dinde aux Œufs Émiettés Chaton',
    species: 'cat',
    growthStage: 'puppy_kitten',
    category: 'vitality_gourmet',
    categoryLabel: 'Proteína Blanca de Alto Valor Biológico',
    description: 'Cocer pavo 20 min y huevo 10 min. Mezclar con taurina, aceite de linaza y cáscara de huevo.',
    kcalPer100g: 130,
    prepTimeMin: 10,
    cookTimeMin: 20,
    difficulty: 'Fácil',
    suitability: 'Gatitos desde el destete con requerimientos de aminoácidos puros',
    clinicalBenefits: ['Colina y fosfolípidos del huevo para desarrollo cognitivo', 'Digestión liviana y sin distensión', 'Taurina'],
    ingredients: [
      { name: 'Pechuga o muslo de pavo picado', category: 'protein', baseGramsFor10kgPetPerDay: 90, notes: 'Cocer 20 min' },
      { name: 'Huevo entero duro picado fino', category: 'protein', baseGramsFor10kgPetPerDay: 25, notes: 'Cocer 10 min' },
      { name: 'Taurina felina', category: 'supplement_calcium', baseGramsFor10kgPetPerDay: 0.5, notes: 'Al templar' },
      { name: 'Aceite de linaza', category: 'healthy_fat', baseGramsFor10kgPetPerDay: 2, notes: 'En crudo' },
      { name: 'Cáscara de huevo molida', category: 'supplement_calcium', baseGramsFor10kgPetPerDay: 2, notes: 'Calcio' }
    ],
    instructions: [
      'Cocer el pavo 20 minutos y trocear muy menudo.',
      'Cocer el huevo 10 minutos, pelar y chafar fino.',
      'Unir todo e incorporar taurina, aceite de linaza y cáscara de huevo molida.'
    ],
    storageInfo: 'Nevera 48h, congelador 2 meses.',
    macronutrients: { proteinPct: 54, fatPct: 26, fiberCarbPct: 3, moisturePct: 75 }
  },
  {
    id: 'cat-kit-03',
    title: 'Conejo con Corazón de Pollo para Gatitos',
    frenchTitle: 'Lapin Tendre & Cœurs de Volaille Chaton',
    species: 'cat',
    growthStage: 'puppy_kitten',
    category: 'sensitive_digestion',
    categoryLabel: 'Hipoalergénico Felino & Bomba de Taurina',
    description: 'Cocer conejo 35 min y corazón 7 min. Terminar con taurina, aceite de salmón y cáscara de huevo.',
    kcalPer100g: 130,
    prepTimeMin: 15,
    cookTimeMin: 35,
    difficulty: 'Fácil',
    suitability: 'Gatitos con digestiones propensas a diarreas o alergias tempranas',
    clinicalBenefits: ['Proteína hipoalergénica de conejo de excelente digestibilidad', 'Taurina multiplicada con corazón', 'DHA'],
    ingredients: [
      { name: 'Carne magra de conejo deshuesada', category: 'protein', baseGramsFor10kgPetPerDay: 85, notes: 'Cocer 35 min' },
      { name: 'Corazón de pollo picado', category: 'organ_meat', baseGramsFor10kgPetPerDay: 30, notes: 'Cocer 7 min' },
      { name: 'Taurina en polvo', category: 'supplement_calcium', baseGramsFor10kgPetPerDay: 0.5, notes: 'Al templar' },
      { name: 'Aceite de salmón', category: 'healthy_fat', baseGramsFor10kgPetPerDay: 2, notes: 'Omega 3' },
      { name: 'Cáscara de huevo molida', category: 'supplement_calcium', baseGramsFor10kgPetPerDay: 2, notes: 'Calcio' }
    ],
    instructions: [
      'Cocer el conejo 35 minutos y asegurarse de quitar todos los huesos.',
      'Cocer el corazón 7 minutos y picar en brunoise fina.',
      'Mezclar carnes y espolvorear la taurina, aceite de salmón y cáscara de huevo en tibio.'
    ],
    storageInfo: 'Nevera 48h, congelador 2 meses.',
    macronutrients: { proteinPct: 58, fatPct: 24, fiberCarbPct: 2, moisturePct: 76 }
  },
  {
    id: 'cat-kit-04',
    title: 'Salmón con Pavo para Gatitos',
    frenchTitle: 'Duo Saumon & Dinde Chaton',
    species: 'cat',
    growthStage: 'puppy_kitten',
    category: 'joint_omega3',
    categoryLabel: 'DHA Cerebral & Retiniano Felino',
    description: 'Hornear salmón 12 min y cocer pavo 20 min. Añadir taurina, aceite de linaza y cáscara de huevo.',
    kcalPer100g: 140,
    prepTimeMin: 15,
    cookTimeMin: 20,
    difficulty: 'Fácil',
    suitability: 'Gatitos en pleno desarrollo neurológico y sensorial',
    clinicalBenefits: ['Ácidos grasos EPA/DHA esenciales para agudeza visual y reflejos', 'Pavo digestivo', 'Taurina'],
    ingredients: [
      { name: 'Salmón fresco desespinado', category: 'protein', baseGramsFor10kgPetPerDay: 50, notes: 'Hornear 12 min' },
      { name: 'Pechuga de pavo', category: 'protein', baseGramsFor10kgPetPerDay: 65, notes: 'Cocer 20 min' },
      { name: 'Taurina felina', category: 'supplement_calcium', baseGramsFor10kgPetPerDay: 0.5, notes: 'Al templar' },
      { name: 'Aceite de linaza', category: 'healthy_fat', baseGramsFor10kgPetPerDay: 2, notes: 'En crudo' },
      { name: 'Cáscara de huevo en polvo', category: 'supplement_calcium', baseGramsFor10kgPetPerDay: 2, notes: 'Calcio' }
    ],
    instructions: [
      'Hornear el salmón 12 minutos y revisar con las yemas de los dedos que no tenga espinas.',
      'Hervir el pavo 20 minutos y triturar finamente.',
      'Mezclar ambas proteínas y agregar taurina, aceite de linaza y cáscara de huevo en templado.'
    ],
    storageInfo: 'Nevera 48h, congelador 2 meses.',
    macronutrients: { proteinPct: 53, fatPct: 29, fiberCarbPct: 2, moisturePct: 75 }
  },
  {
    id: 'cat-kit-05',
    title: 'Ternera Magra con Hígado para Gatitos',
    frenchTitle: 'Bœuf Haché Maigre & Foie Chaton',
    species: 'cat',
    growthStage: 'puppy_kitten',
    category: 'vitality_gourmet',
    categoryLabel: 'Hierro Hémico & Resistencia Felina',
    description: 'Cocer ternera 25 min e hígado 7 min. Incorporar taurina, aceite de salmón y cáscara de huevo.',
    kcalPer100g: 135,
    prepTimeMin: 15,
    cookTimeMin: 25,
    difficulty: 'Fácil',
    suitability: 'Gatitos con requerimiento de soporte hematopoyético y masa muscular magra',
    clinicalBenefits: ['Máxima biodisponibilidad de hierro para evitar anemia nutricional', 'Complejo B', 'Taurina'],
    ingredients: [
      { name: 'Ternera magra picada', category: 'protein', baseGramsFor10kgPetPerDay: 90, notes: 'Cocer 25 min' },
      { name: 'Hígado de vacuno o pollo', category: 'organ_meat', baseGramsFor10kgPetPerDay: 15, notes: 'Cocer 7 min' },
      { name: 'Taurina felina', category: 'supplement_calcium', baseGramsFor10kgPetPerDay: 0.5, notes: 'Al templar' },
      { name: 'Aceite de salmón', category: 'healthy_fat', baseGramsFor10kgPetPerDay: 2, notes: 'Omega 3' },
      { name: 'Cáscara de huevo molida', category: 'supplement_calcium', baseGramsFor10kgPetPerDay: 2, notes: 'Calcio' }
    ],
    instructions: [
      'Cocer la ternera 25 minutos y el hígado 7 minutos.',
      'Picar muy menudo o procesar brevemente.',
      'Añadir taurina, aceite de salmón y cáscara de huevo molida cuando esté templado.'
    ],
    storageInfo: 'Nevera 48h, congelador 2 meses.',
    macronutrients: { proteinPct: 56, fatPct: 27, fiberCarbPct: 2, moisturePct: 75 }
  },
  {
    id: 'cat-kit-06',
    title: 'Pollo con Huevo y Calabaza para Gatitos',
    frenchTitle: 'Poulet Mimosa au Potiron Doux Chaton',
    species: 'cat',
    growthStage: 'puppy_kitten',
    category: 'sensitive_digestion',
    categoryLabel: 'Fibra Mínima Emoliente & Digestión Sana',
    description: 'Cocer pollo 20 min, huevo 10 min y calabaza 15 min. Añadir taurina, omega 3 y cáscara de huevo.',
    kcalPer100g: 130,
    prepTimeMin: 15,
    cookTimeMin: 20,
    difficulty: 'Fácil',
    suitability: 'Gatitos con heces irregulares o estreñimiento al pasar del biberón al sólido',
    clinicalBenefits: ['Calabaza en dosis segura (menos de 5%) que protege la mucosa intestinal', 'Aminoácidos del huevo y pollo', 'Taurina'],
    ingredients: [
      { name: 'Pechuga de pollo cocida', category: 'protein', baseGramsFor10kgPetPerDay: 80, notes: 'Cocer 20 min' },
      { name: 'Huevo cocido picado', category: 'protein', baseGramsFor10kgPetPerDay: 20, notes: 'Cocer 10 min' },
      { name: 'Calabaza muy cocida en puré', category: 'vegetable', baseGramsFor10kgPetPerDay: 10, notes: 'Cocer 15 min' },
      { name: 'Taurina felina', category: 'supplement_calcium', baseGramsFor10kgPetPerDay: 0.5, notes: 'Al templar' },
      { name: 'Aceite de salmón (omega 3)', category: 'healthy_fat', baseGramsFor10kgPetPerDay: 2, notes: 'Ácidos EPA/DHA' },
      { name: 'Cáscara de huevo molida', category: 'supplement_calcium', baseGramsFor10kgPetPerDay: 2, notes: 'Calcio' }
    ],
    instructions: [
      'Cocer el pollo 20 minutos, el huevo 10 minutos y la calabaza 15 minutos.',
      'Aplastar la calabaza con el huevo y mezclar con el pollo finamente picado.',
      'Añadir taurina, aceite omega 3 y cáscara de huevo.'
    ],
    storageInfo: 'Nevera 48h, congelador 2 meses.',
    macronutrients: { proteinPct: 53, fatPct: 26, fiberCarbPct: 5, moisturePct: 76 }
  },
  {
    id: 'cat-kit-07',
    title: 'Pato con Corazón de Pavo para Gatitos',
    frenchTitle: 'Canard Savoureux & Cœur de Dinde Chaton',
    species: 'cat',
    growthStage: 'puppy_kitten',
    category: 'vitality_gourmet',
    categoryLabel: 'Aromas Intensos & Taurina Natural',
    description: 'Hornear pato 35 min y cocer corazón 7 min. Terminar con taurina, aceite de salmón y cáscara de huevo.',
    kcalPer100g: 145,
    prepTimeMin: 15,
    cookTimeMin: 35,
    difficulty: 'Fácil',
    suitability: 'Gatitos caprichosos o inapetentes estimulados por el aroma natural de las aves acuáticas',
    clinicalBenefits: ['Palatabilidad irresistible para gatos', 'Ácidos grasos esenciales naturales', 'Taurina'],
    ingredients: [
      { name: 'Carne magra de pato sin piel sobrante', category: 'protein', baseGramsFor10kgPetPerDay: 80, notes: 'Hornear 35 min' },
      { name: 'Corazón de pavo picado', category: 'organ_meat', baseGramsFor10kgPetPerDay: 30, notes: 'Cocer 7 min' },
      { name: 'Taurina felina', category: 'supplement_calcium', baseGramsFor10kgPetPerDay: 0.5, notes: 'Al templar' },
      { name: 'Aceite de salmón', category: 'healthy_fat', baseGramsFor10kgPetPerDay: 2, notes: 'Omega 3' },
      { name: 'Cáscara de huevo molida', category: 'supplement_calcium', baseGramsFor10kgPetPerDay: 2, notes: 'Calcio' }
    ],
    instructions: [
      'Hornear el pato 35 minutos desgrasando.',
      'Cocer el corazón de pavo 7 minutos y picar diminuto.',
      'Unir ambas carnes y añadir la taurina, el aceite de salmón y la cáscara de huevo molida.'
    ],
    storageInfo: 'Nevera 48h, congelador 2 meses.',
    macronutrients: { proteinPct: 54, fatPct: 32, fiberCarbPct: 2, moisturePct: 74 }
  },
  {
    id: 'cat-kit-08',
    title: 'Trucha con Pollo para Gatitos',
    frenchTitle: 'Truite de Ruisseau & Blanc de Poulet Chaton',
    species: 'cat',
    growthStage: 'puppy_kitten',
    category: 'joint_omega3',
    categoryLabel: 'Pescado de Agua Dulce & Piel Sedosa',
    description: 'Trucha 12 min y pollo 20 min. Añadir taurina, aceite de linaza y cáscara de huevo.',
    kcalPer100g: 135,
    prepTimeMin: 15,
    cookTimeMin: 20,
    difficulty: 'Fácil',
    suitability: 'Gatitos con pelaje mate o inicio de muda felina',
    clinicalBenefits: ['Aceites marinos limpios combinados con proteína blanca magra', 'Taurina y calcio perfectamente balanceados'],
    ingredients: [
      { name: 'Trucha limpia desespinada al vapor', category: 'protein', baseGramsFor10kgPetPerDay: 50, notes: 'Cocer 12 min' },
      { name: 'Pechuga de pollo cocida', category: 'protein', baseGramsFor10kgPetPerDay: 65, notes: 'Cocer 20 min' },
      { name: 'Taurina felina', category: 'supplement_calcium', baseGramsFor10kgPetPerDay: 0.5, notes: 'Al templar' },
      { name: 'Aceite de linaza', category: 'healthy_fat', baseGramsFor10kgPetPerDay: 2, notes: 'En crudo' },
      { name: 'Cáscara de huevo molida', category: 'supplement_calcium', baseGramsFor10kgPetPerDay: 2, notes: 'Calcio' }
    ],
    instructions: [
      'Cocinar la trucha 12 minutos y palpar exhaustivamente para retirar cualquier microespina.',
      'Cocer el pollo 20 minutos y triturar finamente.',
      'Mezclar e incorporar taurina, aceite de linaza y cáscara de huevo en templado.'
    ],
    storageInfo: 'Nevera 48 horas.',
    macronutrients: { proteinPct: 55, fatPct: 27, fiberCarbPct: 2, moisturePct: 76 }
  },
  {
    id: 'cat-kit-09',
    title: 'Conejo con Huevo para Gatitos',
    frenchTitle: 'Lapereau & Œuf Tendre Chaton',
    species: 'cat',
    growthStage: 'puppy_kitten',
    category: 'sensitive_digestion',
    categoryLabel: 'Asimilación Máxima & Cero Intolerancias',
    description: 'Cocer conejo 35 min y huevo 10 min. Incorporar taurina, aceite de salmón y cáscara de huevo.',
    kcalPer100g: 135,
    prepTimeMin: 15,
    cookTimeMin: 35,
    difficulty: 'Fácil',
    suitability: 'Gatitos con digestión ultra delicada',
    clinicalBenefits: ['Proteína hipoalergénica más el huevo como estándar de oro aminoacídico', 'Taurina', 'Calcio'],
    ingredients: [
      { name: 'Conejo deshuesado cocido', category: 'protein', baseGramsFor10kgPetPerDay: 90, notes: 'Cocer 35 min' },
      { name: 'Huevo cocido picado', category: 'protein', baseGramsFor10kgPetPerDay: 20, notes: 'Cocer 10 min' },
      { name: 'Taurina felina', category: 'supplement_calcium', baseGramsFor10kgPetPerDay: 0.5, notes: 'Al templar' },
      { name: 'Aceite de salmón', category: 'healthy_fat', baseGramsFor10kgPetPerDay: 2, notes: 'Omega 3' },
      { name: 'Cáscara de huevo molida', category: 'supplement_calcium', baseGramsFor10kgPetPerDay: 2, notes: 'Calcio' }
    ],
    instructions: [
      'Cocer el conejo 35 minutos y desmenuzar con minuciosidad.',
      'Cocer el huevo 10 minutos y picar fino.',
      'Mezclar todo en templado junto a la taurina, el aceite de salmón y la cáscara de huevo molida.'
    ],
    storageInfo: 'Nevera 48h, congelador 2 meses.',
    macronutrients: { proteinPct: 56, fatPct: 26, fiberCarbPct: 2, moisturePct: 75 }
  },
  {
    id: 'cat-kit-10',
    title: 'Pavo con Hígado y Calabacín para Gatitos',
    frenchTitle: 'Dinde au Foie & Courgettes Tendres Chaton',
    species: 'cat',
    growthStage: 'puppy_kitten',
    category: 'vitality_gourmet',
    categoryLabel: 'Hidratación & Soporte Hepático-Ocular',
    description: 'Cocer pavo 20 min, hígado 7 min y calabacín 10 min. Añadir taurina, omega 3 y cáscara de huevo.',
    kcalPer100g: 125,
    prepTimeMin: 15,
    cookTimeMin: 20,
    difficulty: 'Fácil',
    suitability: 'Gatitos con poca inclinación a beber agua que requieren comida con alta humedad natural',
    clinicalBenefits: ['Calabacín hidratante', 'Vitamina A del hígado para desarrollo ocular temprano', 'Taurina'],
    ingredients: [
      { name: 'Pechuga de pavo', category: 'protein', baseGramsFor10kgPetPerDay: 85, notes: 'Cocer 20 min' },
      { name: 'Hígado de pollo', category: 'organ_meat', baseGramsFor10kgPetPerDay: 12, notes: 'Cocer 7 min' },
      { name: 'Calabacín cocido en dados', category: 'vegetable', baseGramsFor10kgPetPerDay: 12, notes: 'Cocer 10 min' },
      { name: 'Taurina felina', category: 'supplement_calcium', baseGramsFor10kgPetPerDay: 0.5, notes: 'Al templar' },
      { name: 'Aceite de salmón (omega 3)', category: 'healthy_fat', baseGramsFor10kgPetPerDay: 2, notes: 'Ácidos EPA/DHA' },
      { name: 'Cáscara de huevo molida', category: 'supplement_calcium', baseGramsFor10kgPetPerDay: 2, notes: 'Calcio' }
    ],
    instructions: [
      'Cocer el pavo 20 minutos con el hígado los últimos 7 minutos.',
      'Cocer el calabacín 10 minutos y machacar con tenedor.',
      'Unir todo picado muy fino e incorporar taurina, omega 3 y cáscara de huevo molida.'
    ],
    storageInfo: 'Nevera 48h, congelador 2 meses.',
    macronutrients: { proteinPct: 54, fatPct: 25, fiberCarbPct: 4, moisturePct: 78 }
  },
  {
    id: 'cat-kit-11',
    title: 'Salmón con Huevo Cocido para Gatitos',
    frenchTitle: 'Saumon & Œuf Émietté Chaton',
    species: 'cat',
    growthStage: 'puppy_kitten',
    category: 'joint_omega3',
    categoryLabel: 'Concentrado Lipídico & Omega 3 de Crecimiento',
    description: 'Hornear salmón 12 min y cocer huevo 10 min. Añadir taurina, aceite de salmón y cáscara de huevo.',
    kcalPer100g: 145,
    prepTimeMin: 15,
    cookTimeMin: 15,
    difficulty: 'Fácil',
    suitability: 'Gatitos que necesitan un empuje calórico saludable y brillo en manto',
    clinicalBenefits: ['Grasas esenciales omega 3 en sinergia con luteína y colina del huevo', 'Taurina suplementada'],
    ingredients: [
      { name: 'Lomo de salmón desespinado', category: 'protein', baseGramsFor10kgPetPerDay: 80, notes: 'Hornear 12 min' },
      { name: 'Huevo cocido picado', category: 'protein', baseGramsFor10kgPetPerDay: 25, notes: 'Cocer 10 min' },
      { name: 'Taurina felina', category: 'supplement_calcium', baseGramsFor10kgPetPerDay: 0.5, notes: 'Al templar' },
      { name: 'Aceite de salmón', category: 'healthy_fat', baseGramsFor10kgPetPerDay: 2, notes: 'Omega 3' },
      { name: 'Cáscara de huevo molida', category: 'supplement_calcium', baseGramsFor10kgPetPerDay: 2, notes: 'Calcio' }
    ],
    instructions: [
      'Hornear el salmón 12 minutos y desmenuzar minuciosamente asegurando cero espinas.',
      'Picar el huevo cocido e integrarlo al salmón.',
      'Añadir taurina, aceite de salmón y cáscara de huevo en templado.'
    ],
    storageInfo: 'Nevera 48 horas.',
    macronutrients: { proteinPct: 51, fatPct: 33, fiberCarbPct: 2, moisturePct: 74 }
  },
  {
    id: 'cat-kit-12',
    title: 'Pollo con Pato para Gatitos',
    frenchTitle: 'Volaille Gourmande Poulet & Canard Chaton',
    species: 'cat',
    growthStage: 'puppy_kitten',
    category: 'vitality_gourmet',
    categoryLabel: 'Doble Ave & Perfil Carnívoro Puro',
    description: 'Cocer pollo 20 min y hornear pato 35 min. Incorporar taurina, aceite de linaza y cáscara de huevo.',
    kcalPer100g: 140,
    prepTimeMin: 15,
    cookTimeMin: 35,
    difficulty: 'Fácil',
    suitability: 'Gatitos con apetito selectivo',
    clinicalBenefits: ['Textura y aroma que estimulan el instinto felino', 'Sin cereales ni azúcares', 'Taurina'],
    ingredients: [
      { name: 'Pechuga de pollo cocida', category: 'protein', baseGramsFor10kgPetPerDay: 60, notes: 'Cocer 20 min' },
      { name: 'Carne magra de pato horneada', category: 'protein', baseGramsFor10kgPetPerDay: 50, notes: 'Hornear 35 min' },
      { name: 'Taurina en polvo', category: 'supplement_calcium', baseGramsFor10kgPetPerDay: 0.5, notes: 'Al templar' },
      { name: 'Aceite de linaza', category: 'healthy_fat', baseGramsFor10kgPetPerDay: 2, notes: 'En crudo' },
      { name: 'Cáscara de huevo molida', category: 'supplement_calcium', baseGramsFor10kgPetPerDay: 2, notes: 'Calcio' }
    ],
    instructions: [
      'Cocer el pollo 20 minutos y hornear el pato 35 minutos.',
      'Desmenuzar ambas carnes en trocitos muy pequeños.',
      'Agregar taurina, aceite de linaza y cáscara de huevo molida al templar.'
    ],
    storageInfo: 'Nevera 48h, congelador 2 meses.',
    macronutrients: { proteinPct: 55, fatPct: 29, fiberCarbPct: 2, moisturePct: 75 }
  },
  {
    id: 'cat-kit-13',
    title: 'Ternera con Corazón de Pollo para Gatitos',
    frenchTitle: 'Bœuf & Cœur de Volaille Chaton',
    species: 'cat',
    growthStage: 'puppy_kitten',
    category: 'vitality_gourmet',
    categoryLabel: 'Fuerza Muscular & Mioglobina Felina',
    description: 'Cocer ternera 25 min y corazón 7 min. Añadir taurina, aceite de salmón y cáscara de huevo.',
    kcalPer100g: 135,
    prepTimeMin: 15,
    cookTimeMin: 25,
    difficulty: 'Fácil',
    suitability: 'Gatitos activos de razas medianas y grandes (Maine Coon, Bosque de Noruega)',
    clinicalBenefits: ['Creatina natural para densidad fibrilar', 'Taurina multiplicada del músculo cardíaco', 'Calcio'],
    ingredients: [
      { name: 'Ternera magra picada', category: 'protein', baseGramsFor10kgPetPerDay: 80, notes: 'Cocer 25 min' },
      { name: 'Corazón de pollo picado', category: 'organ_meat', baseGramsFor10kgPetPerDay: 30, notes: 'Cocer 7 min' },
      { name: 'Taurina felina', category: 'supplement_calcium', baseGramsFor10kgPetPerDay: 0.5, notes: 'Al templar' },
      { name: 'Aceite de salmón', category: 'healthy_fat', baseGramsFor10kgPetPerDay: 2, notes: 'Omega 3' },
      { name: 'Cáscara de huevo en polvo', category: 'supplement_calcium', baseGramsFor10kgPetPerDay: 2, notes: 'Calcio' }
    ],
    instructions: [
      'Cocer la ternera picada 25 minutos y los corazones 7 minutos.',
      'Picar fino y mezclar homogéneamente.',
      'Añadir taurina, aceite de salmón y cáscara de huevo al templar.'
    ],
    storageInfo: 'Nevera 48h, congelador 2 meses.',
    macronutrients: { proteinPct: 57, fatPct: 27, fiberCarbPct: 2, moisturePct: 75 }
  },
  {
    id: 'cat-kit-14',
    title: 'Trucha con Huevo y Zanahoria para Gatitos',
    frenchTitle: 'Truite Dorée à l’Œuf & Carottes Douces Chaton',
    species: 'cat',
    growthStage: 'puppy_kitten',
    category: 'joint_omega3',
    categoryLabel: 'Nutrición Integral Marina y Terrestre',
    description: 'Trucha 12 min, huevo 10 min y zanahoria 15 min. Añadir taurina, omega 3 y cáscara de huevo.',
    kcalPer100g: 130,
    prepTimeMin: 15,
    cookTimeMin: 15,
    difficulty: 'Fácil',
    suitability: 'Gatitos en crecimiento con necesidad de soporte antioxidante y visual',
    clinicalBenefits: ['Vitamina A, luteína y DHA en armonía metabólica felina', 'Taurina añadida', 'Calcio'],
    ingredients: [
      { name: 'Trucha sin espinas al vapor', category: 'protein', baseGramsFor10kgPetPerDay: 75, notes: 'Cocer 12 min' },
      { name: 'Huevo cocido picado', category: 'protein', baseGramsFor10kgPetPerDay: 25, notes: 'Cocer 10 min' },
      { name: 'Zanahoria muy cocida machacada', category: 'vegetable', baseGramsFor10kgPetPerDay: 10, notes: 'Cocer 15 min' },
      { name: 'Taurina felina', category: 'supplement_calcium', baseGramsFor10kgPetPerDay: 0.5, notes: 'Al templar' },
      { name: 'Aceite de salmón', category: 'healthy_fat', baseGramsFor10kgPetPerDay: 2, notes: 'Omega 3' },
      { name: 'Cáscara de huevo molida', category: 'supplement_calcium', baseGramsFor10kgPetPerDay: 2, notes: 'Calcio' }
    ],
    instructions: [
      'Cocinar la trucha 12 minutos desmenuzándola sin espinas.',
      'Cocer el huevo 10 minutos y la zanahoria 15 minutos machacando en puré fino.',
      'Integrar todo con taurina, aceite de salmón y cáscara de huevo al templar.'
    ],
    storageInfo: 'Nevera 48 horas.',
    macronutrients: { proteinPct: 52, fatPct: 29, fiberCarbPct: 4, moisturePct: 76 }
  },
  {
    id: 'cat-kit-15',
    title: 'Conejo con Pavo para Gatitos',
    frenchTitle: 'Lapin & Dinde Douce Chaton',
    species: 'cat',
    growthStage: 'puppy_kitten',
    category: 'sensitive_digestion',
    categoryLabel: 'Digestibilidad Sobresaliente & Mínimo Alérgeno',
    description: 'Cocer conejo 35 min y pavo 20 min. Terminar con taurina, aceite de linaza y cáscara de huevo.',
    kcalPer100g: 130,
    prepTimeMin: 15,
    cookTimeMin: 35,
    difficulty: 'Fácil',
    suitability: 'Gatitos con digestión inestable',
    clinicalBenefits: ['Dos fuentes de carne blanca magra no reactivas', 'Taurina felina esencial', 'Calcio'],
    ingredients: [
      { name: 'Conejo deshuesado cocido', category: 'protein', baseGramsFor10kgPetPerDay: 60, notes: 'Cocer 35 min' },
      { name: 'Pechuga de pavo cocida', category: 'protein', baseGramsFor10kgPetPerDay: 50, notes: 'Cocer 20 min' },
      { name: 'Taurina en polvo', category: 'supplement_calcium', baseGramsFor10kgPetPerDay: 0.5, notes: 'Al templar' },
      { name: 'Aceite de linaza', category: 'healthy_fat', baseGramsFor10kgPetPerDay: 2, notes: 'En crudo' },
      { name: 'Cáscara de huevo molida', category: 'supplement_calcium', baseGramsFor10kgPetPerDay: 2, notes: 'Calcio' }
    ],
    instructions: [
      'Cocer el conejo 35 minutos y retirar meticulosamente los huesos.',
      'Cocer el pavo 20 minutos y trocear muy fino con el conejo.',
      'Incorporar la taurina, el aceite de linaza y la cáscara de huevo molida.'
    ],
    storageInfo: 'Nevera 48h, congelador 2 meses.',
    macronutrients: { proteinPct: 57, fatPct: 24, fiberCarbPct: 2, moisturePct: 76 }
  },
  {
    id: 'cat-kit-16',
    title: 'Pollo con Corazón y Calabaza para Gatitos',
    frenchTitle: 'Poulet Cœurs de Volaille & Potiron Chaton',
    species: 'cat',
    growthStage: 'puppy_kitten',
    category: 'vitality_gourmet',
    categoryLabel: 'Fibra Suave & Confort Intestinal',
    description: 'Cocer pollo 20 min, corazón 7 min y calabaza 15 min. Añadir taurina, aceite de salmón y cáscara de huevo.',
    kcalPer100g: 130,
    prepTimeMin: 15,
    cookTimeMin: 20,
    difficulty: 'Fácil',
    suitability: 'Gatitos con heces duras o tendencia a bolas de pelo tempranas',
    clinicalBenefits: ['Mucílago de calabaza para tránsito intestinal', 'Corazón rico en taurina y carnitina', 'Calcio'],
    ingredients: [
      { name: 'Pechuga de pollo picada', category: 'protein', baseGramsFor10kgPetPerDay: 75, notes: 'Cocer 20 min' },
      { name: 'Corazón de pollo picado', category: 'organ_meat', baseGramsFor10kgPetPerDay: 25, notes: 'Cocer 7 min' },
      { name: 'Calabaza cocida', category: 'vegetable', baseGramsFor10kgPetPerDay: 12, notes: 'Cocer 15 min' },
      { name: 'Taurina felina', category: 'supplement_calcium', baseGramsFor10kgPetPerDay: 0.5, notes: 'Al templar' },
      { name: 'Aceite de salmón', category: 'healthy_fat', baseGramsFor10kgPetPerDay: 2, notes: 'Omega 3' },
      { name: 'Cáscara de huevo molida', category: 'supplement_calcium', baseGramsFor10kgPetPerDay: 2, notes: 'Calcio' }
    ],
    instructions: [
      'Cocer el pollo 20 minutos agregando los corazones los últimos 7 minutos.',
      'Cocer la calabaza 15 minutos y aplastar en puré fino.',
      'Unir todo picado muy menudo y espolvorear taurina, aceite de salmón y calcio al templar.'
    ],
    storageInfo: 'Nevera 48h, congelador 2 meses.',
    macronutrients: { proteinPct: 55, fatPct: 26, fiberCarbPct: 4, moisturePct: 76 }
  },
  {
    id: 'cat-kit-17',
    title: 'Pavo con Huevo y Calabacín para Gatitos',
    frenchTitle: 'Dinde Mimosa aux Courgettes Chaton',
    species: 'cat',
    growthStage: 'puppy_kitten',
    category: 'sensitive_digestion',
    categoryLabel: 'Digestión Fácil & Balance Hidroelectrolítico',
    description: 'Cocer pavo 20 min, huevo 10 min y calabacín 10 min. Incorporar taurina, aceite de linaza y cáscara de huevo.',
    kcalPer100g: 130,
    prepTimeMin: 15,
    cookTimeMin: 20,
    difficulty: 'Fácil',
    suitability: 'Gatitos con digestión pesada tras comidas grasas',
    clinicalBenefits: ['Baja carga lipídica para no sobrecargar el hígado en desarrollo', 'Taurina y calcio puros'],
    ingredients: [
      { name: 'Pechuga de pavo', category: 'protein', baseGramsFor10kgPetPerDay: 80, notes: 'Cocer 20 min' },
      { name: 'Huevo cocido picado', category: 'protein', baseGramsFor10kgPetPerDay: 20, notes: 'Cocer 10 min' },
      { name: 'Calabacín cocido suave', category: 'vegetable', baseGramsFor10kgPetPerDay: 12, notes: 'Cocer 10 min' },
      { name: 'Taurina felina', category: 'supplement_calcium', baseGramsFor10kgPetPerDay: 0.5, notes: 'Al templar' },
      { name: 'Aceite de linaza', category: 'healthy_fat', baseGramsFor10kgPetPerDay: 2, notes: 'En crudo' },
      { name: 'Cáscara de huevo molida', category: 'supplement_calcium', baseGramsFor10kgPetPerDay: 2, notes: 'Calcio' }
    ],
    instructions: [
      'Cocer el pavo 20 minutos, el huevo 10 minutos y el calabacín 10 minutos.',
      'Picar el pavo y el huevo e incorporar el calabacín chafado.',
      'Añadir taurina, aceite de linaza y cáscara de huevo en templado.'
    ],
    storageInfo: 'Nevera 48h, congelador 2 meses.',
    macronutrients: { proteinPct: 54, fatPct: 26, fiberCarbPct: 4, moisturePct: 77 }
  },
  {
    id: 'cat-kit-18',
    title: 'Ternera con Hígado y Zanahoria para Gatitos',
    frenchTitle: 'Bœuf aux Éclats de Foie & Carottes Chaton',
    species: 'cat',
    growthStage: 'puppy_kitten',
    category: 'vitality_gourmet',
    categoryLabel: 'Minerales Vitales & Salud Hematológica',
    description: 'Cocer ternera 25 min, hígado 7 min y zanahoria 15 min. Añadir taurina, omega 3 y cáscara de huevo.',
    kcalPer100g: 135,
    prepTimeMin: 15,
    cookTimeMin: 25,
    difficulty: 'Fácil',
    suitability: 'Gatitos vigorosos que necesitan un menú sabroso y enriquecido en hierro',
    clinicalBenefits: ['Zinc y selenio bioactivos', 'Taurina agregada para asegurar 100% de los requerimientos AAFCO/FEDIAF', 'Calcio'],
    ingredients: [
      { name: 'Carne magra de ternera', category: 'protein', baseGramsFor10kgPetPerDay: 80, notes: 'Cocer 25 min' },
      { name: 'Hígado de pollo o ternera', category: 'organ_meat', baseGramsFor10kgPetPerDay: 12, notes: 'Cocer 7 min' },
      { name: 'Zanahoria cocida', category: 'vegetable', baseGramsFor10kgPetPerDay: 10, notes: 'Cocer 15 min' },
      { name: 'Taurina felina', category: 'supplement_calcium', baseGramsFor10kgPetPerDay: 0.5, notes: 'Al templar' },
      { name: 'Aceite de salmón', category: 'healthy_fat', baseGramsFor10kgPetPerDay: 2, notes: 'Omega 3' },
      { name: 'Cáscara de huevo en polvo', category: 'supplement_calcium', baseGramsFor10kgPetPerDay: 2, notes: 'Calcio' }
    ],
    instructions: [
      'Cocer la ternera 25 minutos con el hígado los últimos 7 minutos.',
      'Cocer la zanahoria 15 minutos y aplastar en puré fino.',
      'Picar las carnes, integrar con el puré y mezclar con taurina, aceite de salmón y calcio al templar.'
    ],
    storageInfo: 'Nevera 48h, congelador 2 meses.',
    macronutrients: { proteinPct: 56, fatPct: 27, fiberCarbPct: 3, moisturePct: 75 }
  },
  {
    id: 'cat-kit-19',
    title: 'Salmón con Pollo y Calabaza para Gatitos',
    frenchTitle: 'Saumon & Poulet au Velouté de Potiron Chaton',
    species: 'cat',
    growthStage: 'puppy_kitten',
    category: 'joint_omega3',
    categoryLabel: 'Doble Proteína Noble & Protección de Piel',
    description: 'Hornear salmón 12 min, pollo 20 min y calabaza 15 min. Añadir taurina, aceite de salmón y cáscara de huevo.',
    kcalPer100g: 135,
    prepTimeMin: 15,
    cookTimeMin: 20,
    difficulty: 'Fácil',
    suitability: 'Gatitos con requerimiento de ácidos grasos para manto esponjoso y denso',
    clinicalBenefits: ['Ácidos grasos antiinflamatorios', 'Fibra dietética ultra controlada', 'Taurina'],
    ingredients: [
      { name: 'Lomo de salmón horneado sin espinas', category: 'protein', baseGramsFor10kgPetPerDay: 50, notes: 'Hornear 12 min' },
      { name: 'Pechuga de pollo cocida', category: 'protein', baseGramsFor10kgPetPerDay: 55, notes: 'Cocer 20 min' },
      { name: 'Calabaza cocida', category: 'vegetable', baseGramsFor10kgPetPerDay: 10, notes: 'Cocer 15 min' },
      { name: 'Taurina felina', category: 'supplement_calcium', baseGramsFor10kgPetPerDay: 0.5, notes: 'Al templar' },
      { name: 'Aceite de salmón', category: 'healthy_fat', baseGramsFor10kgPetPerDay: 2, notes: 'Omega 3' },
      { name: 'Cáscara de huevo molida', category: 'supplement_calcium', baseGramsFor10kgPetPerDay: 2, notes: 'Calcio' }
    ],
    instructions: [
      'Hornear el salmón 12 minutos y cocer el pollo 20 minutos.',
      'Cocer la calabaza 15 minutos y aplastar fino.',
      'Unir todo picado minuciosamente con la taurina, aceite de salmón y cáscara de huevo.'
    ],
    storageInfo: 'Nevera 48 horas.',
    macronutrients: { proteinPct: 54, fatPct: 29, fiberCarbPct: 3, moisturePct: 75 }
  },
  {
    id: 'cat-kit-20',
    title: 'Conejo con Corazón y Calabacín para Gatitos',
    frenchTitle: 'Lapin & Cœurs Tendres aux Courgettes Chaton',
    species: 'cat',
    growthStage: 'puppy_kitten',
    category: 'sensitive_digestion',
    categoryLabel: 'Perfil Suave & Cuidado de Tránsito Urinario',
    description: 'Cocer conejo 35 min, corazón 7 min y calabacín 10 min. Añadir taurina, aceite de linaza y cáscara de huevo.',
    kcalPer100g: 130,
    prepTimeMin: 15,
    cookTimeMin: 35,
    difficulty: 'Fácil',
    suitability: 'Gatitos con predisposición a estrés urinario o digestiones difíciles',
    clinicalBenefits: ['Hidratación vegetal y proteína de máxima digestibilidad', 'Taurina cardioprotectora', 'Calcio'],
    ingredients: [
      { name: 'Carne de conejo deshuesada', category: 'protein', baseGramsFor10kgPetPerDay: 80, notes: 'Cocer 35 min' },
      { name: 'Corazón de pollo picado', category: 'organ_meat', baseGramsFor10kgPetPerDay: 25, notes: 'Cocer 7 min' },
      { name: 'Calabacín cocido', category: 'vegetable', baseGramsFor10kgPetPerDay: 12, notes: 'Cocer 10 min' },
      { name: 'Taurina felina', category: 'supplement_calcium', baseGramsFor10kgPetPerDay: 0.5, notes: 'Al templar' },
      { name: 'Aceite de linaza', category: 'healthy_fat', baseGramsFor10kgPetPerDay: 2, notes: 'En crudo' },
      { name: 'Cáscara de huevo molida', category: 'supplement_calcium', baseGramsFor10kgPetPerDay: 2, notes: 'Calcio' }
    ],
    instructions: [
      'Cocer el conejo 35 minutos y desmigar cuidando que no haya huesos.',
      'Cocer el corazón 7 minutos y el calabacín 10 minutos.',
      'Integrar todo picado fino con la taurina, el aceite de linaza y la cáscara de huevo en polvo.'
    ],
    storageInfo: 'Nevera 48h, congelador 2 meses.',
    macronutrients: { proteinPct: 56, fatPct: 25, fiberCarbPct: 3, moisturePct: 76 }
  },
  {
    id: 'cat-kit-21',
    title: 'Codorniz con Huevo para Gatitos ⭐',
    frenchTitle: 'Caille Fondante & Jaune d’Œuf Chaton Gourmet',
    species: 'cat',
    growthStage: 'puppy_kitten',
    category: 'vitality_gourmet',
    categoryLabel: 'Receta Premium Caza Menor & Aminoácidos Esenciales',
    description: 'Premium. Hornear codorniz 25 min y cocer huevo 10 min. Añadir taurina, aceite de salmón y cáscara de huevo.',
    kcalPer100g: 145,
    prepTimeMin: 15,
    cookTimeMin: 25,
    difficulty: 'Media',
    suitability: 'Gatitos con apetito exigente o razas puras en preparación para exposición',
    clinicalBenefits: ['Densidad de micronutrientes de carne de caza', 'Digestibilidad cercana al 95%', 'Taurina'],
    ingredients: [
      { name: 'Carne de codorniz sin huesos', category: 'protein', baseGramsFor10kgPetPerDay: 85, notes: 'Hornear 25 min' },
      { name: 'Huevo cocido picado', category: 'protein', baseGramsFor10kgPetPerDay: 25, notes: 'Cocer 10 min' },
      { name: 'Taurina felina', category: 'supplement_calcium', baseGramsFor10kgPetPerDay: 0.5, notes: 'Al templar' },
      { name: 'Aceite de salmón', category: 'healthy_fat', baseGramsFor10kgPetPerDay: 2, notes: 'Omega 3' },
      { name: 'Cáscara de huevo en polvo', category: 'supplement_calcium', baseGramsFor10kgPetPerDay: 2, notes: 'Calcio' }
    ],
    instructions: [
      'Hornear la codorniz 25 minutos y desmigar meticulosamente descartando todos los huesos diminutos.',
      'Cocer el huevo 10 minutos y picar fino.',
      'Mezclar en templado junto a la taurina, el aceite de salmón y la cáscara de huevo molida.'
    ],
    storageInfo: 'Nevera 48h, congelador 2 meses.',
    macronutrients: { proteinPct: 56, fatPct: 30, fiberCarbPct: 2, moisturePct: 74 }
  },
  {
    id: 'cat-kit-22',
    title: 'Faisán con Corazón de Pollo para Gatitos ⭐',
    frenchTitle: 'Faisan Sauvage & Cœur de Volaille Chaton',
    species: 'cat',
    growthStage: 'puppy_kitten',
    category: 'vitality_gourmet',
    categoryLabel: 'Receta Premium Nobleza Caza & Fuerza Muscular',
    description: 'Premium. Hornear faisán 35 min y cocer corazón 7 min. Incorporar taurina, aceite de linaza y cáscara de huevo.',
    kcalPer100g: 140,
    prepTimeMin: 15,
    cookTimeMin: 35,
    difficulty: 'Media',
    suitability: 'Gatitos que demandan sabores silvestres y desarrollo muscular acelerado',
    clinicalBenefits: ['Proteína libre de hormonas y fármacos de cría industrial', 'Aporte de taurina óptimo', 'Calcio'],
    ingredients: [
      { name: 'Carne de faisán deshuesada', category: 'protein', baseGramsFor10kgPetPerDay: 80, notes: 'Hornear 35 min' },
      { name: 'Corazón de pollo picado', category: 'organ_meat', baseGramsFor10kgPetPerDay: 30, notes: 'Cocer 7 min' },
      { name: 'Taurina felina', category: 'supplement_calcium', baseGramsFor10kgPetPerDay: 0.5, notes: 'Al templar' },
      { name: 'Aceite de linaza', category: 'healthy_fat', baseGramsFor10kgPetPerDay: 2, notes: 'En crudo' },
      { name: 'Cáscara de huevo molida', category: 'supplement_calcium', baseGramsFor10kgPetPerDay: 2, notes: 'Calcio' }
    ],
    instructions: [
      'Hornear el faisán 35 minutos y desmenuzar minuciosamente eliminando cualquier astilla ósea.',
      'Cocer el corazón de pollo 7 minutos y cortar diminuto.',
      'Mezclar e integrar la taurina, el aceite de linaza y la cáscara de huevo molida.'
    ],
    storageInfo: 'Nevera 48h, congelador 2 meses.',
    macronutrients: { proteinPct: 58, fatPct: 27, fiberCarbPct: 2, moisturePct: 75 }
  },
  {
    id: 'cat-kit-23',
    title: 'Caballa con Pavo para Gatitos ⭐',
    frenchTitle: 'Maquereau de Ligne & Dinde Moelleuse Chaton',
    species: 'cat',
    growthStage: 'puppy_kitten',
    category: 'joint_omega3',
    categoryLabel: 'Receta Premium Omega 3 Puro & Digestión Suave',
    description: 'Premium. Hornear caballa 15 min y cocer pavo 20 min. Añadir taurina, aceite de salmón y cáscara de huevo.',
    kcalPer100g: 145,
    prepTimeMin: 15,
    cookTimeMin: 20,
    difficulty: 'Fácil',
    suitability: 'Gatitos con pelaje áspero o piel reseca',
    clinicalBenefits: ['Pescado azul pequeño con alta concentración de EPA/DHA marino', 'Pavo suave', 'Taurina'],
    ingredients: [
      { name: 'Caballa fresca horneada desespinada', category: 'protein', baseGramsFor10kgPetPerDay: 50, notes: 'Hornear 15 min' },
      { name: 'Pechuga de pavo cocida', category: 'protein', baseGramsFor10kgPetPerDay: 60, notes: 'Cocer 20 min' },
      { name: 'Taurina felina', category: 'supplement_calcium', baseGramsFor10kgPetPerDay: 0.5, notes: 'Al templar' },
      { name: 'Aceite de salmón', category: 'healthy_fat', baseGramsFor10kgPetPerDay: 2, notes: 'Omega 3' },
      { name: 'Cáscara de huevo molida', category: 'supplement_calcium', baseGramsFor10kgPetPerDay: 2, notes: 'Calcio' }
    ],
    instructions: [
      'Hornear la caballa 15 minutos y desmigar con tenedor revisando minuciosamente espinas.',
      'Cocer el pavo 20 minutos y triturar finamente.',
      'Unir ambas carnes y agregar taurina, aceite de salmón y cáscara de huevo molida.'
    ],
    storageInfo: 'Nevera 48 horas.',
    macronutrients: { proteinPct: 53, fatPct: 32, fiberCarbPct: 2, moisturePct: 74 }
  },
  {
    id: 'cat-kit-24',
    title: 'Conejo con Codorniz para Gatitos ⭐',
    frenchTitle: 'Lapereau & Caille des Champs Chaton',
    species: 'cat',
    growthStage: 'puppy_kitten',
    category: 'sensitive_digestion',
    categoryLabel: 'Receta Premium Digestibilidad Hipoalergénica',
    description: 'Premium. Cocer conejo 35 min y hornear codorniz 25 min. Añadir taurina, aceite de linaza y cáscara de huevo.',
    kcalPer100g: 135,
    prepTimeMin: 15,
    cookTimeMin: 35,
    difficulty: 'Media',
    suitability: 'Gatitos con hipersensibilidad digestiva',
    clinicalBenefits: ['Proteínas biológicamente apropiadas sin componentes de ganadería intensiva', 'Taurina', 'Calcio'],
    ingredients: [
      { name: 'Carne de conejo deshuesada', category: 'protein', baseGramsFor10kgPetPerDay: 60, notes: 'Cocer 35 min' },
      { name: 'Carne de codorniz sin huesos', category: 'protein', baseGramsFor10kgPetPerDay: 50, notes: 'Hornear 25 min' },
      { name: 'Taurina felina', category: 'supplement_calcium', baseGramsFor10kgPetPerDay: 0.5, notes: 'Al templar' },
      { name: 'Aceite de linaza', category: 'healthy_fat', baseGramsFor10kgPetPerDay: 2, notes: 'En crudo' },
      { name: 'Cáscara de huevo en polvo', category: 'supplement_calcium', baseGramsFor10kgPetPerDay: 2, notes: 'Calcio' }
    ],
    instructions: [
      'Cocer el conejo 35 minutos y hornear la codorniz 25 minutos desmigando ambos sin huesos.',
      'Picar en picada muy fina apta para gatitos.',
      'Añadir taurina, aceite de linaza y cáscara de huevo molida al templar.'
    ],
    storageInfo: 'Nevera 48h, congelador 2 meses.',
    macronutrients: { proteinPct: 57, fatPct: 27, fiberCarbPct: 2, moisturePct: 75 }
  },
  {
    id: 'cat-kit-25',
    title: 'Pato con Faisán para Gatitos ⭐',
    frenchTitle: 'Duo Royal Canard & Faisan Chaton',
    species: 'cat',
    growthStage: 'puppy_kitten',
    category: 'vitality_gourmet',
    categoryLabel: 'Receta Premium Sabor Silvestre Intenso',
    description: 'Premium. Hornear pato 35 min y faisán 35 min. Terminar con taurina, aceite de salmón y cáscara de huevo.',
    kcalPer100g: 145,
    prepTimeMin: 15,
    cookTimeMin: 35,
    difficulty: 'Media',
    suitability: 'Gatitos que se muestran inapetentes ante recetas convencionales',
    clinicalBenefits: ['Estimulación del apetito mediante perfiles de grasa y proteína salvaje', 'Taurina', 'Calcio'],
    ingredients: [
      { name: 'Carne magra de pato horneada', category: 'protein', baseGramsFor10kgPetPerDay: 55, notes: 'Hornear 35 min' },
      { name: 'Carne de faisán deshuesada', category: 'protein', baseGramsFor10kgPetPerDay: 55, notes: 'Hornear 35 min' },
      { name: 'Taurina felina', category: 'supplement_calcium', baseGramsFor10kgPetPerDay: 0.5, notes: 'Al templar' },
      { name: 'Aceite de salmón', category: 'healthy_fat', baseGramsFor10kgPetPerDay: 2, notes: 'Omega 3' },
      { name: 'Cáscara de huevo molida', category: 'supplement_calcium', baseGramsFor10kgPetPerDay: 2, notes: 'Calcio' }
    ],
    instructions: [
      'Hornear ambas aves 35 minutos y desmigar con precisión absoluta descartando huesos.',
      'Picar fino y mezclar homogéneamente.',
      'Añadir taurina, aceite de salmón y cáscara de huevo al templar.'
    ],
    storageInfo: 'Nevera 48h, congelador 2 meses.',
    macronutrients: { proteinPct: 56, fatPct: 31, fiberCarbPct: 2, moisturePct: 74 }
  },
  {
    id: 'cat-kit-26',
    title: 'Trucha con Corazón de Pavo para Gatitos ⭐',
    frenchTitle: 'Truite de Source & Cœur de Dinde Chaton',
    species: 'cat',
    growthStage: 'puppy_kitten',
    category: 'joint_omega3',
    categoryLabel: 'Receta Premium Taurina & DHA Máximos',
    description: 'Premium. Trucha 12 min y corazón 7 min. Añadir taurina, omega 3 y cáscara de huevo.',
    kcalPer100g: 135,
    prepTimeMin: 15,
    cookTimeMin: 15,
    difficulty: 'Fácil',
    suitability: 'Gatitos con necesidad de estimulación metabólica y visual',
    clinicalBenefits: ['Taurina natural del corazón de pavo potenciada con ácidos grasos trucha', 'Calcio'],
    ingredients: [
      { name: 'Trucha fresca desespinada al vapor', category: 'protein', baseGramsFor10kgPetPerDay: 75, notes: 'Cocer 12 min' },
      { name: 'Corazón de pavo picado', category: 'organ_meat', baseGramsFor10kgPetPerDay: 35, notes: 'Cocer 7 min' },
      { name: 'Taurina felina', category: 'supplement_calcium', baseGramsFor10kgPetPerDay: 0.5, notes: 'Al templar' },
      { name: 'Aceite de salmón (omega 3)', category: 'healthy_fat', baseGramsFor10kgPetPerDay: 2, notes: 'Ácidos EPA/DHA' },
      { name: 'Cáscara de huevo molida', category: 'supplement_calcium', baseGramsFor10kgPetPerDay: 2, notes: 'Calcio' }
    ],
    instructions: [
      'Cocinar la trucha al vapor 12 minutos y asegurar ausencia total de espinas.',
      'Cocer el corazón 7 minutos y cortar en daditos mínimos.',
      'Mezclar e incorporar taurina, omega 3 y cáscara de huevo en templado.'
    ],
    storageInfo: 'Nevera 48 horas.',
    macronutrients: { proteinPct: 56, fatPct: 27, fiberCarbPct: 2, moisturePct: 76 }
  },
  {
    id: 'cat-kit-27',
    title: 'Salmón con Codorniz para Gatitos ⭐',
    frenchTitle: 'Saumon Sauvage & Caille Dorée Chaton',
    species: 'cat',
    growthStage: 'puppy_kitten',
    category: 'vitality_gourmet',
    categoryLabel: 'Receta Premium Mar y Campo Gourmet',
    description: 'Premium. Hornear salmón 12 min y codorniz 25 min. Incorporar taurina, aceite de linaza y cáscara de huevo.',
    kcalPer100g: 145,
    prepTimeMin: 15,
    cookTimeMin: 25,
    difficulty: 'Media',
    suitability: 'Gatitos que disfrutan de combinaciones de textura blanda y sabor pronunciado',
    clinicalBenefits: ['Nutrición lipídica balanceada para desarrollo cerebral temprano', 'Taurina', 'Calcio'],
    ingredients: [
      { name: 'Lomo de salmón horneado sin espinas', category: 'protein', baseGramsFor10kgPetPerDay: 55, notes: 'Hornear 12 min' },
      { name: 'Carne de codorniz sin huesos', category: 'protein', baseGramsFor10kgPetPerDay: 55, notes: 'Hornear 25 min' },
      { name: 'Taurina felina', category: 'supplement_calcium', baseGramsFor10kgPetPerDay: 0.5, notes: 'Al templar' },
      { name: 'Aceite de linaza', category: 'healthy_fat', baseGramsFor10kgPetPerDay: 2, notes: 'En crudo' },
      { name: 'Cáscara de huevo en polvo', category: 'supplement_calcium', baseGramsFor10kgPetPerDay: 2, notes: 'Calcio' }
    ],
    instructions: [
      'Hornear el salmón 12 minutos y la codorniz 25 minutos desmigando ambos sin espinas ni huesos.',
      'Picar en migas aptas para gatitos.',
      'Agregar taurina, aceite de linaza y cáscara de huevo molida al templar.'
    ],
    storageInfo: 'Nevera 48 horas.',
    macronutrients: { proteinPct: 53, fatPct: 32, fiberCarbPct: 2, moisturePct: 74 }
  },
  {
    id: 'cat-kit-28',
    title: 'Pavo con Hígado de Conejo para Gatitos ⭐',
    frenchTitle: 'Dinde Délicate & Foie de Lapin Chaton',
    species: 'cat',
    growthStage: 'puppy_kitten',
    category: 'vitality_gourmet',
    categoryLabel: 'Receta Premium Hígado Exclusivo & Digestión Perfecta',
    description: 'Premium. Cocer pavo 20 min e hígado 7 min. Añadir taurina, aceite de salmón y cáscara de huevo.',
    kcalPer100g: 130,
    prepTimeMin: 15,
    cookTimeMin: 20,
    difficulty: 'Fácil',
    suitability: 'Gatitos con estómago sensible que no toleran hígado de res o pollo',
    clinicalBenefits: ['Hígado de conejo sumamente digestivo y rico en vitamina A natural', 'Taurina', 'Calcio'],
    ingredients: [
      { name: 'Pechuga de pavo picada', category: 'protein', baseGramsFor10kgPetPerDay: 95, notes: 'Cocer 20 min' },
      { name: 'Hígado de conejo cocido', category: 'organ_meat', baseGramsFor10kgPetPerDay: 15, notes: 'Cocer 7 min' },
      { name: 'Taurina felina', category: 'supplement_calcium', baseGramsFor10kgPetPerDay: 0.5, notes: 'Al templar' },
      { name: 'Aceite de salmón', category: 'healthy_fat', baseGramsFor10kgPetPerDay: 2, notes: 'Omega 3' },
      { name: 'Cáscara de huevo molida', category: 'supplement_calcium', baseGramsFor10kgPetPerDay: 2, notes: 'Calcio' }
    ],
    instructions: [
      'Cocer el pavo 20 minutos y el hígado de conejo 7 minutos.',
      'Triturar fino el hígado y deshebrar el pavo.',
      'Mezclar con la taurina, el aceite de salmón y la cáscara de huevo molida en tibio.'
    ],
    storageInfo: 'Nevera 48h, congelador 2 meses.',
    macronutrients: { proteinPct: 56, fatPct: 26, fiberCarbPct: 2, moisturePct: 76 }
  },
  {
    id: 'cat-kit-29',
    title: 'Ternera con Faisán para Gatitos ⭐',
    frenchTitle: 'Bœuf Tendre & Faisan Sauvage Chaton',
    species: 'cat',
    growthStage: 'puppy_kitten',
    category: 'vitality_gourmet',
    categoryLabel: 'Receta Premium Máxima Densidad de Proteína',
    description: 'Premium. Cocer ternera 25 min y hornear faisán 35 min. Terminar con taurina, omega 3 y cáscara de huevo.',
    kcalPer100g: 140,
    prepTimeMin: 15,
    cookTimeMin: 35,
    difficulty: 'Media',
    suitability: 'Gatitos con alto gasto energético y juegos vigorosos',
    clinicalBenefits: ['Perfil de aminoácidos completo que apoya el crecimiento esquelético y muscular', 'Taurina', 'Calcio'],
    ingredients: [
      { name: 'Ternera magra picada', category: 'protein', baseGramsFor10kgPetPerDay: 60, notes: 'Cocer 25 min' },
      { name: 'Carne de faisán deshuesada', category: 'protein', baseGramsFor10kgPetPerDay: 50, notes: 'Hornear 35 min' },
      { name: 'Taurina felina', category: 'supplement_calcium', baseGramsFor10kgPetPerDay: 0.5, notes: 'Al templar' },
      { name: 'Aceite de salmón (omega 3)', category: 'healthy_fat', baseGramsFor10kgPetPerDay: 2, notes: 'Ácidos EPA/DHA' },
      { name: 'Cáscara de huevo molida', category: 'supplement_calcium', baseGramsFor10kgPetPerDay: 2, notes: 'Calcio' }
    ],
    instructions: [
      'Cocer la ternera picada 25 minutos y hornear el faisán 35 minutos retirando huesos.',
      'Picar muy menudo e integrar.',
      'Añadir taurina, omega 3 y cáscara de huevo en templado.'
    ],
    storageInfo: 'Nevera 48h, congelador 2 meses.',
    macronutrients: { proteinPct: 57, fatPct: 28, fiberCarbPct: 2, moisturePct: 75 }
  },
  {
    id: 'cat-kit-30',
    title: 'Pollo con Caballa para Gatitos ⭐',
    frenchTitle: 'Poulet Tendre & Maquereau Bleu Chaton',
    species: 'cat',
    growthStage: 'puppy_kitten',
    category: 'vitality_gourmet',
    categoryLabel: 'Receta Premium Equilibrio Aves & Pescado Azul',
    description: 'Premium. Cocer pollo 20 min y hornear caballa 15 min. Añadir taurina, aceite de linaza y cáscara de huevo.',
    kcalPer100g: 140,
    prepTimeMin: 15,
    cookTimeMin: 20,
    difficulty: 'Fácil',
    suitability: 'Gatitos con requerimiento de sabor irresistible y alta energía',
    clinicalBenefits: ['Grasas poliinsaturadas protectoras del sistema cardiovascular felino', 'Taurina', 'Calcio'],
    ingredients: [
      { name: 'Pechuga de pollo cocida', category: 'protein', baseGramsFor10kgPetPerDay: 65, notes: 'Cocer 20 min' },
      { name: 'Caballa horneada sin espinas', category: 'protein', baseGramsFor10kgPetPerDay: 45, notes: 'Hornear 15 min' },
      { name: 'Taurina felina', category: 'supplement_calcium', baseGramsFor10kgPetPerDay: 0.5, notes: 'Al templar' },
      { name: 'Aceite de linaza', category: 'healthy_fat', baseGramsFor10kgPetPerDay: 2, notes: 'En crudo' },
      { name: 'Cáscara de huevo molida', category: 'supplement_calcium', baseGramsFor10kgPetPerDay: 2, notes: 'Calcio' }
    ],
    instructions: [
      'Cocer el pollo 20 minutos y hornear la caballa 15 minutos desmigando sin espinas.',
      'Mezclar en picadillo muy fino para gatito.',
      'Incorporar la taurina, el aceite de linaza y la cáscara de huevo en templado.'
    ],
    storageInfo: 'Nevera 48 horas.',
    macronutrients: { proteinPct: 54, fatPct: 30, fiberCarbPct: 2, moisturePct: 75 }
  }
];
