import { Recipe } from '../types';

export const CAT_ADULT_RECIPES: Recipe[] = [
  {
    id: 'cat-adu-01',
    title: 'Pavo con Calabacín para Gatos Adultos',
    frenchTitle: 'Dinde Fondante aux Courgettes Chat Adulte',
    species: 'cat',
    growthStage: 'adult',
    category: 'sensitive_digestion',
    categoryLabel: 'Hidratación Renal & Proteína Blanca Pura',
    description: 'Cocer pavo 20 min y calabacín 10 min. Incorporar taurina, aceite de salmón y cáscara de huevo.',
    kcalPer100g: 125,
    prepTimeMin: 15,
    cookTimeMin: 20,
    difficulty: 'Fácil',
    suitability: 'Gatos adultos (1-7 años) que necesitan hidratación para prevenir cálculos y mantener peso óptimo',
    clinicalBenefits: ['Proteína magra para masa muscular sin exceso calórico', 'Calabacín para dilución urinaria', 'Taurina'],
    ingredients: [
      { name: 'Pechuga de pavo cocida', category: 'protein', baseGramsFor10kgPetPerDay: 100, notes: 'Cocer 20 min' },
      { name: 'Calabacín cocido en puré', category: 'vegetable', baseGramsFor10kgPetPerDay: 15, notes: 'Cocer 10 min' },
      { name: 'Taurina felina', category: 'supplement_calcium', baseGramsFor10kgPetPerDay: 0.5, notes: 'Al templar' },
      { name: 'Aceite de salmón', category: 'healthy_fat', baseGramsFor10kgPetPerDay: 2, notes: 'Omega 3' },
      { name: 'Cáscara de huevo molida', category: 'supplement_calcium', baseGramsFor10kgPetPerDay: 2, notes: 'Calcio' }
    ],
    instructions: [
      'Cocer el pavo 20 minutos y deshebrar finamente.',
      'Cocer el calabacín 10 minutos y machacar con tenedor conservando su caldo.',
      'Mezclar en templado e incorporar la taurina, el aceite de salmón y la cáscara de huevo molida.'
    ],
    storageInfo: 'Nevera 48h, congelador 2 meses.',
    macronutrients: { proteinPct: 56, fatPct: 24, fiberCarbPct: 3, moisturePct: 78 }
  },
  {
    id: 'cat-adu-02',
    title: 'Pollo con Calabaza para Gatos Adultos',
    frenchTitle: 'Poulet Tendre au Velouté de Potiron Chat Adulte',
    species: 'cat',
    growthStage: 'adult',
    category: 'sensitive_digestion',
    categoryLabel: 'Prevención de Bolas de Pelo & Digestión Fácil',
    description: 'Cocer pollo 20 min y calabaza 15 min. Añadir taurina, aceite de linaza y cáscara de huevo.',
    kcalPer100g: 125,
    prepTimeMin: 15,
    cookTimeMin: 20,
    difficulty: 'Fácil',
    suitability: 'Gatos de pelo medio y largo propensos a regurgitar tricobezoares',
    clinicalBenefits: ['Fibra soluble mucilaginosa que arrastra los pelos en el tránsito intestinal', 'Taurina para miocardio', 'Calcio'],
    ingredients: [
      { name: 'Pechuga o contramuslo de pollo deshuesado', category: 'protein', baseGramsFor10kgPetPerDay: 100, notes: 'Cocer 20 min' },
      { name: 'Calabaza cocida', category: 'vegetable', baseGramsFor10kgPetPerDay: 15, notes: 'Cocer 15 min' },
      { name: 'Taurina felina', category: 'supplement_calcium', baseGramsFor10kgPetPerDay: 0.5, notes: 'Al templar' },
      { name: 'Aceite de linaza', category: 'healthy_fat', baseGramsFor10kgPetPerDay: 2, notes: 'En crudo' },
      { name: 'Cáscara de huevo molida', category: 'supplement_calcium', baseGramsFor10kgPetPerDay: 2, notes: 'Calcio' }
    ],
    instructions: [
      'Cocer el pollo 20 minutos y picar en pequeños dados.',
      'Cocer la calabaza 15 minutos y aplastar en puré fino.',
      'Unir ambos ingredientes y añadir taurina, aceite de linaza y calcio en tibio.'
    ],
    storageInfo: 'Nevera 48h, congelador 2 meses.',
    macronutrients: { proteinPct: 55, fatPct: 25, fiberCarbPct: 4, moisturePct: 77 }
  },
  {
    id: 'cat-adu-03',
    title: 'Conejo con Judías Verdes para Gatos Adultos',
    frenchTitle: 'Lapin Braisé aux Haricots Verts Chat Adulte',
    species: 'cat',
    growthStage: 'adult',
    category: 'sensitive_digestion',
    categoryLabel: 'Línea Esbelta & Control de Peso Felino',
    description: 'Cocer conejo 35 min y judías verdes 12 min. Incorporar taurina, aceite de salmón y cáscara de huevo.',
    kcalPer100g: 120,
    prepTimeMin: 15,
    cookTimeMin: 35,
    difficulty: 'Fácil',
    suitability: 'Gatos castrados con propensión a engordar',
    clinicalBenefits: ['Carne magra hipoalergénica', 'Fibra saciante sin carbohidratos complejos que disparen glucosa', 'Taurina'],
    ingredients: [
      { name: 'Carne magra de conejo deshuesada', category: 'protein', baseGramsFor10kgPetPerDay: 105, notes: 'Cocer 35 min' },
      { name: 'Judías verdes muy cocidas picadas fino', category: 'vegetable', baseGramsFor10kgPetPerDay: 12, notes: 'Cocer 12 min' },
      { name: 'Taurina felina', category: 'supplement_calcium', baseGramsFor10kgPetPerDay: 0.5, notes: 'Al templar' },
      { name: 'Aceite de salmón', category: 'healthy_fat', baseGramsFor10kgPetPerDay: 2, notes: 'Omega 3' },
      { name: 'Cáscara de huevo molida', category: 'supplement_calcium', baseGramsFor10kgPetPerDay: 2, notes: 'Calcio' }
    ],
    instructions: [
      'Cocer el conejo 35 minutos y desmenuzar con minuciosidad retirando huesos.',
      'Cocer las judías 12 minutos y picar en brunoise fina.',
      'Mezclar todo en templado con la taurina, el aceite de salmón y la cáscara de huevo molida.'
    ],
    storageInfo: 'Nevera 48h, congelador 2 meses.',
    macronutrients: { proteinPct: 58, fatPct: 23, fiberCarbPct: 3, moisturePct: 78 }
  },
  {
    id: 'cat-adu-04',
    title: 'Salmón con Calabacín para Gatos Adultos',
    frenchTitle: 'Saumon Grillé & Courgettes Chat Adulte',
    species: 'cat',
    growthStage: 'adult',
    category: 'joint_omega3',
    categoryLabel: 'Piel Radiante & Manto Sedoso',
    description: 'Hornear salmón 12 min y cocer calabacín 10 min. Añadir taurina, aceite de linaza y cáscara de huevo.',
    kcalPer100g: 135,
    prepTimeMin: 15,
    cookTimeMin: 15,
    difficulty: 'Fácil',
    suitability: 'Gatos de interior con caspa o pérdida de brillo en el pelo',
    clinicalBenefits: ['Ácidos grasos EPA/DHA que calman el prurito y la sequedad dérmica', 'Calabacín que hidrata el epitelio', 'Taurina'],
    ingredients: [
      { name: 'Lomo de salmón fresco desespinado', category: 'protein', baseGramsFor10kgPetPerDay: 95, notes: 'Hornear 12 min' },
      { name: 'Calabacín cocido', category: 'vegetable', baseGramsFor10kgPetPerDay: 15, notes: 'Cocer 10 min' },
      { name: 'Taurina felina', category: 'supplement_calcium', baseGramsFor10kgPetPerDay: 0.5, notes: 'Al templar' },
      { name: 'Aceite de linaza', category: 'healthy_fat', baseGramsFor10kgPetPerDay: 2, notes: 'En crudo' },
      { name: 'Cáscara de huevo en polvo', category: 'supplement_calcium', baseGramsFor10kgPetPerDay: 2, notes: 'Calcio' }
    ],
    instructions: [
      'Hornear el salmón 12 minutos y asegurar ausencia absoluta de espinas palpando con dedos.',
      'Cocer el calabacín 10 minutos y aplastar en puré.',
      'Mezclar en tibio con la taurina, el aceite de linaza y la cáscara de huevo.'
    ],
    storageInfo: 'Nevera 48 horas.',
    macronutrients: { proteinPct: 52, fatPct: 29, fiberCarbPct: 3, moisturePct: 76 }
  },
  {
    id: 'cat-adu-05',
    title: 'Ternera Magra con Calabaza para Gatos Adultos',
    frenchTitle: 'Bœuf Haché aux Dés de Potiron Chat Adulte',
    species: 'cat',
    growthStage: 'adult',
    category: 'vitality_gourmet',
    categoryLabel: 'Hierro Vital & Fuerza Carnívora',
    description: 'Cocer ternera 25 min y calabaza 15 min. Incorporar taurina, aceite de salmón y cáscara de huevo.',
    kcalPer100g: 135,
    prepTimeMin: 15,
    cookTimeMin: 25,
    difficulty: 'Fácil',
    suitability: 'Gatos activos con fuerte instinto cazador y requerimiento de carnes rojas magras',
    clinicalBenefits: ['Zinc y aminoácidos azufrados para síntesis de queratina', 'Calabaza para regular heces', 'Taurina'],
    ingredients: [
      { name: 'Ternera magra picada', category: 'protein', baseGramsFor10kgPetPerDay: 100, notes: 'Cocer 25 min' },
      { name: 'Calabaza cocida', category: 'vegetable', baseGramsFor10kgPetPerDay: 15, notes: 'Cocer 15 min' },
      { name: 'Taurina felina', category: 'supplement_calcium', baseGramsFor10kgPetPerDay: 0.5, notes: 'Al templar' },
      { name: 'Aceite de salmón', category: 'healthy_fat', baseGramsFor10kgPetPerDay: 2, notes: 'Omega 3' },
      { name: 'Cáscara de huevo molida', category: 'supplement_calcium', baseGramsFor10kgPetPerDay: 2, notes: 'Calcio' }
    ],
    instructions: [
      'Cocer la ternera picada 25 minutos.',
      'Cocer la calabaza 15 minutos y chafarla fino.',
      'Integrar en templado junto a la taurina, el aceite de salmón y la cáscara de huevo molida.'
    ],
    storageInfo: 'Nevera 48h, congelador 2 meses.',
    macronutrients: { proteinPct: 55, fatPct: 26, fiberCarbPct: 3, moisturePct: 76 }
  },
  {
    id: 'cat-adu-06',
    title: 'Pato con Calabacín para Gatos Adultos',
    frenchTitle: 'Canard Savoureux aux Courgettes Chat Adulte',
    species: 'cat',
    growthStage: 'adult',
    category: 'vitality_gourmet',
    categoryLabel: 'Aroma Intenso & Palatabilidad Superior',
    description: 'Hornear pato 35 min y cocer calabacín 10 min. Añadir taurina, aceite de linaza y cáscara de huevo.',
    kcalPer100g: 140,
    prepTimeMin: 15,
    cookTimeMin: 35,
    difficulty: 'Fácil',
    suitability: 'Gatos que rechazan el pollo habitual o necesitan estímulo olfativo',
    clinicalBenefits: ['Palatabilidad natural de grasas monoinsaturadas aviares', 'Calabacín para volumen urinario', 'Taurina'],
    ingredients: [
      { name: 'Carne magra de pato sin piel sobrante', category: 'protein', baseGramsFor10kgPetPerDay: 95, notes: 'Hornear 35 min' },
      { name: 'Calabacín cocido en dados', category: 'vegetable', baseGramsFor10kgPetPerDay: 15, notes: 'Cocer 10 min' },
      { name: 'Taurina felina', category: 'supplement_calcium', baseGramsFor10kgPetPerDay: 0.5, notes: 'Al templar' },
      { name: 'Aceite de linaza', category: 'healthy_fat', baseGramsFor10kgPetPerDay: 2, notes: 'En crudo' },
      { name: 'Cáscara de huevo molida', category: 'supplement_calcium', baseGramsFor10kgPetPerDay: 2, notes: 'Calcio' }
    ],
    instructions: [
      'Hornear el pato 35 minutos desgrasando el fondo.',
      'Cocer el calabacín 10 minutos.',
      'Picar la carne en daditos, unir al calabacín y añadir taurina, linaza y cáscara de huevo en templado.'
    ],
    storageInfo: 'Nevera 48h, congelador 2 meses.',
    macronutrients: { proteinPct: 53, fatPct: 29, fiberCarbPct: 3, moisturePct: 75 }
  },
  {
    id: 'cat-adu-07',
    title: 'Trucha con Judías Verdes para Gatos Adultos',
    frenchTitle: 'Truite Fraîche aux Haricots Verts Chat Adulte',
    species: 'cat',
    growthStage: 'adult',
    category: 'joint_omega3',
    categoryLabel: 'Pescado de Río Ligero & Saciante',
    description: 'Trucha 12 min y judías verdes 12 min. Terminar con taurina, aceite de salmón y cáscara de huevo.',
    kcalPer100g: 125,
    prepTimeMin: 15,
    cookTimeMin: 15,
    difficulty: 'Fácil',
    suitability: 'Gatos que requieren una comida rica en omega 3 con bajo tenor de sodio',
    clinicalBenefits: ['Pescado fresco de agua dulce sin exceso de salinidad', 'Fibra verde que regula tránsito', 'Taurina'],
    ingredients: [
      { name: 'Trucha limpia desespinada al vapor', category: 'protein', baseGramsFor10kgPetPerDay: 100, notes: 'Cocer 12 min' },
      { name: 'Judías verdes tiernas picadas', category: 'vegetable', baseGramsFor10kgPetPerDay: 12, notes: 'Cocer 12 min' },
      { name: 'Taurina felina', category: 'supplement_calcium', baseGramsFor10kgPetPerDay: 0.5, notes: 'Al templar' },
      { name: 'Aceite de salmón', category: 'healthy_fat', baseGramsFor10kgPetPerDay: 2, notes: 'Omega 3' },
      { name: 'Cáscara de huevo en polvo', category: 'supplement_calcium', baseGramsFor10kgPetPerDay: 2, notes: 'Calcio' }
    ],
    instructions: [
      'Cocinar la trucha al vapor 12 minutos y retirar escrupulosamente toda espina.',
      'Cocer las judías verdes 12 minutos y trocear muy fino.',
      'Mezclar e integrar la taurina, el aceite de salmón y el calcio al templar.'
    ],
    storageInfo: 'Nevera 48 horas.',
    macronutrients: { proteinPct: 54, fatPct: 26, fiberCarbPct: 3, moisturePct: 77 }
  },
  {
    id: 'cat-adu-08',
    title: 'Pavo con Corazón de Pollo para Gatos Adultos',
    frenchTitle: 'Dinde Fondante & Cœur de Volaille Chat Adulte',
    species: 'cat',
    growthStage: 'adult',
    category: 'vitality_gourmet',
    categoryLabel: 'Taurina Natural Máxima & Musculatura Magra',
    description: 'Cocer pavo 20 min y corazón 7 min. Añadir taurina, aceite de linaza y cáscara de huevo.',
    kcalPer100g: 130,
    prepTimeMin: 15,
    cookTimeMin: 20,
    difficulty: 'Fácil',
    suitability: 'Gatos adultos con requerimiento de protección cardiaca y fuerza muscular',
    clinicalBenefits: ['Doble fuente de taurina (miocardio y taurina libre)', 'Digestibilidad superior al 92%', 'Calcio'],
    ingredients: [
      { name: 'Pechuga de pavo cocida', category: 'protein', baseGramsFor10kgPetPerDay: 80, notes: 'Cocer 20 min' },
      { name: 'Corazón de pollo picado', category: 'organ_meat', baseGramsFor10kgPetPerDay: 30, notes: 'Cocer 7 min' },
      { name: 'Taurina felina', category: 'supplement_calcium', baseGramsFor10kgPetPerDay: 0.5, notes: 'Al templar' },
      { name: 'Aceite de linaza', category: 'healthy_fat', baseGramsFor10kgPetPerDay: 2, notes: 'En crudo' },
      { name: 'Cáscara de huevo molida', category: 'supplement_calcium', baseGramsFor10kgPetPerDay: 2, notes: 'Calcio' }
    ],
    instructions: [
      'Cocer el pavo 20 minutos y añadir los corazones los últimos 7 minutos.',
      'Picar en trocitos menudos.',
      'Añadir taurina, aceite de linaza y cáscara de huevo molida en tibio.'
    ],
    storageInfo: 'Nevera 48h, congelador 2 meses.',
    macronutrients: { proteinPct: 57, fatPct: 25, fiberCarbPct: 2, moisturePct: 76 }
  },
  {
    id: 'cat-adu-09',
    title: 'Conejo con Calabaza para Gatos Adultos',
    frenchTitle: 'Lapin Délicat au Potiron Chat Adulte',
    species: 'cat',
    growthStage: 'adult',
    category: 'sensitive_digestion',
    categoryLabel: 'Hipoalergénico Felino & Tránsito Digestivo',
    description: 'Cocer conejo 35 min y calabaza 15 min. Incorporar taurina, aceite de salmón y cáscara de huevo.',
    kcalPer100g: 125,
    prepTimeMin: 15,
    cookTimeMin: 35,
    difficulty: 'Fácil',
    suitability: 'Gatos con dermatitis atópica, prurito crónico o heces secas',
    clinicalBenefits: ['Proteína novel que minimiza reacciones de hipersensibilidad', 'Calabaza emoliente', 'Taurina'],
    ingredients: [
      { name: 'Carne magra de conejo deshuesada', category: 'protein', baseGramsFor10kgPetPerDay: 100, notes: 'Cocer 35 min' },
      { name: 'Calabaza cocida', category: 'vegetable', baseGramsFor10kgPetPerDay: 15, notes: 'Cocer 15 min' },
      { name: 'Taurina felina', category: 'supplement_calcium', baseGramsFor10kgPetPerDay: 0.5, notes: 'Al templar' },
      { name: 'Aceite de salmón', category: 'healthy_fat', baseGramsFor10kgPetPerDay: 2, notes: 'Omega 3' },
      { name: 'Cáscara de huevo molida', category: 'supplement_calcium', baseGramsFor10kgPetPerDay: 2, notes: 'Calcio' }
    ],
    instructions: [
      'Cocer el conejo 35 minutos y retirar todo vestigio de hueso.',
      'Cocer la calabaza 15 minutos y aplastar con tenedor.',
      'Unir la carne desmigada al puré y añadir taurina, aceite de salmón y cáscara de huevo en templado.'
    ],
    storageInfo: 'Nevera 48h, congelador 2 meses.',
    macronutrients: { proteinPct: 56, fatPct: 24, fiberCarbPct: 4, moisturePct: 77 }
  },
  {
    id: 'cat-adu-10',
    title: 'Pollo con Hígado y Calabacín para Gatos Adultos',
    frenchTitle: 'Poulet aux Éclats de Foie & Courgettes Chat Adulte',
    species: 'cat',
    growthStage: 'adult',
    category: 'vitality_gourmet',
    categoryLabel: 'Vitaminas Naturales A & B & Hidratación',
    description: 'Cocer pollo 20 min, hígado 7 min y calabacín 10 min. Añadir taurina, omega 3 y cáscara de huevo.',
    kcalPer100g: 130,
    prepTimeMin: 15,
    cookTimeMin: 20,
    difficulty: 'Fácil',
    suitability: 'Gatos que precisan recarga de micronutrientes orgánicos sin recurrir a premezclas sintéticas',
    clinicalBenefits: ['Vitamina A preformada del hígado en dosis exacta de seguridad (10%)', 'Calabacín diurético', 'Taurina'],
    ingredients: [
      { name: 'Pechuga de pollo cocida', category: 'protein', baseGramsFor10kgPetPerDay: 85, notes: 'Cocer 20 min' },
      { name: 'Hígado de pollo fresco', category: 'organ_meat', baseGramsFor10kgPetPerDay: 12, notes: 'Cocer 7 min' },
      { name: 'Calabacín cocido suave', category: 'vegetable', baseGramsFor10kgPetPerDay: 15, notes: 'Cocer 10 min' },
      { name: 'Taurina felina', category: 'supplement_calcium', baseGramsFor10kgPetPerDay: 0.5, notes: 'Al templar' },
      { name: 'Aceite de salmón (omega 3)', category: 'healthy_fat', baseGramsFor10kgPetPerDay: 2, notes: 'Ácidos EPA/DHA' },
      { name: 'Cáscara de huevo molida', category: 'supplement_calcium', baseGramsFor10kgPetPerDay: 2, notes: 'Calcio' }
    ],
    instructions: [
      'Cocer el pollo 20 minutos con el hígado los últimos 7 minutos.',
      'Cocer el calabacín 10 minutos y triturar ligeramente.',
      'Picar las carnes, unir y espolvorear la taurina, el aceite y la cáscara de huevo al templar.'
    ],
    storageInfo: 'Nevera 48h, congelador 2 meses.',
    macronutrients: { proteinPct: 56, fatPct: 26, fiberCarbPct: 3, moisturePct: 77 }
  },
  {
    id: 'cat-adu-11',
    title: 'Salmón con Pavo y Calabaza para Gatos Adultos',
    frenchTitle: 'Trio Saumon Dinde & Potiron Chat Adulte',
    species: 'cat',
    growthStage: 'adult',
    category: 'joint_omega3',
    categoryLabel: 'Equilibrio Marino-Terrestre Completo',
    description: 'Hornear salmón 12 min, cocer pavo 20 min y calabaza 15 min. Añadir taurina, aceite de salmón y cáscara de huevo.',
    kcalPer100g: 135,
    prepTimeMin: 15,
    cookTimeMin: 20,
    difficulty: 'Fácil',
    suitability: 'Gatos que adoran la variedad de texturas y carnes en un mismo cuenco',
    clinicalBenefits: ['Proteína magra combinada con ácidos grasos esenciales marinos', 'Calabaza para bolas de pelo', 'Taurina'],
    ingredients: [
      { name: 'Salmón horneado desespinado', category: 'protein', baseGramsFor10kgPetPerDay: 50, notes: 'Hornear 12 min' },
      { name: 'Pavo cocido picado', category: 'protein', baseGramsFor10kgPetPerDay: 50, notes: 'Cocer 20 min' },
      { name: 'Calabaza cocida en puré', category: 'vegetable', baseGramsFor10kgPetPerDay: 15, notes: 'Cocer 15 min' },
      { name: 'Taurina felina', category: 'supplement_calcium', baseGramsFor10kgPetPerDay: 0.5, notes: 'Al templar' },
      { name: 'Aceite de salmón', category: 'healthy_fat', baseGramsFor10kgPetPerDay: 2, notes: 'Omega 3' },
      { name: 'Cáscara de huevo molida', category: 'supplement_calcium', baseGramsFor10kgPetPerDay: 2, notes: 'Calcio' }
    ],
    instructions: [
      'Hornear el salmón 12 minutos y cerciorarse de retirar espinas.',
      'Cocer el pavo 20 minutos y la calabaza 15 minutos.',
      'Picar fino, integrar en puré y añadir la taurina, el aceite y el calcio en tibio.'
    ],
    storageInfo: 'Nevera 48 horas.',
    macronutrients: { proteinPct: 54, fatPct: 28, fiberCarbPct: 3, moisturePct: 76 }
  },
  {
    id: 'cat-adu-12',
    title: 'Ternera con Corazón de Pavo para Gatos Adultos',
    frenchTitle: 'Bœuf & Cœur de Dinde Moelleux Chat Adulte',
    species: 'cat',
    growthStage: 'adult',
    category: 'vitality_gourmet',
    categoryLabel: 'Potencia Muscular & Taurina Robusta',
    description: 'Cocer ternera 25 min y corazón 7 min. Añadir taurina, aceite de linaza y cáscara de huevo.',
    kcalPer100g: 135,
    prepTimeMin: 15,
    cookTimeMin: 25,
    difficulty: 'Fácil',
    suitability: 'Gatos muy activos que necesitan mantener volumen fibrilar y tono muscular óptimo',
    clinicalBenefits: ['Creatina, L-carnitina y taurina naturales del músculo estriado', 'Calcio'],
    ingredients: [
      { name: 'Ternera magra picada', category: 'protein', baseGramsFor10kgPetPerDay: 75, notes: 'Cocer 25 min' },
      { name: 'Corazón de pavo picado', category: 'organ_meat', baseGramsFor10kgPetPerDay: 35, notes: 'Cocer 7 min' },
      { name: 'Taurina felina', category: 'supplement_calcium', baseGramsFor10kgPetPerDay: 0.5, notes: 'Al templar' },
      { name: 'Aceite de linaza', category: 'healthy_fat', baseGramsFor10kgPetPerDay: 2, notes: 'En crudo' },
      { name: 'Cáscara de huevo molida', category: 'supplement_calcium', baseGramsFor10kgPetPerDay: 2, notes: 'Calcio' }
    ],
    instructions: [
      'Cocer la ternera 25 minutos y los corazones de pavo 7 minutos.',
      'Cortar en dados menudos.',
      'Mezclar y añadir taurina, aceite de linaza y cáscara de huevo molida en tibio.'
    ],
    storageInfo: 'Nevera 48h, congelador 2 meses.',
    macronutrients: { proteinPct: 58, fatPct: 26, fiberCarbPct: 2, moisturePct: 75 }
  },
  {
    id: 'cat-adu-13',
    title: 'Pato con Judías Verdes para Gatos Adultos',
    frenchTitle: 'Canard Rôti aux Haricots Verts Chat Adulte',
    species: 'cat',
    growthStage: 'adult',
    category: 'vitality_gourmet',
    categoryLabel: 'Sabor Caza Silvestre & Fibra Reguladora',
    description: 'Hornear pato 35 min y cocer judías verdes 12 min. Terminar con taurina, aceite de salmón y cáscara de huevo.',
    kcalPer100g: 135,
    prepTimeMin: 15,
    cookTimeMin: 35,
    difficulty: 'Fácil',
    suitability: 'Gatos que disfrutan de sabores silvestres pero tienden al sobrepeso',
    clinicalBenefits: ['Digestibilidad excelente con efecto saciante de la fibra verde', 'Taurina', 'Calcio'],
    ingredients: [
      { name: 'Carne magra de pato sin grasa sobrante', category: 'protein', baseGramsFor10kgPetPerDay: 95, notes: 'Hornear 35 min' },
      { name: 'Judías verdes cocidas picadas', category: 'vegetable', baseGramsFor10kgPetPerDay: 15, notes: 'Cocer 12 min' },
      { name: 'Taurina felina', category: 'supplement_calcium', baseGramsFor10kgPetPerDay: 0.5, notes: 'Al templar' },
      { name: 'Aceite de salmón', category: 'healthy_fat', baseGramsFor10kgPetPerDay: 2, notes: 'Omega 3' },
      { name: 'Cáscara de huevo molida', category: 'supplement_calcium', baseGramsFor10kgPetPerDay: 2, notes: 'Calcio' }
    ],
    instructions: [
      'Hornear el pato 35 minutos escurriendo bien el exceso graso.',
      'Cocer las judías verdes 12 minutos y trocear muy fino.',
      'Mezclar en templado e incorporar taurina, aceite de salmón y cáscara de huevo.'
    ],
    storageInfo: 'Nevera 48h, congelador 2 meses.',
    macronutrients: { proteinPct: 54, fatPct: 27, fiberCarbPct: 3, moisturePct: 76 }
  },
  {
    id: 'cat-adu-14',
    title: 'Trucha con Calabacín para Gatos Adultos',
    frenchTitle: 'Truite Tendre aux Courgettes Chat Adulte',
    species: 'cat',
    growthStage: 'adult',
    category: 'joint_omega3',
    categoryLabel: 'Hidratación Renovesical & Digestión Liviana',
    description: 'Trucha 12 min y calabacín 10 min. Incorporar taurina, aceite de linaza y cáscara de huevo.',
    kcalPer100g: 125,
    prepTimeMin: 15,
    cookTimeMin: 15,
    difficulty: 'Fácil',
    suitability: 'Gatos propensos al sedentarismo y orina concentrada',
    clinicalBenefits: ['Abundante agua intersticial natural que previene urolitiasis', 'Taurina', 'Calcio'],
    ingredients: [
      { name: 'Trucha al vapor sin espinas', category: 'protein', baseGramsFor10kgPetPerDay: 100, notes: 'Cocer 12 min' },
      { name: 'Calabacín cocido en dados suaves', category: 'vegetable', baseGramsFor10kgPetPerDay: 15, notes: 'Cocer 10 min' },
      { name: 'Taurina felina', category: 'supplement_calcium', baseGramsFor10kgPetPerDay: 0.5, notes: 'Al templar' },
      { name: 'Aceite de linaza', category: 'healthy_fat', baseGramsFor10kgPetPerDay: 2, notes: 'En crudo' },
      { name: 'Cáscara de huevo molida', category: 'supplement_calcium', baseGramsFor10kgPetPerDay: 2, notes: 'Calcio' }
    ],
    instructions: [
      'Cocinar la trucha al vapor 12 minutos revisando que no queden espinas.',
      'Cocer el calabacín 10 minutos y machacar con tenedor.',
      'Integrar en tibio con la taurina, el aceite de linaza y la cáscara de huevo molida.'
    ],
    storageInfo: 'Nevera 48 horas.',
    macronutrients: { proteinPct: 53, fatPct: 26, fiberCarbPct: 3, moisturePct: 78 }
  },
  {
    id: 'cat-adu-15',
    title: 'Conejo con Corazón de Pollo para Gatos Adultos',
    frenchTitle: 'Lapin & Cœurs Volaille Spécial Taurine Chat Adulte',
    species: 'cat',
    growthStage: 'adult',
    category: 'sensitive_digestion',
    categoryLabel: 'Doble Pureza Digestiva & Corazón Fuerte',
    description: 'Cocer conejo 35 min y corazón 7 min. Añadir taurina, aceite de salmón y cáscara de huevo.',
    kcalPer100g: 130,
    prepTimeMin: 15,
    cookTimeMin: 35,
    difficulty: 'Fácil',
    suitability: 'Gatos que requieren carnes de asimilación sin residuo',
    clinicalBenefits: ['Proteína magra sin alérgenos comunes', 'Concentración alta de taurina', 'Calcio'],
    ingredients: [
      { name: 'Carne de conejo deshuesada', category: 'protein', baseGramsFor10kgPetPerDay: 80, notes: 'Cocer 35 min' },
      { name: 'Corazón de pollo troceado', category: 'organ_meat', baseGramsFor10kgPetPerDay: 30, notes: 'Cocer 7 min' },
      { name: 'Taurina felina', category: 'supplement_calcium', baseGramsFor10kgPetPerDay: 0.5, notes: 'Al templar' },
      { name: 'Aceite de salmón', category: 'healthy_fat', baseGramsFor10kgPetPerDay: 2, notes: 'Omega 3' },
      { name: 'Cáscara de huevo molida', category: 'supplement_calcium', baseGramsFor10kgPetPerDay: 2, notes: 'Calcio' }
    ],
    instructions: [
      'Cocer el conejo 35 minutos y retirar meticulosamente todo hueso.',
      'Cocer el corazón 7 minutos y cortar fino.',
      'Mezclar en templado e incorporar la taurina, el aceite de salmón y la cáscara de huevo.'
    ],
    storageInfo: 'Nevera 48h, congelador 2 meses.',
    macronutrients: { proteinPct: 58, fatPct: 24, fiberCarbPct: 2, moisturePct: 76 }
  },
  {
    id: 'cat-adu-16',
    title: 'Pollo con Calabacín y Espinaca para Gatos Adultos',
    frenchTitle: 'Poulet aux Jeunes Pousses d’Épinards & Courgettes Chat Adulte',
    species: 'cat',
    growthStage: 'adult',
    category: 'sensitive_digestion',
    categoryLabel: 'Antioxidantes Verdes & Flora Felina',
    description: 'Cocer pollo 20 min, calabacín 10 min y espinaca 5 min. Añadir taurina, omega 3 y cáscara de huevo.',
    kcalPer100g: 125,
    prepTimeMin: 15,
    cookTimeMin: 20,
    difficulty: 'Fácil',
    suitability: 'Gatos que viven exclusivamente dentro de casa con metabolismo pausado',
    clinicalBenefits: ['Aporte de clorofila y luteína en microcantidades toleradas', 'Taurina', 'Calcio'],
    ingredients: [
      { name: 'Pechuga de pollo cocida', category: 'protein', baseGramsFor10kgPetPerDay: 95, notes: 'Cocer 20 min' },
      { name: 'Calabacín cocido', category: 'vegetable', baseGramsFor10kgPetPerDay: 10, notes: 'Cocer 10 min' },
      { name: 'Espinacas tiernas escaldadas', category: 'vegetable', baseGramsFor10kgPetPerDay: 5, notes: 'Escaldar 5 min' },
      { name: 'Taurina felina', category: 'supplement_calcium', baseGramsFor10kgPetPerDay: 0.5, notes: 'Al templar' },
      { name: 'Aceite de salmón', category: 'healthy_fat', baseGramsFor10kgPetPerDay: 2, notes: 'Omega 3' },
      { name: 'Cáscara de huevo molida', category: 'supplement_calcium', baseGramsFor10kgPetPerDay: 2, notes: 'Calcio' }
    ],
    instructions: [
      'Cocer el pollo 20 minutos y triturar.',
      'Cocer el calabacín 10 minutos y escaldar las espinacas 5 minutos picándolas en papilla fina.',
      'Unir todo y agregar taurina, aceite omega 3 y cáscara de huevo al templar.'
    ],
    storageInfo: 'Nevera 48h, congelador 2 meses.',
    macronutrients: { proteinPct: 56, fatPct: 24, fiberCarbPct: 4, moisturePct: 77 }
  },
  {
    id: 'cat-adu-17',
    title: 'Pavo con Calabaza y Judías Verdes para Gatos Adultos',
    frenchTitle: 'Dinde Gourmande aux Deux Légumes Chat Adulte',
    species: 'cat',
    growthStage: 'adult',
    category: 'sensitive_digestion',
    categoryLabel: 'Doble Fibra Suave & Saciedad Óptima',
    description: 'Cocer pavo 20 min, calabaza 15 min y judías 12 min. Añadir taurina, aceite de salmón y cáscara de huevo.',
    kcalPer100g: 125,
    prepTimeMin: 15,
    cookTimeMin: 20,
    difficulty: 'Fácil',
    suitability: 'Gatos castrados con tendencia al atracón o ansiedad por comida',
    clinicalBenefits: ['Saciedad gástrica prolongada sin hidratos de carbono refinados', 'Taurina', 'Calcio'],
    ingredients: [
      { name: 'Pavo cocido troceado', category: 'protein', baseGramsFor10kgPetPerDay: 95, notes: 'Cocer 20 min' },
      { name: 'Calabaza cocida', category: 'vegetable', baseGramsFor10kgPetPerDay: 10, notes: 'Cocer 15 min' },
      { name: 'Judías verdes tiernas', category: 'vegetable', baseGramsFor10kgPetPerDay: 8, notes: 'Cocer 12 min' },
      { name: 'Taurina felina', category: 'supplement_calcium', baseGramsFor10kgPetPerDay: 0.5, notes: 'Al templar' },
      { name: 'Aceite de salmón', category: 'healthy_fat', baseGramsFor10kgPetPerDay: 2, notes: 'Omega 3' },
      { name: 'Cáscara de huevo molida', category: 'supplement_calcium', baseGramsFor10kgPetPerDay: 2, notes: 'Calcio' }
    ],
    instructions: [
      'Cocer el pavo 20 minutos.',
      'Cocer la calabaza 15 minutos y las judías verdes 12 minutos machacando fino.',
      'Integrar en tibio con taurina, aceite de salmón y cáscara de huevo.'
    ],
    storageInfo: 'Nevera 48h, congelador 2 meses.',
    macronutrients: { proteinPct: 55, fatPct: 24, fiberCarbPct: 4, moisturePct: 77 }
  },
  {
    id: 'cat-adu-18',
    title: 'Ternera con Calabacín y Corazón para Gatos Adultos',
    frenchTitle: 'Bœuf Tendre Cœurs de Volaille & Courgettes Chat Adulte',
    species: 'cat',
    growthStage: 'adult',
    category: 'vitality_gourmet',
    categoryLabel: 'Fórmula Revitalizante & Taurina Concentrada',
    description: 'Cocer ternera 25 min, calabacín 10 min y corazón 7 min. Incorporar taurina, aceite de linaza y cáscara de huevo.',
    kcalPer100g: 135,
    prepTimeMin: 15,
    cookTimeMin: 25,
    difficulty: 'Fácil',
    suitability: 'Gatos que precisan una ingesta densa en hierro y taurina con soporte diurético suave',
    clinicalBenefits: ['Equilibrio entre masa magra y carnes de víscera funcional', 'Taurina reforzada', 'Calcio'],
    ingredients: [
      { name: 'Ternera magra picada', category: 'protein', baseGramsFor10kgPetPerDay: 75, notes: 'Cocer 25 min' },
      { name: 'Corazón de pollo picado', category: 'organ_meat', baseGramsFor10kgPetPerDay: 25, notes: 'Cocer 7 min' },
      { name: 'Calabacín cocido', category: 'vegetable', baseGramsFor10kgPetPerDay: 12, notes: 'Cocer 10 min' },
      { name: 'Taurina felina', category: 'supplement_calcium', baseGramsFor10kgPetPerDay: 0.5, notes: 'Al templar' },
      { name: 'Aceite de linaza', category: 'healthy_fat', baseGramsFor10kgPetPerDay: 2, notes: 'En crudo' },
      { name: 'Cáscara de huevo molida', category: 'supplement_calcium', baseGramsFor10kgPetPerDay: 2, notes: 'Calcio' }
    ],
    instructions: [
      'Cocer la ternera 25 minutos con el corazón en los últimos 7 minutos.',
      'Cocer el calabacín 10 minutos.',
      'Mezclar en tibio y añadir la taurina, el aceite de linaza y la cáscara de huevo.'
    ],
    storageInfo: 'Nevera 48h, congelador 2 meses.',
    macronutrients: { proteinPct: 57, fatPct: 26, fiberCarbPct: 3, moisturePct: 75 }
  },
  {
    id: 'cat-adu-19',
    title: 'Salmón con Judías Verdes para Gatos Adultos',
    frenchTitle: 'Saumon Délicat aux Fins Haricots Verts Chat Adulte',
    species: 'cat',
    growthStage: 'adult',
    category: 'joint_omega3',
    categoryLabel: 'Lípidos Antiinflamatorios & Regulación Digestiva',
    description: 'Hornear salmón 12 min y cocer judías verdes 12 min. Terminar con taurina, aceite de salmón y cáscara de huevo.',
    kcalPer100g: 135,
    prepTimeMin: 15,
    cookTimeMin: 15,
    difficulty: 'Fácil',
    suitability: 'Gatos adultos con pelo reseco o descamación dérmica estacional',
    clinicalBenefits: ['Alta densidad de ácidos EPA y DHA para barrera cutánea', 'Taurina', 'Calcio'],
    ingredients: [
      { name: 'Salmón al horno sin espinas', category: 'protein', baseGramsFor10kgPetPerDay: 95, notes: 'Hornear 12 min' },
      { name: 'Judías verdes cocidas tiernas', category: 'vegetable', baseGramsFor10kgPetPerDay: 15, notes: 'Cocer 12 min' },
      { name: 'Taurina felina', category: 'supplement_calcium', baseGramsFor10kgPetPerDay: 0.5, notes: 'Al templar' },
      { name: 'Aceite de salmón', category: 'healthy_fat', baseGramsFor10kgPetPerDay: 2, notes: 'Omega 3' },
      { name: 'Cáscara de huevo molida', category: 'supplement_calcium', baseGramsFor10kgPetPerDay: 2, notes: 'Calcio' }
    ],
    instructions: [
      'Hornear el salmón 12 minutos retirando espinas minuciosamente.',
      'Cocer las judías 12 minutos y picar en migas.',
      'Unir y aderezar con taurina, aceite de salmón y cáscara de huevo en templado.'
    ],
    storageInfo: 'Nevera 48 horas.',
    macronutrients: { proteinPct: 53, fatPct: 29, fiberCarbPct: 3, moisturePct: 75 }
  },
  {
    id: 'cat-adu-20',
    title: 'Pato con Calabaza y Espinaca para Gatos Adultos',
    frenchTitle: 'Canard Fondant au Potiron & Épinards Chat Adulte',
    species: 'cat',
    growthStage: 'adult',
    category: 'vitality_gourmet',
    categoryLabel: 'Receta Gourmet Palatabilidad & Antioxidantes',
    description: 'Hornear pato 35 min, calabaza 15 min y espinaca 5 min. Añadir taurina, omega 3 y cáscara de huevo.',
    kcalPer100g: 140,
    prepTimeMin: 15,
    cookTimeMin: 35,
    difficulty: 'Fácil',
    suitability: 'Gatos que disfrutan de guisos sabrosos con alta densidad aromática',
    clinicalBenefits: ['Calabaza hidratante más antocianinas y flavonoides vegetales seguros', 'Taurina', 'Calcio'],
    ingredients: [
      { name: 'Carne magra de pato horneada', category: 'protein', baseGramsFor10kgPetPerDay: 95, notes: 'Hornear 35 min' },
      { name: 'Calabaza cocida', category: 'vegetable', baseGramsFor10kgPetPerDay: 10, notes: 'Cocer 15 min' },
      { name: 'Espinacas escaldadas picadas', category: 'vegetable', baseGramsFor10kgPetPerDay: 5, notes: 'Escaldar 5 min' },
      { name: 'Taurina felina', category: 'supplement_calcium', baseGramsFor10kgPetPerDay: 0.5, notes: 'Al templar' },
      { name: 'Aceite de salmón', category: 'healthy_fat', baseGramsFor10kgPetPerDay: 2, notes: 'Omega 3' },
      { name: 'Cáscara de huevo molida', category: 'supplement_calcium', baseGramsFor10kgPetPerDay: 2, notes: 'Calcio' }
    ],
    instructions: [
      'Hornear el pato 35 minutos desgrasando bien.',
      'Cocer la calabaza 15 minutos y escaldar la espinaca 5 minutos.',
      'Picar en daditos, triturar vegetales y mezclar con taurina, aceite de salmón y calcio al templar.'
    ],
    storageInfo: 'Nevera 48h, congelador 2 meses.',
    macronutrients: { proteinPct: 53, fatPct: 29, fiberCarbPct: 4, moisturePct: 75 }
  },
  {
    id: 'cat-adu-21',
    title: 'Codorniz con Calabacín para Gatos Adultos ⭐',
    frenchTitle: 'Caille Sauvage au Velouté de Courgettes Chat Adulte Gourmet',
    species: 'cat',
    growthStage: 'adult',
    category: 'vitality_gourmet',
    categoryLabel: 'Receta Premium Caza Menor & Hidratación Renal',
    description: 'Premium. Hornear codorniz 25 min y cocer calabacín 10 min. Terminar con taurina, aceite de salmón y cáscara de huevo.',
    kcalPer100g: 140,
    prepTimeMin: 15,
    cookTimeMin: 25,
    difficulty: 'Media',
    suitability: 'Gatos sibaritas o de razas propensas a inapetencia',
    clinicalBenefits: ['Proteína magra de caza menor con sabor intenso y digestibilidad absoluta', 'Taurina', 'Calcio'],
    ingredients: [
      { name: 'Carne de codorniz sin huesos', category: 'protein', baseGramsFor10kgPetPerDay: 100, notes: 'Hornear 25 min' },
      { name: 'Calabacín cocido en dados', category: 'vegetable', baseGramsFor10kgPetPerDay: 15, notes: 'Cocer 10 min' },
      { name: 'Taurina felina', category: 'supplement_calcium', baseGramsFor10kgPetPerDay: 0.5, notes: 'Al templar' },
      { name: 'Aceite de salmón', category: 'healthy_fat', baseGramsFor10kgPetPerDay: 2, notes: 'Omega 3' },
      { name: 'Cáscara de huevo molida', category: 'supplement_calcium', baseGramsFor10kgPetPerDay: 2, notes: 'Calcio' }
    ],
    instructions: [
      'Hornear la codorniz 25 minutos y desmigar meticulosamente descartando huesos pequeños.',
      'Cocer el calabacín 10 minutos y machacar con tenedor.',
      'Mezclar e incorporar taurina, aceite de salmón y cáscara de huevo en templado.'
    ],
    storageInfo: 'Nevera 48h, congelador 2 meses.',
    macronutrients: { proteinPct: 56, fatPct: 28, fiberCarbPct: 3, moisturePct: 75 }
  },
  {
    id: 'cat-adu-22',
    title: 'Faisán con Calabaza para Gatos Adultos ⭐',
    frenchTitle: 'Faisan des Bois au Potiron Doux Chat Adulte',
    species: 'cat',
    growthStage: 'adult',
    category: 'vitality_gourmet',
    categoryLabel: 'Receta Premium Caza Noble & Confort Gástrico',
    description: 'Premium. Hornear faisán 35 min y cocer calabaza 15 min. Añadir taurina, aceite de linaza y cáscara de huevo.',
    kcalPer100g: 135,
    prepTimeMin: 15,
    cookTimeMin: 35,
    difficulty: 'Media',
    suitability: 'Gatos que requieren una carne biológicamente pura sin aditivos industriales',
    clinicalBenefits: ['Mínima reactividad alérgica', 'Fibra vegetal soluble que previene constipación', 'Taurina'],
    ingredients: [
      { name: 'Carne de faisán deshuesada', category: 'protein', baseGramsFor10kgPetPerDay: 95, notes: 'Hornear 35 min' },
      { name: 'Calabaza cocida en puré', category: 'vegetable', baseGramsFor10kgPetPerDay: 15, notes: 'Cocer 15 min' },
      { name: 'Taurina felina', category: 'supplement_calcium', baseGramsFor10kgPetPerDay: 0.5, notes: 'Al templar' },
      { name: 'Aceite de linaza', category: 'healthy_fat', baseGramsFor10kgPetPerDay: 2, notes: 'En crudo' },
      { name: 'Cáscara de huevo molida', category: 'supplement_calcium', baseGramsFor10kgPetPerDay: 2, notes: 'Calcio' }
    ],
    instructions: [
      'Hornear el faisán 35 minutos y desmenuzar minuciosamente eliminando cualquier hueso.',
      'Cocer la calabaza 15 minutos y aplastar fino.',
      'Unir la carne al puré y mezclar con taurina, aceite de linaza y calcio en tibio.'
    ],
    storageInfo: 'Nevera 48h, congelador 2 meses.',
    macronutrients: { proteinPct: 57, fatPct: 25, fiberCarbPct: 3, moisturePct: 76 }
  },
  {
    id: 'cat-adu-23',
    title: 'Caballa con Judías Verdes para Gatos Adultos ⭐',
    frenchTitle: 'Maquereau Grillé aux Haricots Fins Chat Adulte',
    species: 'cat',
    growthStage: 'adult',
    category: 'joint_omega3',
    categoryLabel: 'Receta Premium Omega 3 Puro & Control Metabólico',
    description: 'Premium. Hornear caballa 15 min y cocer judías 12 min. Incorporar taurina, aceite de salmón y cáscara de huevo.',
    kcalPer100g: 140,
    prepTimeMin: 15,
    cookTimeMin: 15,
    difficulty: 'Fácil',
    suitability: 'Gatos adultos con problemas articulares tempranos o pérdida de brillo en manto',
    clinicalBenefits: ['Ácidos grasos esenciales poliinsaturados de origen marino', 'Taurina', 'Calcio'],
    ingredients: [
      { name: 'Caballa fresca horneada desespinada', category: 'protein', baseGramsFor10kgPetPerDay: 95, notes: 'Hornear 15 min' },
      { name: 'Judías verdes tiernas', category: 'vegetable', baseGramsFor10kgPetPerDay: 15, notes: 'Cocer 12 min' },
      { name: 'Taurina felina', category: 'supplement_calcium', baseGramsFor10kgPetPerDay: 0.5, notes: 'Al templar' },
      { name: 'Aceite de salmón', category: 'healthy_fat', baseGramsFor10kgPetPerDay: 2, notes: 'Omega 3' },
      { name: 'Cáscara de huevo molida', category: 'supplement_calcium', baseGramsFor10kgPetPerDay: 2, notes: 'Calcio' }
    ],
    instructions: [
      'Hornear la caballa 15 minutos y desmigar con tenedor verificando ausencia de espinas.',
      'Cocer las judías 12 minutos y picar diminuto.',
      'Mezclar con la taurina, el aceite de salmón y la cáscara de huevo molida en tibio.'
    ],
    storageInfo: 'Nevera 48 horas.',
    macronutrients: { proteinPct: 53, fatPct: 31, fiberCarbPct: 3, moisturePct: 75 }
  },
  {
    id: 'cat-adu-24',
    title: 'Conejo con Espinaca y Calabaza para Gatos Adultos ⭐',
    frenchTitle: 'Lapin Rôti au Potiron & Épinards Chat Adulte',
    species: 'cat',
    growthStage: 'adult',
    category: 'sensitive_digestion',
    categoryLabel: 'Receta Premium Hipoalergénica & Protección Digestiva',
    description: 'Premium. Cocer conejo 35 min, espinaca 5 min y calabaza 15 min. Añadir taurina, omega 3 y cáscara de huevo.',
    kcalPer100g: 125,
    prepTimeMin: 15,
    cookTimeMin: 35,
    difficulty: 'Fácil',
    suitability: 'Gatos que sufren vómitos por intolerancia a proteínas habituales',
    clinicalBenefits: ['Proteína magra biológicamente óptima', 'Fibra vegetal antiinflamatoria en dosis estrictamente felinas', 'Taurina'],
    ingredients: [
      { name: 'Carne de conejo deshuesada', category: 'protein', baseGramsFor10kgPetPerDay: 95, notes: 'Cocer 35 min' },
      { name: 'Calabaza cocida', category: 'vegetable', baseGramsFor10kgPetPerDay: 10, notes: 'Cocer 15 min' },
      { name: 'Espinacas escaldadas', category: 'vegetable', baseGramsFor10kgPetPerDay: 5, notes: 'Escaldar 5 min' },
      { name: 'Taurina felina', category: 'supplement_calcium', baseGramsFor10kgPetPerDay: 0.5, notes: 'Al templar' },
      { name: 'Aceite de salmón', category: 'healthy_fat', baseGramsFor10kgPetPerDay: 2, notes: 'Omega 3' },
      { name: 'Cáscara de huevo molida', category: 'supplement_calcium', baseGramsFor10kgPetPerDay: 2, notes: 'Calcio' }
    ],
    instructions: [
      'Cocer el conejo 35 minutos y asegurar desespinado/deshuesado absoluto.',
      'Cocer la calabaza 15 minutos y escaldar la espinaca 5 minutos formando un puré verde suave.',
      'Mezclar la carne con el puré e integrar taurina, aceite y cáscara de huevo.'
    ],
    storageInfo: 'Nevera 48h, congelador 2 meses.',
    macronutrients: { proteinPct: 56, fatPct: 24, fiberCarbPct: 4, moisturePct: 77 }
  },
  {
    id: 'cat-adu-25',
    title: 'Pato con Corazón de Conejo para Gatos Adultos ⭐',
    frenchTitle: 'Canard Savoureux & Cœur de Lapin Chat Adulte',
    species: 'cat',
    growthStage: 'adult',
    category: 'vitality_gourmet',
    categoryLabel: 'Receta Premium Sabor Exclusivo & Taurina Pura',
    description: 'Premium. Hornear pato 35 min y cocer corazón 7 min. Terminar con taurina, aceite de linaza y cáscara de huevo.',
    kcalPer100g: 145,
    prepTimeMin: 15,
    cookTimeMin: 35,
    difficulty: 'Fácil',
    suitability: 'Gatos que demandan sabores intensos e ingredientes cárnicos de primera categoría',
    clinicalBenefits: ['Víscera noble de conejo que no inflama el intestino', 'Pato aromático', 'Taurina'],
    ingredients: [
      { name: 'Carne magra de pato horneada', category: 'protein', baseGramsFor10kgPetPerDay: 75, notes: 'Hornear 35 min' },
      { name: 'Corazón de conejo cocido picado', category: 'organ_meat', baseGramsFor10kgPetPerDay: 30, notes: 'Cocer 7 min' },
      { name: 'Taurina felina', category: 'supplement_calcium', baseGramsFor10kgPetPerDay: 0.5, notes: 'Al templar' },
      { name: 'Aceite de linaza', category: 'healthy_fat', baseGramsFor10kgPetPerDay: 2, notes: 'En crudo' },
      { name: 'Cáscara de huevo molida', category: 'supplement_calcium', baseGramsFor10kgPetPerDay: 2, notes: 'Calcio' }
    ],
    instructions: [
      'Hornear el pato 35 minutos y cocer el corazón de conejo 7 minutos.',
      'Picar menudo e integrar.',
      'Añadir taurina, aceite de linaza y cáscara de huevo molida en tibio.'
    ],
    storageInfo: 'Nevera 48h, congelador 2 meses.',
    macronutrients: { proteinPct: 56, fatPct: 29, fiberCarbPct: 2, moisturePct: 75 }
  },
  {
    id: 'cat-adu-26',
    title: 'Trucha con Calabaza y Calabacín para Gatos Adultos ⭐',
    frenchTitle: 'Truite Dorée au Duo Potiron Courgette Chat Adulte',
    species: 'cat',
    growthStage: 'adult',
    category: 'joint_omega3',
    categoryLabel: 'Receta Premium Hidratación Dual & Manto Brillante',
    description: 'Premium. Trucha 12 min, calabaza 15 min y calabacín 10 min. Añadir taurina, aceite de salmón y cáscara de huevo.',
    kcalPer100g: 130,
    prepTimeMin: 15,
    cookTimeMin: 15,
    difficulty: 'Fácil',
    suitability: 'Gatos que requieren hidratación extra sin perder apetito',
    clinicalBenefits: ['Baja carga osmótica renal', 'Pescado fresco de alta digestibilidad', 'Taurina'],
    ingredients: [
      { name: 'Trucha fresca sin espinas al vapor', category: 'protein', baseGramsFor10kgPetPerDay: 95, notes: 'Cocer 12 min' },
      { name: 'Calabaza cocida', category: 'vegetable', baseGramsFor10kgPetPerDay: 10, notes: 'Cocer 15 min' },
      { name: 'Calabacín cocido suave', category: 'vegetable', baseGramsFor10kgPetPerDay: 8, notes: 'Cocer 10 min' },
      { name: 'Taurina felina', category: 'supplement_calcium', baseGramsFor10kgPetPerDay: 0.5, notes: 'Al templar' },
      { name: 'Aceite de salmón', category: 'healthy_fat', baseGramsFor10kgPetPerDay: 2, notes: 'Omega 3' },
      { name: 'Cáscara de huevo molida', category: 'supplement_calcium', baseGramsFor10kgPetPerDay: 2, notes: 'Calcio' }
    ],
    instructions: [
      'Cocer la trucha al vapor 12 minutos y asegurar ausencia total de espinas.',
      'Cocer los vegetales y chafarlos en puré húmedo.',
      'Unir en tibio con la taurina, el aceite de salmón y la cáscara de huevo molida.'
    ],
    storageInfo: 'Nevera 48 horas.',
    macronutrients: { proteinPct: 53, fatPct: 26, fiberCarbPct: 4, moisturePct: 78 }
  },
  {
    id: 'cat-adu-27',
    title: 'Salmón con Corazón de Pollo para Gatos Adultos ⭐',
    frenchTitle: 'Saumon & Cœur de Volaille Chat Adulte',
    species: 'cat',
    growthStage: 'adult',
    category: 'vitality_gourmet',
    categoryLabel: 'Receta Premium Miocardio & Omega 3 de Mar',
    description: 'Premium. Hornear salmón 12 min y cocer corazón 7 min. Incorporar taurina, omega 3 y cáscara de huevo.',
    kcalPer100g: 145,
    prepTimeMin: 15,
    cookTimeMin: 15,
    difficulty: 'Fácil',
    suitability: 'Gatos que adoran sabores marinos combinados con textura cárnica densa',
    clinicalBenefits: ['Máxima concentración de taurina biodisponible para proteger miocardio felino', 'Omega 3', 'Calcio'],
    ingredients: [
      { name: 'Salmón horneado desespinado', category: 'protein', baseGramsFor10kgPetPerDay: 70, notes: 'Hornear 12 min' },
      { name: 'Corazón de pollo picado', category: 'organ_meat', baseGramsFor10kgPetPerDay: 35, notes: 'Cocer 7 min' },
      { name: 'Taurina felina', category: 'supplement_calcium', baseGramsFor10kgPetPerDay: 0.5, notes: 'Al templar' },
      { name: 'Aceite de salmón (omega 3)', category: 'healthy_fat', baseGramsFor10kgPetPerDay: 2, notes: 'Ácidos EPA/DHA' },
      { name: 'Cáscara de huevo molida', category: 'supplement_calcium', baseGramsFor10kgPetPerDay: 2, notes: 'Calcio' }
    ],
    instructions: [
      'Hornear el salmón 12 minutos revisando que no contenga ninguna espina.',
      'Cocer el corazón 7 minutos y cortar en daditos.',
      'Unir en tibio e incorporar la taurina, el omega 3 y la cáscara de huevo.'
    ],
    storageInfo: 'Nevera 48 horas.',
    macronutrients: { proteinPct: 55, fatPct: 31, fiberCarbPct: 2, moisturePct: 75 }
  },
  {
    id: 'cat-adu-28',
    title: 'Pavo con Hígado de Pato para Gatos Adultos ⭐',
    frenchTitle: 'Dinde Délicate & Foie de Canard Châtillon Chat Adulte',
    species: 'cat',
    growthStage: 'adult',
    category: 'vitality_gourmet',
    categoryLabel: 'Receta Premium Sabor Aves Nobles & Vitamina A',
    description: 'Premium. Cocer pavo 20 min e hígado 7 min. Añadir taurina, aceite de linaza y cáscara de huevo.',
    kcalPer100g: 135,
    prepTimeMin: 15,
    cookTimeMin: 20,
    difficulty: 'Fácil',
    suitability: 'Gatos exigentes que adoran la textura sedosa del hígado de pato',
    clinicalBenefits: ['Vitamina A natural para visión nocturna y salud de las mucosas', 'Taurina', 'Calcio'],
    ingredients: [
      { name: 'Pechuga de pavo cocida', category: 'protein', baseGramsFor10kgPetPerDay: 90, notes: 'Cocer 20 min' },
      { name: 'Hígado de pato fresco cocido', category: 'organ_meat', baseGramsFor10kgPetPerDay: 15, notes: 'Cocer 7 min' },
      { name: 'Taurina felina', category: 'supplement_calcium', baseGramsFor10kgPetPerDay: 0.5, notes: 'Al templar' },
      { name: 'Aceite de linaza', category: 'healthy_fat', baseGramsFor10kgPetPerDay: 2, notes: 'En crudo' },
      { name: 'Cáscara de huevo molida', category: 'supplement_calcium', baseGramsFor10kgPetPerDay: 2, notes: 'Calcio' }
    ],
    instructions: [
      'Cocer el pavo 20 minutos con el hígado en los últimos 7 minutos.',
      'Aplastar el hígado y desmigar el pavo.',
      'Integrar en templado con la taurina, el aceite de linaza y la cáscara de huevo molida.'
    ],
    storageInfo: 'Nevera 48h, congelador 2 meses.',
    macronutrients: { proteinPct: 56, fatPct: 27, fiberCarbPct: 2, moisturePct: 76 }
  },
  {
    id: 'cat-adu-29',
    title: 'Ternera con Faisán y Calabacín para Gatos Adultos ⭐',
    frenchTitle: 'Bœuf Faisan Sauvage & Courgettes Chat Adulte',
    species: 'cat',
    growthStage: 'adult',
    category: 'vitality_gourmet',
    categoryLabel: 'Receta Premium Densidad Proteica Silvestre',
    description: 'Premium. Cocer ternera 25 min, hornear faisán 35 min y calabacín 10 min. Terminar con taurina, aceite de salmón y cáscara de huevo.',
    kcalPer100g: 140,
    prepTimeMin: 15,
    cookTimeMin: 35,
    difficulty: 'Media',
    suitability: 'Gatos que requieren un perfil proteico robusto y carnes de caza mayor biodisponibilidad',
    clinicalBenefits: ['Zinc, hierro hémico y taurina en armonía digestiva', 'Calabacín para hidratación', 'Calcio'],
    ingredients: [
      { name: 'Ternera magra picada', category: 'protein', baseGramsFor10kgPetPerDay: 55, notes: 'Cocer 25 min' },
      { name: 'Carne de faisán deshuesada', category: 'protein', baseGramsFor10kgPetPerDay: 45, notes: 'Hornear 35 min' },
      { name: 'Calabacín cocido', category: 'vegetable', baseGramsFor10kgPetPerDay: 15, notes: 'Cocer 10 min' },
      { name: 'Taurina felina', category: 'supplement_calcium', baseGramsFor10kgPetPerDay: 0.5, notes: 'Al templar' },
      { name: 'Aceite de salmón', category: 'healthy_fat', baseGramsFor10kgPetPerDay: 2, notes: 'Omega 3' },
      { name: 'Cáscara de huevo en polvo', category: 'supplement_calcium', baseGramsFor10kgPetPerDay: 2, notes: 'Calcio' }
    ],
    instructions: [
      'Cocer la ternera picada 25 minutos y hornear el faisán 35 minutos retirando huesos.',
      'Cocer el calabacín 10 minutos.',
      'Mezclar todo menudo y agregar la taurina, el aceite de salmón y la cáscara de huevo molida.'
    ],
    storageInfo: 'Nevera 48h, congelador 2 meses.',
    macronutrients: { proteinPct: 57, fatPct: 27, fiberCarbPct: 3, moisturePct: 75 }
  },
  {
    id: 'cat-adu-30',
    title: 'Pollo con Codorniz y Judías para Gatos Adultos ⭐',
    frenchTitle: 'Poulet Fermier Caille Rôtie & Haricots Fins Chat Adulte',
    species: 'cat',
    growthStage: 'adult',
    category: 'vitality_gourmet',
    categoryLabel: 'Receta Premium Doble Ave & Fibra Saludable',
    description: 'Premium. Cocer pollo 20 min, hornear codorniz 25 min y judías 12 min. Añadir taurina, omega 3 y cáscara de huevo.',
    kcalPer100g: 135,
    prepTimeMin: 15,
    cookTimeMin: 25,
    difficulty: 'Media',
    suitability: 'Gatos que disfrutan de bocados de caza combinados con pollo blanco tierno',
    clinicalBenefits: ['Proteína de alto valor biológico para vitalidad prolongada', 'Judías para saciedad', 'Taurina'],
    ingredients: [
      { name: 'Pechuga de pollo cocida', category: 'protein', baseGramsFor10kgPetPerDay: 55, notes: 'Cocer 20 min' },
      { name: 'Carne de codorniz sin huesos', category: 'protein', baseGramsFor10kgPetPerDay: 45, notes: 'Hornear 25 min' },
      { name: 'Judías verdes cocidas picadas', category: 'vegetable', baseGramsFor10kgPetPerDay: 12, notes: 'Cocer 12 min' },
      { name: 'Taurina felina', category: 'supplement_calcium', baseGramsFor10kgPetPerDay: 0.5, notes: 'Al templar' },
      { name: 'Aceite de salmón', category: 'healthy_fat', baseGramsFor10kgPetPerDay: 2, notes: 'Omega 3' },
      { name: 'Cáscara de huevo molida', category: 'supplement_calcium', baseGramsFor10kgPetPerDay: 2, notes: 'Calcio' }
    ],
    instructions: [
      'Cocer el pollo 20 minutos y hornear la codorniz 25 minutos desmigando sin huesos.',
      'Cocer las judías verdes 12 minutos y picar fino.',
      'Mezclar todo en templado e incorporar la taurina, el aceite de salmón y la cáscara de huevo.'
    ],
    storageInfo: 'Nevera 48h, congelador 2 meses.',
    macronutrients: { proteinPct: 56, fatPct: 27, fiberCarbPct: 3, moisturePct: 76 }
  }
];
