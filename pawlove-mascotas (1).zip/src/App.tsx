import React from 'react';
import { AppProvider, useApp } from './context/AppContext';
import { Header } from './components/Header';
import { HomeScreen } from './components/HomeScreen';
import { PetProfileScreen } from './components/PetProfileScreen';
import { WeeklyPlanView } from './components/WeeklyPlanView';
import { AgendaScreen } from './components/AgendaScreen';
import { RecipesScreen } from './components/RecipesScreen';
import { ToxicFoodsScreen } from './components/ToxicFoodsScreen';
import { NutriIAChatScreen } from './components/NutriIAChatScreen';
import { AlarmModal } from './components/AlarmModal';
import { PageReturnHeader } from './components/PageReturnHeader';
import { WelcomePaymentGateway } from './components/WelcomePaymentGateway';
import { LandingPage } from './components/LandingPage';
import { PaymentPlansModal } from './components/PaymentPlansModal';
import { PWAInstallModal } from './components/PWAInstallModal';
import { PostPurchaseInstallModal } from './components/PostPurchaseInstallModal';
import { PWAInstallBanner } from './components/PWAInstallBanner';
import { FloatingPawsBackground } from './components/FloatingPawsBackground';
import { Navigation } from './components/Navigation';
import { Sparkles, CheckCircle2, AlertCircle, Info } from 'lucide-react';

const MainLayout: React.FC = () => {
  const { 
    theme,
    isSubscribed, 
    showPaymentModal, 
    setShowPaymentModal, 
    showPwaInstallModal,
    setShowPwaInstallModal,
    showPostPurchaseInstallModal,
    setShowPostPurchaseInstallModal,
    activeTab, 
    toast,
    currentView,
    setCurrentView
  } = useApp();

  const [selectedPlanId, setSelectedPlanId] = React.useState<string | undefined>(undefined);

  const renderToast = () => {
    if (!toast) return null;
    return (
      <div className="fixed bottom-6 right-4 sm:right-8 z-50 animate-in slide-in-from-bottom-5 fade-in duration-200">
        <div className={`flex items-center gap-2.5 py-3 px-4 rounded-2xl shadow-xl border text-xs font-semibold backdrop-blur-md ${
          toast.type === 'success'
            ? 'bg-emerald-900/90 text-emerald-100 border-emerald-500/40 shadow-emerald-950/40'
            : toast.type === 'warning'
            ? 'bg-amber-900/90 text-amber-100 border-amber-500/40 shadow-amber-950/40'
            : 'bg-stone-900/90 text-stone-100 border-[#D4AF37]/30 shadow-black/40'
        }`}>
          {toast.type === 'success' ? (
            <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
          ) : toast.type === 'warning' ? (
            <AlertCircle className="w-4 h-4 text-amber-400 shrink-0" />
          ) : (
            <Sparkles className="w-4 h-4 text-[#D4AF37] shrink-0" />
          )}
          <span>{toast.message}</span>
        </div>
      </div>
    );
  };

  // 1. Landing Page View (Default first screen)
  if (currentView === 'landing') {
    return (
      <>
        <LandingPage 
          onGoToPricing={(planId) => {
            setSelectedPlanId(planId);
            setCurrentView('pricing');
            window.scrollTo({ top: 0, behavior: 'smooth' });
          }} 
          onGoToApp={() => {
            setCurrentView('app');
            window.scrollTo({ top: 0, behavior: 'smooth' });
          }}
        />
        <PWAInstallModal 
          isOpen={showPwaInstallModal} 
          onClose={() => setShowPwaInstallModal(false)} 
        />
        <PostPurchaseInstallModal
          isOpen={showPostPurchaseInstallModal}
          onClose={() => setShowPostPurchaseInstallModal(false)}
        />
        {renderToast()}
      </>
    );
  }

  // 2. Welcome Payment Gateway View (Pricing plans & checkout)
  if (currentView === 'pricing') {
    return (
      <>
        <WelcomePaymentGateway 
          onBackToLanding={() => {
            setCurrentView('landing');
            window.scrollTo({ top: 0, behavior: 'smooth' });
          }}
          onBackToApp={() => {
            setCurrentView('app');
            window.scrollTo({ top: 0, behavior: 'smooth' });
          }}
          initialSelectedPlanId={selectedPlanId}
        />
        <PWAInstallModal 
          isOpen={showPwaInstallModal} 
          onClose={() => setShowPwaInstallModal(false)} 
        />
        <PostPurchaseInstallModal
          isOpen={showPostPurchaseInstallModal}
          onClose={() => setShowPostPurchaseInstallModal(false)}
        />
        {renderToast()}
      </>
    );
  }

  const renderActiveScreen = () => {
    switch (activeTab) {
      case 'home':
        return <HomeScreen />;
      case 'pet_profile':
        return <PetProfileScreen />;
      case 'weekly_plan':
        return <WeeklyPlanView />;
      case 'recipes':
        return <RecipesScreen />;
      case 'agenda':
        return <AgendaScreen />;
      case 'concierge':
        return <NutriIAChatScreen />;
      case 'toxic_foods':
        return <ToxicFoodsScreen />;
      default:
        return <HomeScreen />;
    }
  };

  return (
    <div className={`min-h-screen flex flex-col relative ${theme === 'dark' ? 'dark bg-[#0A0F0D] text-stone-100' : 'light bg-[#FAF7F2] text-stone-900'} transition-colors duration-300 antialiased selection:bg-amber-500/30 selection:text-amber-900 dark:selection:text-[#F3E5AB] overflow-x-hidden w-full pb-16 md:pb-0`}>
      {/* Dynamic Ambient Background (Glow orbs & subtle architectural pattern) */}
      <div className="fixed inset-0 pointer-events-none overflow-hidden z-0" aria-hidden="true">
        {/* Glow Ámbar / Dorado Cálido */}
        <div className="absolute -top-24 left-1/4 w-[28rem] h-[28rem] bg-amber-400/10 dark:bg-[#E8B84A]/10 rounded-full blur-3xl animate-float-slow" />
        {/* Glow Verde Bosque / Esmeralda */}
        <div className="absolute top-1/3 -right-20 w-[30rem] h-[30rem] bg-emerald-500/10 dark:bg-emerald-600/10 rounded-full blur-3xl animate-float-reverse" />
        {/* Glow Inferior Ámbar Profundo */}
        <div className="absolute bottom-1/4 -left-20 w-[26rem] h-[26rem] bg-amber-600/10 dark:bg-yellow-600/8 rounded-full blur-3xl animate-float-slow" />
        <div 
          className="absolute inset-0 opacity-[0.035] dark:opacity-[0.045] bg-[radial-gradient(#C49A45_1px,transparent_1px)] [background-size:24px_24px]" 
        />
      </div>

      {/* Floating Paws in Champagne & Gold */}
      <FloatingPawsBackground />

      <div className="relative z-10 flex flex-col min-h-screen">
        <PWAInstallBanner onOpenModal={() => setShowPwaInstallModal(true)} />
        {/* Top Main Atelier Header with Integrated Navigation & Language Switcher */}
        <Header />

        {/* Dynamic Screen Viewport */}
        <main className="flex-1 w-full max-w-7xl mx-auto p-3 sm:p-6 lg:p-8 pb-20 md:pb-12 overflow-x-hidden">
          <PageReturnHeader />
          {renderActiveScreen()}
        </main>

        {/* Mobile Bottom Navigation Bar */}
        <Navigation />

        {/* Global Interactive Alarm Sound & Visual Reminder Popup Modal */}
        <AlarmModal />
      </div>

      {/* Settings Modalidad de Pagos (Subscription Manager) */}
      <PaymentPlansModal 
        isOpen={showPaymentModal} 
        onClose={() => setShowPaymentModal(false)} 
      />

      {/* PWA Install Instructions Modal */}
      <PWAInstallModal 
        isOpen={showPwaInstallModal} 
        onClose={() => setShowPwaInstallModal(false)} 
      />

      {/* Post-Purchase Immediate Install Modal */}
      <PostPurchaseInstallModal
        isOpen={showPostPurchaseInstallModal}
        onClose={() => setShowPostPurchaseInstallModal(false)}
      />

      {/* Global Toast Notification */}
      {toast && (
        <div className="fixed bottom-6 right-4 sm:right-8 z-50 animate-in slide-in-from-bottom-5 fade-in duration-200">
          <div className={`flex items-center gap-2.5 py-3 px-4 rounded-2xl shadow-xl border text-xs font-semibold backdrop-blur-md ${
            toast.type === 'success'
              ? 'bg-emerald-900/90 text-emerald-100 border-emerald-500/40 shadow-emerald-950/40'
              : toast.type === 'warning'
              ? 'bg-amber-900/90 text-amber-100 border-amber-500/40 shadow-amber-950/40'
              : 'bg-stone-900/90 text-stone-100 border-[#D4AF37]/30 shadow-black/40'
          }`}>
            {toast.type === 'success' ? (
              <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
            ) : toast.type === 'warning' ? (
              <AlertCircle className="w-4 h-4 text-amber-400 shrink-0" />
            ) : (
              <Sparkles className="w-4 h-4 text-[#D4AF37] shrink-0" />
            )}
            <span>{toast.message}</span>
          </div>
        </div>
      )}
    </div>
  );
};

export default function App() {
  return (
    <AppProvider>
      <MainLayout />
    </AppProvider>
  );
}
